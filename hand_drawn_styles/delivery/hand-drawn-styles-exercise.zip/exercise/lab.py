from pathlib import Path
import sys,os,subprocess,json,hashlib,datetime,shlex,struct,zlib
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'out';OUT.mkdir(exist_ok=True)
os.environ['HAND_DRAWN_OFFLINE']='1';os.environ['HAND_DRAWN_IMAGE_CACHE']=str(ROOT/'empty-cache');os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'upstream/scripts'))
import render_prompt as rp
import hosted_images as hi
CHECKS=[]
def check(name,ok):
 CHECKS.append({'check':name,'passed':bool(ok)})
 if not ok:raise AssertionError(name)
def run(args,expect=0):
 cmd=[sys.executable,'-B','upstream/scripts/render_prompt.py']+args
 t=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
 row={'utc':t,'command':shlex.join(cmd),'cwd':'exercise','environment':{'HAND_DRAWN_OFFLINE':'1','HAND_DRAWN_IMAGE_CACHE':'exercise/empty-cache'},'exit':p.returncode,'expectedExit':expect,'stdout':p.stdout,'stderr':p.stderr}
 with (ROOT/'commands.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
 check('exit '+shlex.join(args),p.returncode==expect);return p

def png(rgb,comment=None):
 def chunk(k,b):return struct.pack('>I',len(b))+k+b+struct.pack('>I',zlib.crc32(k+b)&0xffffffff)
 b=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',2,2,8,2,0,0,0))
 if comment:b+=chunk(b'tEXt',b'Comment\0'+comment)
 return b+chunk(b'IDAT',zlib.compress((b'\0'+bytes(rgb)*2)*2))+chunk(b'IEND',b'')

step=sys.argv[1];start=datetime.datetime.now(datetime.timezone.utc).isoformat();result={}
if step=='catalog':
 p=run(['--list']);a=json.loads(p.stdout);check('21 unique style identifiers',len(a)==21 and len({x['style_id'] for x in a})==21);check('3.1 included',any(x['style_id']=='3.1' for x in a));result={'styleCount':len(a),'ids':[x['style_id'] for x in a],'python':sys.version,'catalog':a}
elif step=='template':
 args=['--var','N=3','--var','分镜列表=IMU测量【短句】；驱动读取；定位融合']
 a=run(['--style','1']+args);b=run(['--style','xkcd']+args)
 check('alias byte equivalent',a.stdout==b.stdout);check('literal user brackets preserved','【短句】' in a.stdout);check('fixed punctuation label preserved','【最重要·硬性负向约束】' in a.stdout);check('declared slots filled','【N】' not in a.stdout and '【分镜列表】' not in a.stdout)
 (OUT/'prompt.txt').write_text(a.stdout);result={'equal':True,'promptSha256':hashlib.sha256(a.stdout.encode()).hexdigest()}
elif step=='guards':
 cases=[(['--style','1','--var','N=3'],'缺少占位符'),(['--style','1','--var','N=3','--var','分镜列表=测试','--var','多余=内容'],'配方不包含'),(['--style','999'],'不存在画风'),(['--style','1','--var','N='],'不能为空')]
 result={'cases':[]}
 for args,word in cases:
  p=run(args,2);check('diagnostic '+word,word in p.stderr);check('no output on rejection',not p.stdout);result['cases'].append({'args':args,'exit':p.returncode,'stderr':p.stderr})
elif step=='aspect':
 args=['--style','1','--var','N=3','--var','分镜列表=测量；传输；融合']
 a=run(args);b=run(args+['--aspect','16:9']);bad=run(args+['--aspect','not-a-ratio'])
 check('no numeric aspect automatically appended','画幅比例:' not in a.stdout);check('explicit aspect appended','画幅比例:16:9。' in b.stdout);check('arbitrary aspect accepted by upstream','画幅比例:not-a-ratio。' in bad.stdout)
 result={'noAspectSuffix':True,'explicitAspect':True,'arbitraryAspectAccepted':True,'limit':'CLI appends arbitrary aspect; consumer validation still needed. No model call.'}
elif step=='offline':
 a=run(['--style','19','--subject','a robot holding a lantern','--format','json'],2);check('missing cache fails closed','离线缓存缺少有效图片' in a.stderr);check('no production payload',not a.stdout)
 b=run(['--style','19','--subject','a robot holding a lantern','--format','text'],2);check('text-only production refused','正式生产不能只输出 prompt' in b.stderr)
 result={'missingAnchorExit':a.returncode,'textOnlyExit':b.returncode,'scope':'Expected negative tests only. No reference downloads, production image or API call.'}
elif step=='integrity':
 a=OUT/'fixture.png';b=OUT/'metadata.png';c=OUT/'changed.png';a.write_bytes(png((255,180,0)));b.write_bytes(png((255,180,0),b'original synthetic fixture'));c.write_bytes(png((255,181,0)))
 ha=rp.png_pixel_sha256(a);hb=rp.png_pixel_sha256(b);hc=rp.png_pixel_sha256(c)
 check('file hash changes with metadata',hashlib.sha256(a.read_bytes()).hexdigest()!=hashlib.sha256(b.read_bytes()).hexdigest());check('pixel hash unchanged by metadata',ha==hb);check('pixel hash changes with pixels',ha!=hc)
 rec={'bytes':a.stat().st_size,'sha256':hashlib.sha256(a.read_bytes()).hexdigest()};hi.verify_image_bytes(a.read_bytes(),rec,'fixture.png');check('valid bytes accepted',True)
 try:hi.verify_image_bytes(c.read_bytes(),rec,'fixture.png')
 except ValueError as e:check('changed bytes rejected','图片校验失败' in str(e))
 else:check('changed bytes rejected',False)
 result={'fixtureDimensions':ha[0],'pixelSha256':ha[1],'metadataPixelSha256':hb[1],'changedPixelSha256':hc[1],'scope':'Original 2x2 PNG fixture, not real style anchor or visual model test.'}
else:raise ValueError(step)
row={'step':step,'startUtc':start,'endUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':CHECKS,'result':result}
(OUT/(step+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row,ensure_ascii=False))
