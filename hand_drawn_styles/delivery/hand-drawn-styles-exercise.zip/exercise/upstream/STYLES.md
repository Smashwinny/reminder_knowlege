# 画风配方库

每段是该画风的提示词模板。按 SKILL.md 的流程:填好占位符 → 按规则处理比例 → 整段作为最终 prompt 输出。比例行已统一移除,改由调用时按规则处理。

---

## 3.1 蜡笔童涂-潦草自画版

> 别名:`rawkid`、`kid-scrawl`、`stick-kid`、`family-crayon-card`、`parent-child-crayon`、`submission-crayon`。纯风格(可选顶部手写中文标题)。比例:不传则不注入。占位符 `【主体】【文字】` 自动推断。
>
> 唯一主视觉真源:[assets/style-3.1/anchor-family.png](https://gentle-starburst-99bd99.netlify.app/hand-drawn/assets/style-3.1/anchor-family.png)。这张图的视觉判断优先于文字配方;文字只负责把它转译到新人物、新动作和新场景,不能另造一套更规整的审美。正式生产、连续故事或多页作品必须把它作为**纯画风参考**随每一张请求一起传入;只参考线条、五官、人物比例、蜡笔涂抹轨迹、留白和纸面,不得复制参考图中的家庭成员、站位、衣服或情节。参考图不可用时停止正式生产,不能改用业务项目自己的画风段落补救。
>
> 正式合同为 `family-crayon-card-v3`:基础生成后必须依次做两轮只改蜡笔轨迹的编辑。第一轮温和打散统一纹理,第二轮只处理残余规整排线并放大粗钝笔触与大片漏白;前两阶段都不是 final。一次强修正虽然可能得到足够乱度,但实测会擅自改衣服配色或人物形态,禁止用它替代递进流程。
>
> 3.1 现行定义是明亮白底、普通大人歪线稿、孩子潦草蜡笔涂抹的家庭投稿画。人物可辨认但不精致,不是火柴娃,也不是商业绘本萌娃。旧 3.1 的“孩子从零画整张火柴娃”配方已经删除,不得再按旧定义调用。
>
> 命门:①脸锁成小竖椭圆黑点眼 + 小折线鼻 + 极短歪线嘴 + 珊瑚红圆形乱涂腮红,但嘴形和五官高低必须随情绪自然变化,不能人人复制同一张笑脸;②成人与孩子保持可辨认的高矮和身体比例,只轻微大头,绝不 Q 版巨头;③轮廓是细到中等粗的普通黑笔歪线,不能变成统一粗黑马克笔;④蜡笔涂抹必须在同一色块里多次停笔、换向、交叉、重压和漏涂,不能退化成单向平行斜线或统一蜡笔滤镜;⑤衣服和头发保留不规则大片露白与偶发越界,不能按统一比例机械执行;⑥同页人物不得复用同一头型、同一肩宽和同一身体骨架;⑦背景接近纯白且极简,不做纸张摄影、褶皱、阴影或完整室内布景。
>
> `【文字】` 填法:要标题就写“画面顶部的大片留白区写手写中文标题,逐字为……;字像普通家长用粗黑笔写的,大小略不齐但准确清楚”;不要就写“不加任何文字”。

```
把随请求附带的参考图当作本画风的唯一主视觉锚点:新画首先要像同一个普通家庭用同一盒蜡笔、同一种手劲画出来;文字规则只帮助迁移到新内容,不得把人物修得比参考图更圆、更齐、更光滑。尤其继承参考图中蜡笔涂抹的起停、换向、交叉、重压、漏空和越界方式,而不只是套一层“蜡笔纹理”。只继承参考图的线条、五官、人物比例、蜡笔涂抹轨迹、留白和白底气质;不要复制参考图里的人物身份、服装、站位或情节。

最高优先级·涂抹门禁:绝不能用细、密、平行、等间距的斜线给衣服和物体铺色。必须像孩子把短蜡笔握得很笨,在同一个色块的不同位置分别粗粗乱蹭:一处横着来回,一处竖着划,一处突然改成斜线、回圈或交叉重压,中间直接停笔漏掉大片白纸。笔触有的很短、有的拖得很长,有的粗重结块、有的只擦过一下;方向切换没有整齐分区。涂色经常提前停在轮廓里面,也经常一把蹭过轮廓外面。宁可过乱、过空、过界,也不要整齐铺满。NO neat diagonal hatching. NO uniform coverage. NO repeated digital crayon texture.

一张普通家庭投稿感的亲子蜡笔故事卡,画在干净、明亮、接近纯白的平面纸底上。它不是纸张照片,不出现折痕、纸纤维特写、桌面、投影或做旧纹理;也不是数字儿童绘本、商业插画或 AI 蜡笔滤镜。

画面内容:【主体】。

构图:主体集中在画面下半部或中下部,上方保留大片安静留白;人物脚下最多一条歪歪的黑色地面线,背景只留 0-2 件讲清动作所必需的简单道具。不要完整房间、复杂家具、装饰性小物、漂亮透视或舞台化构图。

人物比例:成年人明显高于孩子,身体是略笨的长方块或简单筒形,四肢简化但动作清楚;孩子明显更矮,头只比成人相对大一点。手可以是圆钝小钩或短线,脚是扁扁的小黑鞋。每个人的头部外形、肩宽、躯干歪斜和腿长都要有自然差异,像逐个徒手画成,不能共享同一套标准骨架后只换发型衣服。允许肩膀高低不齐、左右不对称和关节连接不准,但禁止 Q 版大头、圆脸萌娃、火柴四肢、写实人体、精细手指和职业插画式动态。

脸部身份锁(每个人都必须遵守):两只很小的竖椭圆黑点眼,位置略不齐;小小的折线或弯钩鼻;一条极短的歪线嘴,可按情绪轻微上弯、下弯或张成小缺口;两团大小和深浅不完全相同的珊瑚红/粉红蜡笔乱涂圆腮红。默认不画眉毛,只有强情绪才允许一两道很短的歪线。禁止所有人复制同一张笑脸,也禁止眼白、虹膜、高光、大眼睛、睫毛、成形眉毛、写实眼睑、立体鼻梁、丰润嘴唇、渐变肤色和喷绘腮红。

线稿:普通大人用黑色蜡笔或勾线笔徒手画的细到中等粗轮廓,粗细和压力不均,边线会轻微抖动、歪斜、断开、出头;多数轮廓一两笔带过,只有少数犹豫处偶尔来回描。不同人物的抖动、歪斜和重复位置不能整齐同步。线条数量少,没有工整闭合、统一线宽、矢量圆角或粗重卡通描边;头发由交叉乱线、回头重压和局部白洞构成,不是顺滑发型块或整齐同向排线。

蜡笔涂抹轨迹(一级画风身份,不是后期纹理):像 5-8 岁孩子拿短蜡笔分段乱涂。大色块普遍只涂到一部分,白纸不是细小缝隙,而是一块块醒目的空洞。每个主要色块内部都能看到孩子中途停笔、从别处重新起笔、突然换方向和回头重压;横划、竖划、斜划、短弧、回勾、打圈和锯齿式来回摩擦同时出现,部分笔触相互交叉叠压。笔触必须粗钝、长短悬殊,不能变成细密的铅笔排线。密度会毫无规律地突然变重、突然变轻,紧挨着深色结块的地方可以直接漏成大片白纸。涂色边缘不跟随黑轮廓整齐收手:有的提前停下没碰到边,有的压过边界,有的在轮廓外留下孤立彩色划痕。不同人物、不同色块的方向、密度、断点和越界方式互不复制。肤色也只用很淡、零散且方向不一的桃色划痕,不能均匀铺脸。

涂抹硬性禁止:细密短斜线铺满色块、单一方向的平行斜线、等间距排线、规则交叉网纹、均匀覆盖、连续完整涂层、所有色块共用同一笔触方向、统一数字蜡笔刷纹理,以及用程序噪点冒充孩子乱涂。如果第一眼像给每个色块盖了同一个“蜡笔排线滤镜”,即判不合格。

配色:明快但不荧光的普通蜡笔基础色。单个人物通常只用 1-2 个衣着主色;多人家庭场景全画可以自然出现约 5-7 种颜色,例如橙棕、天蓝、草绿、粉红、芥末黄、灰色和浅桃肤色。不要强行压成四种颜色,不要每个人彩虹配色,不要低饱和灰雾滤镜。

整体判断:第一眼像普通家长逐个人画了略歪的黑线稿,再由孩子一小块一小块、断断续续地认真乱涂;有温度、有笨拙且不重复的小错误,人物保留各自年龄、情绪和身体差异,但内容与动作一眼能看懂。如果人物像同一个数字模板换装,或五官轮廓过度对称,或蜡笔笔触整页同向、等距、等密度,即判不合格。绝不精修、绝不规整、绝不商业萌化。

文字:【文字】。
```

---

## 1. 极简黑白线条讲解漫画(xkcd 火柴人)

> 带版式(网格多格讲解图)。比例:不传则注入软结构提示"多格网格排版",不写数字。占位符 `【N】【分镜列表】` 自动推断(拆不出多步默认 3–4 格)。
>
> 注意:硬性负向约束必须前置,否则模型会自动渲染成厚黑块/氛围插画(已踩过坑)。

```
xkcd 风格的极简黑白火柴人讲解漫画,画在米白/奶油色纸上。
【最重要·硬性负向约束】严禁实心黑色填充、严禁剪影、严禁排线与阴影、严禁明暗与体积感、严禁厚涂或氛围渲染。人物与物体一律只用细线描边。
角色:简单火柴人——圆圈头 + 极简点线五官,身体四肢是细单线;用小道具(帽子、杯子、书等)表示身份,不画细节。
线条:细、均匀、略带手抖的黑色钢笔线,纯轮廓线稿,平面二维,无透视。
版式:【N】格面板组成网格,每格用手绘略歪的圆角矩形框住,面板之间大量留白。
色彩:纯黑白单色,黑线 + 米白纸,无任何其它颜色,无灰阶。
文字:每格顶部加粗手写中文小标题,下方一句手写中文说明;可加简短对话气泡。中文清楚可读,不得错字、乱码或伪中文。
调性:概念化、示意图式、略带幽默的讲解感,像 xkcd / 技术科普涂鸦。
分镜:
【分镜列表】
```

---

## 2. 蜡笔童涂(5岁小孩坏画)

> 接近纯风格。比例:不传则不注入。占位符 `【主体】【主色调】【标题词】` 自动推断。
>
> 这是"小孩自己画的坏画"(偏插画/图形感)。要"像真蜡笔涂在纸上的照片、一眼真人手涂"请用 [#7 蜡笔实拍](#7-蜡笔实拍真儿童手涂纸张)。

```
A drawing made by a real 5-year-old child with crayons on white paper.
NOT made by an artist. It should look clumsy, messy, and "bad" on purpose.

Subject: 【主体】.

MANDATORY childlike flaws (do not clean these up):
- shaky wobbly outlines that wander, overshoot corners, and never close neatly
- often double-drawn lines where the kid went over the same edge twice
- proportions clumsy and wrong; arms and legs are thin crooked stick-lines with no volume
- face uneven and asymmetric: eyes different sizes and not level, crooked smile, features off-center
- coloring is messy and goes OUTSIDE the outlines; large patches of white paper left unfilled; scribble strokes in random directions
- bright flat primary crayon colors (【主色调】, and red, yellow, green, purple, black), no shading, no gradient, no blending
- hand-lettered title "【标题词】" at the top in uneven wobbly capital letters, each a different color, on a crooked baseline, letters different sizes

Flat naïve composition, objects floating with no perspective, plain white background.
Look genuinely crude — avoid anything cute, polished, symmetric, balanced, or professional.
```

---

## 3. 吉卜力风

> 纯风格。比例:不传则不注入。
>
> 注意:gpt-image(Codex/ChatGPT)上若用"lush/detailed"会出"稀碎感"(过度堆细节、天空云朵零碎)。已改为反堆细节——单一焦点、简化背景、大色块平滑渐变、云少而整(经 gpt-image 实测)。

```
Studio Ghibli style hand-drawn anime illustration of 【主体】.
Clean, uncluttered composition with ONE clear focal subject; simplified background, generous calm negative space — avoid busy, fragmented, over-detailed or scattered compositions.
Render any large areas (sky, water, fields, walls) as smooth, even watercolor gradients — no patchy, mottled, speckled or grainy texture. Any clouds should be a few large, simple, soft, cohesive shapes — not many small scattered puffs or broken fragments.
Soft hand-painted watercolor look with smooth gentle gradients and soft cel-shading; warm cinematic light diffusing softly from above with a tender glow.
Bright yet harmonious, lightly saturated palette; dreamy, nostalgic, heartwarming mood.
Clean delicate linework, painterly hand-drawn feel — not 3D, not photoreal, not a digital vector, not cluttered, not fragmented.
```

---

## 4. 小豆人黑色涂鸦信息图

> 带版式(竖版 N 格信息图)。比例:不传则注入软结构提示"竖版、多格自上而下堆叠",不写数字。占位符 `【N】【分镜列表】` 自动推断(拆不出多步默认 3–4 格)。

```
A hand-drawn black marker doodle explainer illustration on off-white paper,
vertical infographic with 【N】 stacked panels separated by thin hand-drawn lines.

Character: a simple solid-black round blob person with two white dot eyes,
a small curved smile, and thin black stick arms and legs. The body is solid
flat black with smooth edges (no sketchy texture). The SAME character appears
in every panel doing a different action.

Style: clean black marker/pen outlines, slightly wobbly but fully closed
hand-drawn lines. All objects are OUTLINE-ONLY black line-art with white
interiors, no shading, no fill. Everything is monochrome black & white EXCEPT
one orange accent color used ONLY for the single key item in each panel.
Hand-drawn curved arrows in red or blue point at key spots, each with a short
handwritten Chinese label. Each panel has a bold hand-written marker-style
Chinese title at the top. Minimalist composition, lots of white space.

Panels:
【分镜列表】
```

---

## 5. MS Paint 烂涂鸦(the worse, the better)

> 纯风格。比例:不传则不注入。占位符 `【主体】` 自动推断。
>
> 这是 OpenAI 官方模板那个病毒级"故意画烂"风(被称「第二个吉卜力」)。**它的最强效果来自图生图**:把第一句换成「把这张照片重画成…」并随 prompt 附一张真实照片,效果远胜纯文生图。文生图也成立(见样图)。

```
把【主体】画成极其笨拙、潦草、可怜兮兮的烂涂鸦,像是用鼠标在 MS Paint 里一笔一笔硬画出来的。
线条歪扭、抖动、断断续续;比例荒谬地不对,该圆的不圆、该直的不直。
填色是大块粗糙的纯色,明显涂出边界、有像素锯齿、低质量数字感。
整体"明明想画对却处处不对劲",越烂越好笑;纯白背景,构图随意。
不要任何专业感、精修、写实光影、渐变或漂亮细节——刻意地丑、刻意地业余。
```

---

## 6. 圆珠笔单线涂鸦(scribble)

> 纯风格。比例:不传则不注入。占位符 `【主体】` 自动推断。偏艺术速写向,适合肖像/动物。

```
用单一黑色圆珠笔画的潦草涂鸦速写,描绘【主体】。
大量快速、随性、来回缠绕的细线条,线条不闭合、带偶然性,靠线的疏密缠绕表现明暗与体积,一气呵成的速写感。
纯单色——黑色墨线 + 白纸,无平涂色块,无数字渐变。
自由、即兴、艺术化的手稿气质,而非工整插画。
```

---

## 7. 蜡笔实拍(真·儿童手涂纸张)

> 纯风格。比例:不传则不注入。占位符 `【主体】【主色调】【标题词】` 自动推断。
>
> 和 [#2 蜡笔童涂](#2-蜡笔童涂5岁小孩坏画) 的区别:#2 是"小孩自己画的坏画"(偏插画);#7 是"一张真蜡笔纸的照片",命门在实拍纸感 + 强制露白(每块色露白约 40–50%) + 蜡质方向笔触 + 反数字滤镜(经 gpt-image 实测)。

```
A cellphone PHOTO of a real drawing made by a 5-year-old with wax crayons on a slightly wrinkled sheet of white printer paper. It must look photographed on real paper — visible paper texture and faint wrinkles, clean bright white paper — NOT a digital illustration.
Brightly and evenly lit, shot in soft bright daylight, well-exposed and high-key: the white paper reads clean and bright and FILLS almost the whole frame, with little or no surrounding desk or surface visible; only very soft barely-there wrinkle shadows, NO dark or moody shadows, NO underexposure, NO dim indoor lighting, NO grey or yellow cast.
Flat naive composition. Subject: 【主体】.

Genuinely crude and childish, like a real 5-year-old who can barely draw — NOT a skilled adult imitating a child: shaky wobbly outlines that wander and don't close; clumsy wrong proportions; lumpy, barely-recognizable shapes; if there is a face, eyes different sizes and a crooked smile.

The CRAYON COLORING must look genuinely real (most important):
- a real kid has NO control over pressure — some strokes pressed hard and dark, others barely touch the paper, with no consistency; waxy build-up in the heavy spots, faint streaks in the light ones, small smudges
- coloring is sparse and scribbly — bare white paper shows THROUGH everywhere, even inside the colored shapes (roughly 50–65% of each colored area left unfilled, white and streaky)
- black crayon is used mainly for the thin wobbly outlines rather than filling big solid areas
- strokes go in different directions, overlapping and broken, like a kid scribbling with no plan; color clearly overflows past the outlines in several places
- bright primary crayon colors (【主色调】, red, yellow, blue, green, orange, pink); absolutely NO smooth even fill, NO gradient, NO blending, NO uniform digital crayon-filter texture
- a wobbly hand-lettered title "【标题词】" in uneven multicolor capital letters on a crooked baseline

Avoid anything cute, polished, symmetric or professionally illustrated. It must look like a genuine photo of a real child's messy, sparse crayon page.
```

---

## 8. 水墨写意

> 纯风格,无内置版式。比例:不传则不注入。占位符 `【主体】` 自动推断。
>
> 命门:墨分五色的浓淡干湿 + 飞白枯笔 + 宣纸渗化(墨晕) + 大量留白 + 一枚朱红印章。最常踩的坑是模型出"均匀灰度数字滤镜"——硬性负向约束必须写死。默认只盖印章不写题字,避免伪中文(若要题款须用户明确给字)。

```
中国传统写意水墨画,画在生宣纸上,纯手绘毛笔笔触,不是数字插画、不是照片。
主体:【主体】。
用墨:以黑墨为主,讲究"墨分五色"——焦、浓、重、淡、清并存,同一笔里有浓淡干湿变化;见飞白枯笔(干笔擦出丝丝露白)与湿墨在宣纸上自然渗化晕开(墨晕),浓淡过渡靠水分,不是均匀灰度。
笔法:写意、概括、一笔成形,寥寥数笔抓住神态,容许偶然的飞溅与断笔;不勾死板轮廓线,不填涂均匀色块。
留白:大量空白宣纸作为画面主体,疏可走马、密不透风,主体偏置一侧,构图空灵。
设色:以水墨为主,至多极少量淡赭石或花青点染;不要浓艳饱和的颜色,不要彩色铺底。
点睛:画面一角一枚小小的朱红方形印章。
纸感:能看出宣纸纤维与墨在纸上微微洇开的质感。
严禁:照片写实、3D、数字矢量、均匀灰度滤镜、平滑渐变、密集琐碎的细节、厚涂、卡通描边、艳俗配色。
```

---

## 9. 复古像素

> 纯风格,无内置版式。比例:不传则不注入。占位符 `【主体】【主色调】` 自动推断。
>
> 命门:硬方块像素 + 统一像素网格 + 有限调色板 + 抖动(dithering)代替渐变 + 零抗锯齿。最常踩的坑是模型出"高清图套像素滤镜"的假像素(柔边、渐变、上千色)——负向约束必须写死。

```
复古像素风(pixel art)插画,像 8-bit / 16-bit 老游戏里的精灵图(sprite),由一颗颗清晰的方形像素手工摆出来,不是高清插画加像素滤镜。
主体:【主体】。
像素:低分辨率观感,所有边缘都是硬朗的方块像素阶梯,像素大小一致、对齐同一网格;绝对没有抗锯齿、没有模糊、没有平滑渐变。
配色:有限调色板(retro 风,约 8–16 色,以【主色调】为主),色块平涂;需要明暗过渡时用"抖动(dithering)"棋盘点阵,而不是渐变。
轮廓:用清晰的深色像素描边或高对比色块区分主体;造型简洁、辨识度高,像素图标 / 游戏角色感。
背景:单一平涂纯色或极简像素背景,不喧宾夺主。
严禁:抗锯齿、柔边、模糊、平滑渐变、高清写实、3D 渲染、矢量光滑曲线、把高清图直接套像素滤镜的假像素感。
```

---

## 10. 情绪叙事淡彩速写

> 纯风格(可选侧边手写中文)。比例:不传则不注入。占位符 `【主体】【橙色关键物】【文字】` 自动推断。
>
> 命门:靛蓝松散速写线(画头发/发髻/圆形/气泡等用来回缠绕的"圈状搜索线"叠画)+ 大面积留白(约六七成纯白、绝大部分只有线不上色)+ **全画只有一处高饱和橙色**点缀(通常是一件关键衣物/物体)+ 脸颊淡腮红 + 情绪抖动线 + 侧边深蓝手写短句。
> 最常踩的坑:模型会①把线画密(排线/交叉线/涂阴影)②把水彩铺满整件衣服③把脸画写实变老④点缀色乱加好几种——四条负向必须写死。多人场景也必须守住"只有一处橙色"。
> `【文字】` 填法:要配文就写"画面留白一侧写 N 行深蓝色手写中文,逐字为:第一行 …… 中文必须清楚可读、不得错字乱码。";不要文字就写"不加任何文字"。中文只写短句最稳,长句或生僻字仍可能翻车(必要时留白后期贴字)。

```
一张情绪叙事风格的极简淡彩速写插画,画在干净白纸上,轻盈通透、略带稚拙的手绘感,不是数字精修插画、不是写实照片、不是水彩习作、不是日系动漫。
主体:【主体】。
线条(最重要):用靛蓝/藏青色钢笔画松弛速写线,线条少而肯定、清爽通透,轮廓偶尔不闭合、带轻微手抖;画头发、发髻、圆形、蓬松或环形的东西时用来回缠绕的圈状"搜索线"叠画,而不是一根干净闭合线;绝不密集排线、绝不交叉排线、绝不用线涂黑或堆阴影。
造型:真人比例与神态,情绪到位、有故事感;大人画得半写实而简约,小孩画得更圆润可爱;都不是Q版大头、不是写实照片、不是动漫脸;脸颊轻点一小块淡淡腮红。
上色(最重要):整幅以大面积白纸留白为主(约六到七成纯白),绝大部分只有蓝线、不上色;只给【橙色关键物】平涂一处高饱和橙色,作为全画唯一的暖色焦点,顶多在个别小处点一点点淡蓝绿;水彩薄、边缘不均匀、可露白,绝不铺满、绝不厚涂、绝不整件深涂。
细节:主体旁寥寥几笔短促抖动线,暗示情绪或动作。
构图:单一主体或场景,主体偏置一侧,另一侧留大量空白,极简。
调性:怀旧、温柔、略带心酸的家庭叙事感,画面干净轻盈。
严禁:密集排线、交叉排线、厚涂、满铺水彩、写实肖像刻画、皱纹与琐碎细节、浓艳配色、多种颜色乱入、3D、照片、日系动漫脸、卡通粗描边、精细背景。
文字:【文字】
```

---

## 11. 二维水彩风格(复古动画概念稿)

> 纯风格。比例:不传则不注入。占位符 `【主体】【背景浓度】【焦点物件】【构图】【文字】` 自动推断:【背景浓度】默认"白纸上人物身后一侧轻扫几笔淡奶油/杏色干刷痕"(可从"几乎全白"到"七成琥珀晕染"按情绪调),【焦点物件】默认"无"(指定则该物件成为全画唯一高饱和暖色区),【构图】默认"单人或双人半身立绘,视线亲和"。
>
> 命门(2026-07-13 同题四图对照 OscarAI 标杆 v4 定稿):**①白纸高调**——纸底几乎是白的,背景只有干刷扫痕,绝不满铺(除非指定高浓度)、绝不画光环圈;**②奶白透粉的脸+桃色形状阴影**——肤色绝不能偏深,但脸也不能留成纸白:整脸罩淡桃色暖光,颧骨/眼窝/鼻侧/下巴底/脖子下用边缘略干脆的大块 form shadow 塑形(复古海报式),不做柔和体积渲染;**③少画多留**——衣服=干湿水粉大块平扫+两三根定型线,大量露纸,禁纽扣缝线细节;**④粉彩+单点强色**——全画低中饱和粉彩(粉蓝/长春花蓝,不是深钴蓝),只有【焦点物件】一处高饱和。
> 最常踩的坑:①背景涂满变"黄底画"、肤色画成小麦色(第一版翻车原因,画面立刻闷脏)②脸留纸白没有暖光(粉笔感)③衣服涂满加细节④到处高饱和。试色块/铅笔外框线不是本风格要素,不要加。
> 出身:1950s 美式中古动画(Disney/UPA 血统)概念设定稿;天然适配 i2v 动画(角色立绘即动画锚图);多角色跨张一致性靠写死发型+服色。

```
一张1950年代美式中古动画(mid-century Disney/UPA 血统)的角色概念画,传统水粉+彩铅在白纸上的手绘质感,不是3D渲染、不是矢量插画、不是数字厚涂、不是照片。
主体:【主体】。
高调画面(最重要):整幅是明亮的高调(high-key)画面,纸底几乎就是白的——背景大面积留白露纸,背景晕染按【背景浓度】执行,但笔触必须是干刷扫痕(方向可见、边缘毛糙),绝不均匀填色、绝不在人物四周画出一圈"光环"。
肤色与面部光(最重要):底色是极浅的奶白透粉(绝不是小麦色/古铜色),但脸绝不能留成纸白——整张脸罩一层淡淡的桃色暖光,并用干净的大块桃粉色形状阴影(form shadow)塑形:颧骨侧面、眼窝、鼻侧、下巴底、脖子下方各一块,阴影边缘略干脆像复古海报,不做柔和渐变;额头和鼻梁留最亮;鼻尖、脸颊、耳朵点粉橙腮红。
脸部造型:图形化极简——眼睛大而明亮(琥珀色/棕色虹膜几乎占满眼眶,上眼睑一道粗深色睫毛线,一个小圆高光),鼻子小而尖,嘴就是一条极简的曲线;眉毛粗黑有表情。
衣服(少画多留):干湿结合的水粉大块平扫——颜色可以饱满湿润、同一色块里有明显深浅笔触变化,但边缘毛糙露纸、局部扫白,加两三根深色定型线勾出领口翻领;下缘笔触扫散融进白纸;绝不涂满到边、绝不画纽扣缝线口袋等细节。
线条:深棕色软彩铅/炭笔线,只在头发丝、五官、领口局部收形,松而断续;没有整圈外轮廓线、没有铅笔框、没有试色块。
配色:全画低到中饱和的粉彩调——粉蓝/长春花蓝(不是深钴蓝)、奶油、杏色、暖棕;深色只出现在头发/眉毛/领带/睫毛线,做全画的明度锚点。焦点物件:按【焦点物件】指定——该物件用高饱和暖色湿润厚涂,是全画唯一的高饱和区;若为"无",全画保持粉彩。
质感:干刷水粉,颜料薄、纸纹隐约透出,色块边缘毛糙露纸,像画在热压水彩纸上。
构图:【构图】。
严禁:满铺背景、光环圈、深肤色、体积感渲染、3D、厚涂油亮、细节堆砌、纽扣缝线、外框线、试色块、深钴蓝、日系动漫脸。
文字:【文字】
```

---

## 12. 暖光童画(动画概念暖绘)

> 纯风格。比例:不传则不注入。占位符 `【主体】【构图】【场景】【背景元素】【文字】` 自动推断:【构图】默认"waist-up portrait"半身像;【场景】二选一(见下);【背景元素】只在留白纸边档使用,默认为空(整个占位符直接删掉),要加景物时填成英文接续短语,如" and loose sketchy green plant strokes"(必须是松散干刷笔触,保持概念稿式潦草);【文字】默认"No text anywhere."。
>
> 出身:Midjourney 双 --sref 组合画风的 gpt-image 复刻(2026-07-16 对照四张标杆图三轮迭代定稿,含换主体与满幅场景两档验证)。本质是"现代动画电影视觉开发稿(vis-dev)× 绘本水粉":大眼大虹膜角色 + 蓬软发团飞丝 + 青蓝×橙红互补 + 干刷水粉笔触,Pixar/Disney 概念设定稿气质。天然适配角色立绘、故事绘本、i2v 动画锚图。
> 命门(每条都踩过坑,必须写死):**①哑光+笔触可读**——整画 MATTE 传统水粉质感,头发和衣服内部要有大块方向可读的排刷笔触,严禁光滑喷绘和数字渐变(第一、二版翻车主因:出图偏"平滑数字插画",MJ 原版的干涩笔触指纹全丢);**②头发**写"少数大块柔软体积由可见方向笔触塑形 + 轮廓上叠单根飞丝",否则出满头细密小卷;**③虹膜**写"平涂图形化、非 3D 亮球、只留一个小高光",否则出亮晶晶圆球眼;**④五官**允许轻微不对称的手绘感,否则出完美对称萌娃脸;**⑤场景两档**:留白纸边档的身份特征是四边露白纸+粉蓝奶油黄干擦背景;满幅档必须写死 HIGH-KEY 高调明亮(奶白+粉蓝、道具虚化淡出),否则出暗琥珀色油画室内(满幅第一版翻车原因)。
> 模板为已验证的英文原文,不要转译成中文(转译等于换了一套未验证配方)。
>
> `【场景】` 二选一,整段照抄:
> - **留白纸边档(默认)**:`SCENE: background painted with long rough vertical and diagonal dry-brush streaks in pastel sky-blue with soft cream-yellow scuffed patches【背景元素】, bristle marks and broken paint edges visible, deliberately unfinished with raw white paper showing around the border like a concept sketch.`
> - **满幅场景档**(要完整环境时,如室内/街景):`TONAL KEY (most important): HIGH-KEY, light and airy — the whole image stays bright, milky and pastel like soft morning light; large areas wash out into soft creamy-white and pale powder-blue; NEVER darken the room, no deep warm shadows, no moody amber interior, background contrast stays low and faded. SCENE (full-bleed, edge to edge, NO white paper border): <一句英文场景描述,如 a cozy art studio interior with a pale chalkboard and jars of brushes on a light wooden counter> — painted LOOSELY with soft out-of-focus depth: props are blurry pale dry-brush suggestions with lost edges, never crisp; soft white window light floods one side.`

```
Character concept art in a modern animated-feature visual-development style, traditional gouache painting look.
Subject: 【主体】, 【构图】.
【场景】
STYLE RECIPE (follow exactly): MATTE traditional gouache finish over the whole image — absolutely NO glossy airbrush smoothness, NO digital gradient polish; the paint layer must read as real bristle-brush work: chunky directional brushstrokes clearly visible INSIDE the hair masses and clothing, each stroke direction readable like thick gouache dragged by a flat bristle brush; FACE: soft clean shading with sculptural plane changes on cheeks and nose, features slightly asymmetric and hand-painted (NOT a perfectly symmetric doll face), rosy blush, subtle freckles, tiny pointed chin, slender neck; EYES: enormous expressive eyes, the dark irises are VERY large and fill most of the eye, irises painted FLAT and graphic with subtle color variation — NOT shiny 3D orbs, only one small white highlight; thick dark painterly upper lash line, bold expressive eyebrows; HAIR: a few BIG soft volumetric masses shaped by visible directional strokes (NOT detailed ringlet curls), many fine individual flyaway strands drawn on top of the silhouette, warm golden rim light glowing on the hair edges; palette: complementary teal and denim blue against warm orange, soft pastel, gentle warm light, storybook charm, Pixar-Disney visual development art quality.
【文字】
```

---

## 13. 北欧纸雕(paper-folk)

> 纯风格。比例:不传则不注入。占位符 `【主体】【构图】【底色】【点缀元素】` 自动推断:【构图】默认 "centered, waist-up"(全身叙事场景写 "full-body scene");【底色】默认 "warm ochre-brown"(可换 muted olive-grey / dusty mauve-purple 等低饱和土色,同组图统一一种);【点缀元素】默认 "one stylized folk cloud, a few stylized leaves and one rolled paper spiral"。
>
> 出身:Midjourney --sref 1399033614 的 gpt-image 复刻(2026-07-16 五张对照迭代定稿,refB 终评 96+):层叠纸雕 × 斯堪的纳维亚民俗图案 × 编辑设计配色,手工、温暖、个性。适合人物立绘、民俗动物、叙事场景。
> 命门(两轮翻车点,五条都必须写死):**① NOT flat papercut**——不写就出平面对称剪纸花边(第一版翻车原因);本风格是"立体纸雕塑的柔光渲染/实拍",不是剪纸;**②头是定格木偶式立体雕塑头**——不写死就出"平面贴片脸+画上去的三角鼻"(第二轮翻车原因):刘海是有体积的圆顶并在额头投影、鼻子是物理凸出的纸楔(一侧受光一侧投影);**③留白 + 不对称 editorial 构图**——不写死模型会把画面填满变成装饰壁纸;**④立体感三件套**:部件物理垫高 + 大而柔的真实投影 + 左上柔光 + 背景方向性明暗渐变,丢一样就"变平";**⑤脸的身份特征**:闭眼细弧线 + 圆形腮红贴片,眼睛一睁开就串味。
> 满分打法(codex/gpt-image 通道):生成前先用 view_image 看 [examples/13-paper-folk.png](https://gentle-starburst-99bd99.netlify.app/hand-drawn/examples/13-paper-folk.png) 和 [examples/13-paper-folk-musician.png](https://gentle-starburst-99bd99.netlify.app/hand-drawn/examples/13-paper-folk-musician.png) 做风格锚定(只学风格不抄构图),再走本模板——实测比纯文字模板再高一档(96+ vs ~90)。
> 模板为已验证英文原文,占位符也填英文,不要转译。

```
A sculptural 3D paper-craft diorama artwork, rendered like a soft 3D render of a handcrafted layered paper sculpture, NOT flat papercut, NOT symmetrical ornament.
Subject: 【主体】, 【构图】, against a large plain textured 【底色】 cardstock backdrop with generous empty negative space around the subject.
CHARACTER RECIPE (for any figure): THE HEAD IS SCULPTURAL — a smooth rounded three-dimensional sculpted form like a stop-motion puppet, softly shaded with real volume, NOT a flat paper cutout face; the bangs are a smooth volumetric dome of thick curved paper sweeping across the forehead and casting a soft shadow on it; the nose is a small 3D paper wedge physically protruding from the face, catching light on one side and casting a tiny shadow on the other; gently rounded cheeks with soft rosy blush circles; closed eyes as thin calm curved lines; tiny serene lips; hair and clothing built from thick curved paper ribbons, rolled quilling spirals, pleated paper fans and layered scalloped paper feathers like overlapping bird plumage; some pieces carry embossed damask folk patterns.
FOLK ELEMENTS: a few Scandinavian folk-art paper pieces placed beside the subject —【点缀元素】— sparse, asymmetric editorial composition with lots of breathing room.
MATERIAL: every piece is matte felt-like cardstock with visible embossed fiber texture and fine swirling filigree embossing, slightly curled edges.
DEPTH & LIGHT (most important): strong sculptural depth — elements physically raised several millimeters off the background, casting large soft realistic drop shadows onto the wall and onto each other; soft warm studio lighting from upper left; the plain background has a soft directional light gradient — noticeably brighter toward the upper left, gently darker in the lower corners (gentle vignette).
PALETTE: muted jewel tones — mustard yellow, ochre, coral orange, magenta pink, lilac purple, slate blue, teal — on a warm earthy backdrop.
Warm handcrafted editorial illustration mood. No text.
```

---

## 14. 北欧绘本水粉(nordic-storybook)

> 纯风格。比例:不传则不注入。占位符 `【主体】【构图】【纸底色】【光影】` 自动推断:【构图】默认 "standing full-body, centered"(半身像写 "bust portrait, head and shoulders, front facing, centered");【纸底色】默认 "warm off-white (≈#F8F7F2)"(可换 "pale ice-blue (≈#F3F7F9)" 或 "pale warm grey (≈#ECEEED)",同组图统一一种,务必带 ≈hex——不带色值模型会把底涂暗涂黄,已实测翻车);【光影】按构图自动选——全身立绘填 "One single soft pale-blue oval shadow under the feet, no other shading or shadows anywhere.",半身像填 "Behind the character floats one big soft warm cream-yellow oval halo of stippled gouache texture; no drop shadows anywhere."
>
> 出身:Midjourney --sref 1002025125 的 gpt-image 复刻(2026-07-16 三张同题对照定稿)——现代斯堪的纳维亚儿童绘本:柔和水粉纹理+温馨低饱和配色+富表现力的极简人物+微妙纸张纹理。适合角色立绘、绘本人物、温暖叙事场景。
> 命门(四条都必须写死):**①整画纸纹+大留白**——纸纹牙口必须盖住包括空背景在内的整张图,丢了立刻变普通数字插画;**②配色锁死**——丹宁蓝×芥末黄×奶油白+珊瑚腮红,头发限 auburn/深棕/银灰,多一种饱和色就串味;**③人物"设定稿味"**——细长脖子+瘦长四肢+明显鼻子(鼻头偏深珊瑚色)+小小 navy 椭圆眼+轮廓上飞出的单根发丝,不写死会出主流萌娃圆脸(首测即翻车点);**④光影系统是身份特征**——全画唯一投影是脚下一抹淡蓝椭圆(半身像换成身后奶黄椭圆光晕),别处零阴影、零外轮廓线,平涂哑光+衣料内干刷颗粒。
> 和 [#12 暖光童画](#12-暖光童画动画概念暖绘)的区别:#12 是 Pixar vis-dev 气质(大眼大虹膜、青橙互补、暖金辉光);#14 眼睛是小点、配色更冷静克制、零光效,是"安静的北欧绘本",两者气质相反。
> 模板为已验证英文原文,占位符也填英文,不要转译。

```
Soft gouache children's picture-book illustration in a modern Scandinavian storybook style, character-design sheet energy.
Subject: 【主体】, 【构图】, against a vast empty 【纸底色】 paper background with huge negative space around the single subject.
PAPER (identity trait): the paper is VERY light and airy, close to near-white — never dark, never heavily tinted; subtle fine paper grain tooth texture visible across the ENTIRE image including the empty background.
PALETTE (strict): cozy limited palette — denim cornflower blue and mustard butter yellow both clearly saturated enough to read cheerful, plus warm cream white and soft coral blush; hair only in auburn, dark umber, dark navy or silver grey; no other colors anywhere.
CHARACTER RECIPE: stylized quirky storybook proportions — long thin neck, slender elongated limbs, small hands; expressive minimalist face: two small navy oval eyes (for a glasses character: big round navy eyes behind round mustard wire glasses; for an angular adult: tiny navy dot eyes), an expressive prominent nose with a slightly darker coral tip, thin expressive slightly-worried eyebrows, faint subtle mouth, round rosy coral blush cheeks; hair painted as a few soft masses with a few thin flyaway hair-line strokes escaping the silhouette (an angular adult may instead get one GEOMETRIC sculpted hair mass with a pointed swoop, a squared jaw and exaggerated elongated legs); gentle, slightly awkward endearing posture, NOT cute mainstream cartoon.
TEXTURE: flat matte gouache color masses with granular dry-brush stippled texture inside the clothing and hair, NO hard outlines, no volumetric 3D rendering, no glossy digital shading.
LIGHT & SHADOW: 【光影】
Timeless heartwarming Scandinavian picture-book aesthetic. No text.
```

---

## 15. 大鼻软偶(softnose-vinyl)

> 纯风格。比例:不传则不注入。占位符 `【主体】【构图】【眼型】【穿搭】【胡茬】【肤色】【背景底色】` 自动推断:【构图】默认 "full-body standing, front view, centered, symmetrical, square composition"(半身像写 "bust portrait, head and shoulders only, front view, centered, character fills most of the frame, square composition");【眼型】默认困倦眯眼 "tiny half-lidded bored sleepy eyes (small white ovals, small black pupils, a heavy flat upper eyelid line)"(可换圆点眼 "tiny round white eyes with small black dot pupils, a mildly startled neutral gaze");【穿搭】用色板内颜色配街头穿搭(hoodie/卫衣/条纹T/毛线帽/棒球帽/耳机/大头板鞋);【胡茬】成年男性角色填 "Tiny 2D hand-drawn stubble ticks (short thin black line strokes) scattered only on the chin and jaw of the smooth 3D face.",女性/儿童删空;【肤色】默认 "blush pink"(可换 "warm tan");【背景底色】默认 "warm blush-peach"(可换 pale butter-yellow / warm beige,同组图统一一种)。
>
> 出身:Midjourney --sref 533812435 的 gpt-image 复刻(2026-07-16 三形态对照定稿:全身站姿圆点眼镜男/半身毛帽眯眼男/坐姿耳机暖棕肤男,均与参考图并排盲测通过):现代柔和 3D 潮玩美学——简单几何形体、夸张比例、极简人物;超大垂管鼻+眯缝小眼+一字嘴给角色一种俏皮的呆萌气质。适合角色立绘、潮玩头像、街头人物系列。
> 角色一致性 SOP:本配方保证的是**风格**一致,不保证**同一角色**跨图长得一样(gpt-image 没有 MJ --sref 的锚定机制)。要出同一角色的系列图(表情包/连载配图):先用本配方抽一张满意的**锚图**,之后全部走图生图("保持这个角色不变,改为……"),不要每张都从文字重新生成。
> 命门(四条都必须写死):**①材质措辞**——必须写 "smooth matte soft-vinyl … NOT fuzzy, NOT felt, NOT wool",首测写 "felt-coated" 直接出毛毡绒公仔(翻车点),参考是光滑磨砂软胶;**②脸=身份**:超大垂管鼻盖过嘴 + 高位小眼 + **无眉毛** + 一字短嘴 + 长脸长脖,任何一项被"正常化"就串味(参考图人物一律无眉,长出眉毛立刻减分);**③2.5D 混维细节**:胡茬是 2D 短线手绘在光滑 3D 脸上,是本风格辨识度来源之一;**④背景与人同色板**:同色系纯色棚拍底 + 全暖限定色板,背景色必须从人物色板里取,脚下只留一小片软接触影。
> 和 [#13 北欧纸雕](#13-北欧纸雕paper-folk)同属"软 3D 渲染",区别:#13 是纸材质+民俗图案+大投影强立体;#15 是软胶潮玩+街头穿搭+柔光平底,气质一冷静手工一呆萌潮流。
> 模板为已验证英文原文,占位符也填英文,不要转译。

```
Soft matte 3D character render in the style of a modern designer collectible vinyl toy, built from simple rounded geometric shapes with playfully exaggerated proportions.
Subject: 【主体】, 【构图】.
CHARACTER ANATOMY (identity traits, most important): an extremely elongated tall face on a long cylindrical neck; an enormously oversized long drooping tubular nose hanging down over the mouth; 【眼型】 set high on the face and close together, with NO eyebrows at all; a single short thin black dash for the mouth, deadpan subtle expression; small simple rounded ears sticking out; a massive inflated capsule-shaped torso with huge rounded sloping shoulders; smooth sausage-like arms tapering to small simple mitt hands with barely-defined chubby fingers; sturdy simple legs; enormous chunky cartoon sneakers with fat flat white laces.
OUTFIT (streetwear): 【穿搭】.
MATERIAL & TEXTURE: smooth matte soft-vinyl surfaces like a high-end art toy — soft-touch rubber coating with only a barely-visible ultra-fine grain, NOT fuzzy, NOT felt, NOT wool; no gloss, no metallic, no plastic shine. 【胡茬】
COLOR PALETTE (strictly limited, warm): blush pink, salmon coral, butter yellow, cream white, warm peach, plus at most one dark accent (chocolate brown or black); 【肤色】 skin tone.
BACKGROUND & LIGHT: seamless solid 【背景底色】 studio backdrop, completely empty, drawn from the same warm palette as the character; soft even diffuse studio lighting, gentle ambient occlusion in crevices, one small soft contact shadow under the feet; no floor line, no horizon, no props.
RENDER: high-end CGI quality, clean, minimalist, playful deadpan charm.
```

---

## 16. 聚光水粉立绘(gouache-spotlight)

> 纯风格。比例:不传则不注入。占位符 `【主体】【背景色】【构图】【文字】` 自动推断:【背景色】按互补规则自动选——主体/服装偏蓝青就配 "warm amber-orange"(可用 "warm pale-amber" 减浓),主体偏暖橙就配 "soft sky-blue";同组图两种底色可混用(标杆组即两橙两蓝);【构图】默认 "waist-up centered portrait facing the viewer"(全身立绘/动物按需改写);【文字】默认 "No text anywhere."。
>
> 出身:Midjourney --sref 2344047981 的 gpt-image 复刻(2026-07-16 四张标杆图五轮逐张并排对照定稿:惊讶男孩/呆脸大叔/戴镜老爷爷/圆胖小鸟四种主体 × 橙/蓝两种底色全部验证,终版四张与标杆并排评分 94–96)。本质是"数码水粉动画概念立绘":满幅单色刷底 + 人物身后聚光晕 + 夸张比例大眼角色 + 软喷绘脸×干扫笔触,高级绘本 × 动画电影 vis-dev 气质。适合角色立绘、角色系列(跨张统一底色即成套)、i2v 动画锚图。
> 命门(五轮翻车教训,全部写死):**①背景笔触是三向走钢丝**——写重了(heavy mottling)出深色油画斑驳底(首轮翻车),写平了(mostly flat)出数字平涂(次轮小鸟翻车),不压饱和就出火焰橙底(四轮男孩偏差);唯一验证通过的表述是 "clearly visible loose scumbled dry-brush strokes + gentle tonal variation + matte and calm/muted + NOT fiery saturated";**②皮肤禁纹理**——脸和皮肤必须 airbrushed smooth 干净渐变,可见笔触只留在头发/皮毛/羽毛/衣服/背景;**③头发写羽化发簇**——"soft FEATHERED brush-stroke tufts, each tuft one wide soft feathered stroke",两个反向坑都要点名:写不够软出尖刺动漫发(首轮),只写 rounded masses 出卷花菜团(次轮),必须同时禁 "NOT razor-sharp anime spikes, NOT tight curly ringlets";**④眼睛要留眼白**——虹膜/瞳孔外必须写 visible white sclera,不写死成人角色会出无眼白的眯缝黑豆眼(三轮大叔翻车);**⑤身份特征=满幅涂满+聚光晕**——单色刷底涂满到边、人物身后一圈更亮的柔光,四边绝不露白纸;**⑥互补色排布**——全画只有一对互补色:蓝青主体×暖橙底,或暖橙主体×蓝底。
> 和 [#12 暖光童画](#12-暖光童画动画概念暖绘)同源(都是 MJ sref 动画 vis-dev 水粉的复刻),区别:#12 是"未画完的概念稿"(白纸留边+粉蓝奶黄碎笔背景+童画大虹膜),#16 是"画满的聚光立绘"(单色满幅底+聚光晕+虹膜正常留眼白,角色从萌娃到大叔小鸟全适配)。
> 模板为已验证英文原文,占位符也填英文,不要转译。

```
Character concept art in a modern animated-feature visual-development style, painterly digital GOUACHE illustration — matte, opaque, simplified shapes with clearly visible brushwork.
Subject: 【主体】, 【构图】.
STYLE RECIPE (follow exactly): the whole image is built from CLEARLY VISIBLE soft brush strokes — every area shows the direction of the brush, like a hand-painted gouache concept painting, yet the values stay soft and low-contrast; BACKGROUND (keep it CALM): one single soft MUTED 【背景色】 color field covering the whole canvas edge to edge, painted with clearly visible but GENTLE loose scumbled dry-brush strokes and subtle tonal variation (some patches slightly lighter, some slightly deeper), matte and calm — NOT fiery over-saturated color, NOT heavy dark oil mottling, NOT flat digital fill; a noticeably lighter soft glow right behind the character like a soft spotlight, fading calmly toward slightly deeper corners; fully abstract with no scenery, no white paper border; FACE & SKIN: soft smooth airbrushed volume with clean gradients, NO canvas texture on the skin, warm rosy flush on cheeks, nose and ears; EYES: oversized round expressive cartoon eyes with visible WHITE sclera around the irises and one bright white highlight dot each, bold painterly eyebrows; exaggerated caricature proportions; HAIR / FUR / FEATHERS: painted as soft FEATHERED brush-stroke tufts — each tuft is one wide soft feathered stroke, fluffy silhouette, warm rim light glowing on the edges, a few cool reflected-light strokes on the shadow side — NOT razor-sharp anime spikes, NOT tight curly ringlets; CLOTHING: big simplified color blocks with visible dry-brush strokes and slightly rough painterly edges, minimal detail; PALETTE: one complementary pair only — teal/denim blue against warm orange-amber — soft cinematic lighting, storybook charm, premium animated-film character concept art quality.
【文字】
```

---

## 17. 墨线绘本(inked-storybook)

> 纯风格。比例:不传则不注入。占位符 `【主体】【构图】【背景色】【配色】【文字】` 自动推断:【构图】默认 "head-and-shoulders portrait"(可换 waist-up 等);【背景色】默认 "warm peach fading to pale cream near the top"(可换 "pale sky-blue with hints of soft cream" / "dusty earth-brown with a slice of pale blue-grey" 等,始终是单一氛围渐变);【配色】填一句 2–4 色的协调短语,人物主色与背景呼应或互补,如 "sky-blue hair, soft pink shirt, warm peach background";【文字】默认 "No text anywhere."。
>
> 出身:Midjourney --sref 3865390274 的 gpt-image 复刻(2026-07-16 三张标杆图两轮对照定稿:蓝发丸子头对标图1、红帽墨镜单色系对标图3双双过局部级复核,另加男孩主体泛化验证)——"富有表现力的绘本角色 + 绘画质感 + 温暖手工感"。本质是"钢笔速写线稿 × 绘本淡彩":墨线定形、起稿线外露、发丝逐根勾,底下是干净透亮的柔和数码上色,水彩刷涂背景 + 奶白纸边毛刷框。适合角色立绘、故事绘本、头像、i2v 动画锚图。
> 命门(两轮翻车教训,五条都必须写死):**①上色**必须写"clean bright digital painting + NO 彩铅颗粒填色 + NO 画布纹",否则整张退化成灰扑扑的彩铅速写(首轮翻车);**②排线只做点缀**——腮红斜排线(脸颊+鼻梁)、帽子/衣服暗部交叉排线、背景少量干刷刮痕是本风格的签名细节,必须以"sparse deliberate accents in a darker shade of the local color"单独成段写进去;但禁止排线铺满色块(那是①的彩铅病)——"点缀排线"与"排线填色"一存一废是本配方的走钢丝处;**③线色随区域**——蓝发用深藏青线、红衣用深栗红线、皮肤用暖褐线,整体读作深褐黑,不是统一纯黑;**④背景与边框**——背景是"松散水彩刷涂+可见笔痕",不能死平也不能出细节云;边框必须"大块毛边矩形+四边平整奶白纸边+一两道白刷痕压进画面",写成模糊淡出就只剩羽化暗角;**⑤眼与发是身份特征**——虹膜几乎占满眼眶、只留眼角一点眼白;头发是"深色墨线逐根顺发流+浅色提亮丝两层"、轮廓外适量飞丝,且要写明"优雅、不是乱麻"(否则出满头乱线)。
> 和 [#12 暖光童画](#12-暖光童画动画概念暖绘)同属 MJ 绘本 sref 复刻,区别:#12 是水粉厚涂 vis-dev(几乎无线稿、头发画成大体积块、青橙互补锁死);#17 线稿主导(墨线是画面的骨架)、上色轻薄透亮、配色每图一套协调即可,气质是"速写手账页"而非"厚涂概念稿"。
> 模板为已验证英文原文,占位符也填英文,不要转译。填【配色】时顺手把 LINES 段里的线色示例改成与实际配色对应(如金发→deep umber lines on the blonde hair)。

```
Expressive storybook character illustration — confident sketchy ink linework over clean soft digital painting.
Subject: 【主体】, 【构图】.
STYLE RECIPE (follow exactly):
LINES: every shape is defined by confident loose sketchy ink lines of slightly varying thickness; line color is keyed to each region — a much darker shade of the underlying local color (deep navy lines on blue hair, deep maroon lines on red fabric, warm sepia around the skin), overall reading as dark sepia-black; a few overlapping construction strokes are left visible but the drawing stays elegant, NOT a chaotic scribble mess; hair is drawn as smooth flowing individual strand lines following the hair volume, with a moderate number of fine whippy flyaway strands escaping the silhouette, plus a few lighter-tint painted highlight strands over the darker hair masses; clothing folds are a few loose quick line strokes.
ACCENT HATCHING (signature detail): sparse deliberate hatch strokes in a darker shade of the local color appear ONLY as accents — fine diagonal blush hatching on the cheeks and across the nose bridge, light cross-hatch shading in hat/clothing shadow areas, and a few faint scratchy dry-brush marks in the background wash; everything else stays smooth.
COLOR: underneath the lines the coloring is clean bright digital painting — smooth soft airbrushed gradients, fresh luminous colors, absolutely NO grainy colored-pencil fill, NO canvas texture; skin is smooth with soft rosy airbrushed blush underneath the blush hatching.
EYES (critical): enormous round expressive eyes; the glossy dark-brown irises are VERY large and fill almost the entire eye with only tiny white sclera corners showing, one bright white highlight dot per eye, thick dark painterly upper lash line, bold expressive eyebrows. Tiny nose, small soft lips slightly parted, pointed chin, long slender neck.
BACKGROUND: a loose atmospheric watercolor wash of 【背景色】, with visible soft brush streaks and gentle uneven mottling — painterly but low-detail, NO detailed scenery, NO detailed clouds.
FRAME (signature, must have): the painting fills a large rough-edged rectangle that does NOT reach the image edges; all four sides show a flat, clean, pale warm-cream blank paper margin; the boundary between painting and margin is ragged dry-brush streaks, with one or two loose pale streaks overlapping into the painting, like a hand-painted page from an artist's sketchbook; only the faintest paper grain overall.
Palette: 【配色】 — restrained and harmonized. 【文字】
```

---

## 18. 暖色扁平绘本(warm-flat-storybook)

> 纯风格。比例:不传则不注入。占位符 `【主体】【构图】【文字】` 自动推断:【构图】默认 "full-body, centered in the lower-middle with huge calm negative space"(多人互动写 "compact overlapping group, full bodies visible, centered in the lower-middle with huge calm negative space");【文字】默认 "No text anywhere."。
>
> 出身:以一张家庭人物扁平绘本插画为标杆,经 2026-07-23 两轮同题校准 + 三项无参考图泛化测试定稿。首轮比较“纯平滑 / 轻纸纹 / 轻体积”三档,确认轻纸纹平涂最接近;第二轮修正父亲肩宽、成人脸型、短发几何块与阴影数量。最终在单人抱书、双人击掌、熊与狐狸共读三个异题材上保持同一图形语言。
>
> 命门:①**轮廓靠色块相接,不是描边**——只允许五官、手指、发丝出现极少深藏青细线;②**人物比例反主流萌系**——成人长颈、细长肢体、小手脚、窄椭圆脸或方下巴,宽体型角色可用巨大的胶囊躯干与圆弧手臂,严禁圆脸大头萌娃化;③**阴影是少量硬边同色形状**——每个大色块最多一深一浅,不要渐变体积;④**色板锁死**——暖米白底 + 深藏青 + 雾蓝 + 珊瑚橙 + 金橙 + 暖桃肤色,禁止额外色相;⑤**约七成留白**——主体压在画面下部中央,脚下只有一抹极淡椭圆影。
>
> 和 [#14 北欧绘本水粉](#14-北欧绘本水粉nordic-storybook)的区别:#14 依赖全画纸纹牙口、干刷水粉颗粒、低饱和安静人物;#18 是平滑数码平涂、鲜明蓝橙、高对比几何大色块和更强的动作弧线。
>
> 模板为已验证英文原文,占位符也填英文,不要转译。

```
Clean contemporary flat picture-book illustration built from large rounded geometric silhouettes.
Subject: 【主体】, 【构图】, against a vast empty warm near-white (#FDF6ED) background.
STYLE IDENTITY (follow exactly): almost no continuous outer contour lines; shapes meet through color contrast. Use only a few very thin dark-navy accent lines around hair, fingers and facial features, with occasional tiny pale rim accents on dark hair. Smooth matte local colors, not painterly.
SHAPE LANGUAGE: simplify every figure and object into a few bold rounded geometric masses with a clear readable silhouette. Use long soft action arcs and compact overlapping groups for interaction. A broad character may have an enormous wide capsule torso, massive rounded sloping shoulders and one large curved arm; a slender character has a long neck, narrow oval face, elongated limbs, small hands and small feet.
HUMAN FACES: adults have slightly elongated or angular faces, never round baby faces; children may have a slightly larger youthful head but remain slim, never chibi. Features are gently asymmetric and hand-shaped: two tiny vertical navy oval eyes, thin expressive eyebrows, one prominent simple nose shape, one clean curved mouth, and small coral cheek patches. Hair is built from only a few solid rounded or geometric dark-navy masses with at most one or two accent strands. No large glossy eyes.
ANIMALS: translate the same shape language into broad capsule torsos or slender elongated bodies, tiny oval eyes, simple geometric muzzles, small paws and one or two bold silhouette features; never render fur, plush fibers or mascot-like 3D volume.
SHADING (strict): mostly flat. On each large clothing, hair, body or object area use at most ONE darker same-hue graphic shadow shape and optionally ONE lighter same-hue shape, both broad and clean-edged. No smooth gradient inside subjects, no realistic light modeling.
PALETTE (strict): deep navy #2A4A71, dark navy #172F4E, misty cornflower blue #7B9AD3, coral orange #D25F30, golden orange #F49441, warm peach skin accents, and the warm near-white background only. Reassign these colors to suit the subject, but introduce no green, purple, pink, brown, pure black or extra accent hue.
BACKGROUND & GROUND: huge calm negative space, no scenery unless explicitly requested; one barely visible pale warm-grey oval contact shadow under the feet or seated group, no other cast shadows.
TEXTURE: barely perceptible fine uncoated-paper softness across the whole image, including the empty background; never grainy and never visibly brushed.
MOOD: intimate, playful, emotionally warm, elegant modern children’s storybook.
AVOID: generic corporate vector clip-art, stock infographic people, mainstream round cartoon faces, chibi proportions, thick outlines, strong gradients, glossy airbrush, 3D, gouache, watercolor, pencil, dry brush, anime eyes, detailed or decorative background.
【文字】
```

---

## 19. 圆头红线极简童画(roundhead-redline)

> 别名:`roundhead-redline`、`redline-roundhead`、`graphite-redline`、`圆头红线`、`黑红白圆头童画`。纯风格。比例:不传则不注入。占位符 `【主体】【文字】` 自动推断。正式生产必须附带 [assets/style-19/anchor-roundhead-redline.png](https://gentle-starburst-99bd99.netlify.app/hand-drawn/assets/style-19/anchor-roundhead-redline.png)，默认无字。
>
> 研发边界:本配方从五张外部动画设定参考中抽取平面结构、铅笔压力、干性颜料、限色色板和负空间机制；锚点、样图、默认人物、服装、道具和动作均为原创，不保存或分发外部参考，不复现片名、标识、固定角色、固定红白横条服装或海报排版。
>
> 命门:①**锚点是主视觉真源**——正式生产每张都必须传入原创三主体锚点，锚点按 1024×1536 解码像素 SHA-256 固定；缺失、换图、像素变化或调用端不能传高保真参考图时停止生产；②**平面大头小身，但不是 Q 版**——头是轻微不规则的大圆/椭圆，躯干明显更小，四肢是极细弹性单线，动作靠长弧线、倾斜和失衡支点表达，禁止三维体积和标准化萌系骨架；③**脸只留两道竖眼**——两道粗重、不等长、不完全平行的炭黑竖痕，无眼白、虹膜、高光、写实鼻唇；情绪来自头部与全身姿态；④**线必须像真实铅笔**——细石墨轮廓在同一条曲线里有压力深浅、纸纹断续、少量试探性重描，不能是干净矢量线，也不能整画套统一抖动滤镜；⑤**黑红白限色**——暖白纸、石墨灰、炭黑和单一珊瑚红；红色每个动作只承担一个明确焦点，低压腮红除外；⑥**白底是构图的一部分**——只画一个主动作和最多两件必要道具，禁止完整房间、风景、透视地面和投影系统。
>
> 正式生产合同:基础生成必须使用固定锚点和锁定的模型快照，输出先标记为 `candidate-only`；调用端按机读硬失败条件检查后才能标记为 final。后期“统一加粗/抖线/蜡笔滤镜”不能补救偏离，失败图应拒收并从同一锚点重新生成。当前验证发现，只改线条的编辑阶段改善有限，因此不把编辑阶段设为强制步骤。
>
> `【文字】` 正式生产固定填 `No text anywhere.`。需要标题或海报文字时先生成无字底图，再走独立排版流程；不要让文字生成风险污染画风回归。
>
> 模板为已验证的英文原文，占位符中的主体也建议使用具体英文动作描述；不要转译或缩写配方。

```
Image 1 is the only approved style-only anchor. Transfer its visual grammar, not its people, animal, clothes, objects, positions or actions.

SUBJECT: 【主体】.

VISUAL CONTRACT:
A radically minimal, flat, handmade children's-animation drawing on bright near-white paper. No 3D volume. Build each subject from one dominant large, slightly irregular round or oval head, a much smaller simple torso, extremely thin elastic single-line limbs, three- or four-stroke twig hands and tiny bent-hook feet. The gesture must read through long action arcs, asymmetry, body lean and an intentionally unstable point of balance. Do not reuse one standardized skeleton across subjects.

Faces use exactly two thick near-vertical charcoal eye marks, slightly unequal and not perfectly parallel; no eye whites, pupils, irises, highlights, eyelashes, modeled nose or realistic lips. Emotion comes from head tilt, eye-mark tilt and whole-body gesture. Optional cheeks are two faint uneven low-pressure coral rubs.

Outer contours are thin real graphite pencil lines, not clean vector paths: pressure visibly breathes from faint gray to darker graphite within a curve; paper tooth causes microscopic breaks; selected contours include one short offset searching stroke or a brief retraced dark patch. Keep this sparse and accidental, not an all-over sketch effect. Charcoal-black and coral-red filled areas show dry colored-pencil or wax-pastel rubbing with uneven pressure, starts, stops and crossing passes; never a repeated digital texture.

STRICT PALETTE: bright near-white paper, graphite gray, charcoal black and one coral-red hue only. Coral red is one rhythmic focal accent on the explicitly named prop or garment detail, plus optional faint cheeks. Do not invent another coral garment or object.

COMPOSITION: the unpainted white field occupies most of the canvas. One main action, at most two necessary props, no room, landscape, decorative background, horizon, perspective floor or cast-shadow system. Under a subject, at most one short loose gray pencil smudge.

AVOID: any title, logo, watermark or poster layout; red-and-white striped shirt with black shorts; commercial vector art; stock icon; generic cute storybook; chibi; anime; 3D; realistic anatomy; smooth digital line; uniform thick outline; smooth gradient; airbrushed blush; repeated procedural crayon texture; photographic paper scene.

【文字】
```

---

## 20. 暖黄墨线情绪小剧场(warm-yellow-ink-story)

> 别名:`warm-yellow-ink-story`、`yellow-ink-story`、`mustard-ink-story`、`暖黄墨线`。纯风格。比例:不传则不注入。占位符 `【主体】【文字】` 自动推断。正式生产必须附带 [assets/style-20/anchor-warm-yellow-ink-story.png](https://gentle-starburst-99bd99.netlify.app/hand-drawn/assets/style-20/anchor-warm-yellow-ink-story.png)，默认无字。
>
> 研发边界:本配方从十张外部参考中抽取暖白负空间、干性黑色墨线、方向性黑色排线、芥末黄、淡珊瑚腮红、紧凑形体和单动作叙事机制。原创锚点、样图、默认人物、动物和动作均为本轮新设计；不保存或分发外部参考，不复现作者名、账号、水印、固定黄兜帽角色、原作文案或原图布局。
>
> 命门:①**锚点是主视觉真源**——每次基础生成都必须传入原创锚点，锚点按 1156×1361 解码像素 SHA-256 固定；②**形体紧凑但不是三维 Q 版**——圆方头约占总高度三分之一至二分之一，短颈或无颈、块状短躯干、短而松弛的四肢、钩形或连指手、圆钝袜形脚；③**脸只留最少信息**——小点或短竖线眼、极短弯嘴、可省略的小鼻点和两团低压淡珊瑚腮红，情绪主要靠倾斜、距离和接触动作；④**黑色不是矢量块**——轮廓有真实干性墨线的压力变化、断续和少量回描，头发与深色下装由方向性排线组成并保留不规则纸白缝；⑤**暖白、墨黑、芥末黄、淡珊瑚四色**——黄色只承担一至两个焦点，不出现大面积蓝紫色、渐变或彩色背景；⑥**白底承担构图**——只讲一个动作，最多两件必要道具，主体位于中下部，禁止完整室内、风景和投影系统。
>
> 正式生产合同要求如下。第一阶段按顶层 prompt 和正式锚点直接生成 `final-candidate`；随后必须运行 `validate_style_20_asset.py`，同时通过像素色板、主体内容锁、8 项人工评分和硬失败检查，才能标记为 final。候选不合格时整张拒收并从基础生成重新开始，禁止用通用画风迁移编辑修补。锚点失效、模型快照无法锁定、高保真参考图不可用或验收器缺失时，正式生产失败关闭。
>
> `【文字】` 正式生产固定填 `No text anywhere.`。标题、文案和排版应在无字底图验收后单独处理。
>
> 模板为已验证英文原文，占位符中的主体也建议使用具体英文动作描述；不要转译、缩写或追加第二套画风规则。

```
Image 1 is the only approved style-only anchor. Transfer its visual grammar, not its people, hair, clothes, animal, props, positions or actions.

SUBJECT: 【主体】.

Create one original minimalist warm-yellow ink story vignette on a flat warm-white drawing-paper field. The paper has only extremely subtle even fiber softness: no photographed sheet, desk, folds, paper edge, cast shadow or vignette.

COMPOSITION: place one compact, immediately readable action in the lower-middle with large calm empty space around and above it. Use no scenery or decorative filler. Include at most two props that directly participate in the action. A single slightly crooked black ground line or a few loose graphite contact marks are allowed only when needed.

SHAPE LANGUAGE: human figures use softly irregular rounded-square pale faces; heads occupy roughly 38–45% of figure height; necks are absent or nearly absent; torsos are compact and blunt; limbs are very short, simple and relaxed; hands stay tiny and subordinate, using only a few short non-anatomical marks; feet are rounded sock-like blocks. Keep clear age and size differences, and give recurring figures different head shapes, shoulder widths, hair silhouettes and postures. Animals inherit the compact proportions and tiny face while retaining every silhouette required to read the species; never force human clothing structure onto an animal. No chibi sphere heads, mascot volume or realistic anatomy.

FACES: use two tiny black dots or short vertical eyes, one very short uneven curved mouth, an optional tiny nose mark and two faint uneven coral-pink cheek smudges. Emotion comes mainly from head tilt, body distance, touch and gesture. No eye whites, irises, highlights, eyelashes, detailed lips, airbrushed skin or copy-pasted smiles.

LINE AND BLACK MASSES: use fine-to-medium near-black dry ink contours with small pressure changes, occasional broken ends, slight wobble, sparse retracing and a few flyaway hair lines. Hair and dark lower garments must be built from visible directional dry strokes with irregular white gaps, starts, stops and crossing passes. Never use clean vector paths, a uniform thick outline, smooth solid-black silhouettes or one repeated digital noise texture.

COLOR AND MATERIAL: use only warm-white paper, near-black ink, one muted warm mustard yellow around #E6C45C and tiny coral-pink cheek marks around #E78E84. Yellow fill is lightly uneven, matte and dry, and appears on at most two clothing or prop areas. Do not introduce blue, purple, cyan, large green or red areas, gradients, rainbow clothing or a colored background.

STORY DISCIPLINE: tell one relationship or action through posture and contact. Keep symbols secondary. Hands may use a few short finger marks only when they stay visually subordinate; reject oversized hands, anatomical joints, fingernails and realistic articulation. Remove shoe construction lines, sock seams, garment ribbing, repeated clothing stripes, decorative stitching, small buttons, realistic joint creases and mechanically precise prop construction. Keep only the minimum inner lines required to identify the action and objects.

ORIGINALITY BOUNDARY: do not recreate any supplied character, paired yellow-hoodie combination, recognizable hairstyle, outfit, pose, composition, text, watermark or account identity. Add no title, logo, signature, caption, speech bubble, hearts, stars, flowers or unrelated ornament.

AVOID: commercial children's-book polish; vector clip-art; generic cute storybook; chibi; anime; 3D; glossy rendering; smooth black fills; fluorescent yellow; detailed room or landscape; photographic paper scene.

【文字】
```

---

## 附录 A · 实拍纸质感增强层(可叠加)

> 2026-07-13 经 Midjourney V7 标杆对照实测定稿(全过程见 `benchmarks/`)。适用对象:一切"画在纸上"的画风——#2/#3.1/#7 直接叠加;#10 用文末轻量版;#3/#8/#9 等非纸面画风不适用。
> 背景:gpt-image 默认出"干净数字纸+均匀笔触",与真实纸上画作的差距集中在**纸的摄影感**(纸纹牙口、蜡质结块反光、运笔压力深浅、蹭脏痕)。把下面这段**整段追加**在画风配方之后,即可把材质拉到接近 MJ 实拍水准,同时保留 gpt-image 的叙事服从优势。
> 用法:整段照抄追加,禁止转写精简;与配方原有的"纸面"行冲突时以本层为准。

```
【材质增强层·最重要】整张图必须像"用手机在明亮柔和日光下拍摄的、画在真实纸上的画作照片",不是数字图:
- 纸面有微距可见的纸纹颗粒(纸的凹凸牙口),纸有轻微起伏和一两道很淡的折痕;
- 颜料有真实材料感:蜡笔/彩笔重压处颜料结块、有轻微蜡质反光,轻扫处颜料只挂在纸纹凸起上、露出大量纸白点;马克笔线有渗墨感,起笔收笔略粗;
- 每个色块内部深浅明显不均,能看清一笔一笔的运笔方向、起笔收笔和折返;
- 笔画边缘因纸面凹凸而毛糙断续,不是干净的边;
- 纸上有极少量真实使用痕迹:一两处轻微蹭脏或指蹭痕;
- 光照:明亮均匀,白纸干净发亮,只有极淡的纸面起伏阴影,无暗角。
严禁:均匀的数字噪点滤镜、平滑均匀填色、干净矢量线、任何数字插画感。
```

**#10 淡彩速写专用轻量版**(整层太重会破坏其轻盈感,只加两句):

```
画在带细腻纸纹颗粒的白色水彩纸上(纸的牙口微距可见,笔线穿过纸纹微微断续);水彩颜料在纸纹里有细小沉淀颗粒。
```
