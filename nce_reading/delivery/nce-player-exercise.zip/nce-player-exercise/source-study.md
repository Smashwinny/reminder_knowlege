# 固定源码研究与观测

## 一、身份与来源

仓库：<https://github.com/iChochy/NCE>

提交：`0a92ab5af50e2898a104f15eac7adb00f17bd96b`，提交时间 `2026-08-26T15:23:55+08:00`，消息 `toast`。

固定 [README](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/README.md) 描述静态 HTML/CSS/JS 播放器，与课本资源分离。依赖图中没有 npm 包；本实验不需要账户、安装、服务器或外部服务。

[官方目录](https://nce.ichochy.com/data.json) 在 2026-10-05 09:47 UTC 前后通过普通 HTTP 只读获取；SHA-256 为 `858c86fc9b094c6ed1f68c1410d3739736cf5e2d07e323cc048321bf5616b64f`，与固定提交的 data.json 相同。目录有八个记录：NCE1–4 和 NCE1(85)–NCE4(85)。本研究没有跟随目录加载任何 book.json、LRC 或音频资源。

`REFACTORING.md` 中部分架构说明已陈旧，如旧文件名与当前源码不符；本实验依据固定提交实际模块图，不依据该文件推定实现。

## 二、真实解析路径

[LRCParser.js](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/js/utils/LRCParser.js#L12-L77)

- parse 支持 1–2 位分钟、2 位秒、2–3 位小数；秒必须小于 60
- 前后空白被去除；空行和以 # 开头的行忽略
- 小数部分按十进制秒处理；减去传入偏移后四舍五入至毫秒
- 英文为空则丢弃；中文可省略；额外的竖线段不进入 english/chinese 字段，但保留于 fullText
- 不支持标准 metadata/offset 标签，也不展开一行多个时间标签；第二个时间标签会成为正文的一部分
- 结果按时间排序；本次运行中重复时间保留输入顺序
- 当前行查找从数组尾部扫描，条件是 currentTime >= time，所以精确边界选新行，重复时间选最后一条
- 句子尾部取下一条的时间；最后一条取 max(audioDuration, startTime + 0.1)

## 三、偏移与重复时间的具体结果

[config.js](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/js/config.js#L21-L25) 配置 TIME_OFFSET 为 0.3；[ReadingSystem.loadUnitByIndex](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/js/ReadingSystem.js#L210-L214) 把它传入解析器。

原创输入的原始时间排序后是 `[0.1, 1.25, 2.5, 2.5, 4.125, 6]`；应用偏移后的真实解析输出是 `[-0.2, 0.95, 2.2, 2.2, 3.825, 5.7]`。

- 解析器保留 -0.2，不自行归零；因此 t=0 已匹配第一行
- 精确 t=2.2 时正常时间线选索引 3，即第二个重复项
- 索引 2 的句子区间为 [2.2, 2.2]，长度为零
- 在单句点读模式点击索引 2 后，首个 t=2.2 tick 即触发回到 2.2 并暂停
- 最后一行在给定总长 8 秒时结束于 8；未提供时长时，解析器返回 5.8

这些都是固定版本真实函数的观测结果，没有自动修复，也不代表推荐的数据格式。

## 四、真实组件链

[LyricsView](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/js/ui/LyricsView.js#L123-L141) 的点击/Enter/空格委托调用 onActivate。该回调由真实 [ReadingSystem](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/js/ReadingSystem.js#L319-L373) 绑定，依次进行高亮、seek、play 和进度保存。

- 正常模式根据媒体 currentTime 更新高亮
- click 模式锁定所点句子，到句尾后 seek 回句首并 pause
- one 模式同样回到句首，但不调用 pause
- 上游 AudioController 的 timeupdate 经过约 33.3 毫秒的节流，随后触发 ReadingSystem 的实际私有时间线方法；实验以每次 40 毫秒的替身时钟推进
- 直接 AudioController.seek 更新进度条，但不会立即调用 onTick；在正常模式下，高亮直到下一个 audio tick 才同步
- LyricsView 高亮会移除旧 active 类、添加新 active 类，并在阈值外请求 scrollIntoView；本实验只验证调用和类名，未观察实际视觉效果
- 原文与对应中文进入 HTML 字符串前由真实 escapeHtml 转义

## 五、seek 的时长条件

[AudioController.seek](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/js/player/AudioController.js#L102-L107) 与 [clamp](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/js/utils/helpers.js#L6)

- 已知有限正时长 8 秒：seek(-0.2) 写入 0；seek(99) 写入 8
- 时长为 0：seek(-0.2) 用请求值作为 max，从而向替身 currentTime 写入 -0.2。这是上下界反转的算术观测，不能据此声称真实 HTMLMediaElement 会接受该值
- 非有限 seek 输入会被忽略
- 恢复进度在已知时长情况下最多到 duration - 0.05，防止恢复到结束点
- 设置 playbackRate 只改变速率属性，没有改写当前时间或 LRC 时间。真实倍速播放效果未测试；LRC 仍属于媒体时间坐标

## 六、验证强度与未覆盖项

已验证：15 个上游文件的 SHA-256、六句原创输入、真实函数输出、实际私有回调链、受控事件/属性/类名与本地内存存储。统一复跑 72/72 通过，详见 results/initial.json。断言的实际值与期望值在记录时深复制，七份随包 JSON 中所有通过项的值均已再次核对。

没有验证：真实音频解码或发声、浏览器 HTML 布局、触摸交互体验、滚动动画、自动播放限制、媒体 seek 精度、平台兼容性、CORS、真实目录/课程获取、预加载、真实存储生命周期和网络取消竞争。没有启动或重试浏览器/file/localhost/Chromium 预览路径。

原始 repo 未改动。测试使用仅含所需模块的副本；模块本身保持字节一致。没有修改、提交或推送上游代码。

## 七、软件与课程权利的区别

[LICENSE](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/LICENSE) 为 MIT，Copyright (c) 2025 iChochy；附带原样许可证。

[README 的版权说明](https://github.com/iChochy/NCE/blob/0a92ab5af50e2898a104f15eac7adb00f17bd96b/README.md#L132-L137) 表明内容来源于互联网、作者不拥有内容版权，并建议购买正版教材/音频。本实验不把软件许可证当作教材、翻译或录音授权。
