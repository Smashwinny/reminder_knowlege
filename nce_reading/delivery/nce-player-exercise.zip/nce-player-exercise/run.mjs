/**
 * Original test harness, not a replacement player.
 * It imports unchanged upstream modules. Only ReadingSystem.init is overridden.
 * DOM, audio, storage, wall-clock ticks and timers are controlled doubles.
 * No browser is started and no media is downloaded, decoded, or heard.
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const base = dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
function option(name, fallback) {
  const i = argv.indexOf(name);
  return i === -1 ? fallback : argv[i + 1];
}
const group = option('--group', 'all');
const groups = ['integrity', 'parser', 'timeline', 'controller', 'view', 'integration'];
if (group !== 'all' && !groups.includes(group)) throw new Error(`Unknown group: ${group}`);
const output = resolve(base, option('--output', 'results/latest.json'));
const manifest = JSON.parse(readFileSync(resolve(base, 'source-manifest.json'), 'utf8'));
const fixture = readFileSync(resolve(base, 'fixtures/original.lrc'), 'utf8');
const startedAt = new Date().toISOString();
const report = {
  schema: 1, startedAt, node: process.version, group, argv,
  source: manifest,
  scope: 'Controlled component simulation using actual upstream modules; not full-player end-to-end, browser, layout, or playback testing.',
  interventions: [
    'ReadingSystem subclass overrides only init() to suppress catalog/book boot.',
    'DOM double recognizes only the exact lyric-line wrapper emitted by upstream render; it is not a browser HTML parser.',
    'Audio double records currentTime, duration, play/pause/load and emitted events; it does not decode or play audio.',
    'Map-backed storage, deterministic Date.now and queued-but-not-automatically-fired timers replace browser state.',
    'fetch and global Audio construction throw; source modules are loaded only from local unchanged files.'
  ],
  fixture, fixtureSha256: createHash('sha256').update(fixture).digest('hex'),
  tests: [], traces: {}, networkAttempts: [],
  limitations: ['No actual audio downloaded, generated, decoded or heard.', 'No browser opened, localhost server started or HTML visual inspection performed.', 'No rendering quality, media seek precision, autoplay policy, CORS, fetch integration, network cancellation or real event cadence verified.']
};
let currentGroup = 'integrity';
function check(name, actual, expected, context = {}) {
  try {
    assert.deepStrictEqual(actual, expected);
    report.tests.push(structuredClone({ group: currentGroup, name, pass: true, actual, expected, ...context }));
  } catch (error) {
    report.tests.push(structuredClone({ group: currentGroup, name, pass: false, actual, expected, error: error.message, ...context }));
  }
}
function runGroup(name, fn) {
  if (group !== 'all' && group !== name) return;
  currentGroup = name;
  try { fn(); }
  catch (error) { report.tests.push({ group: name, name: 'Unexpected group exception', pass: false, error: error.stack }); }
}

// Verify bytes before importing. An integrity mismatch stops any source execution.
const verifiedHashes = {};
for (const [path, expected] of Object.entries(manifest.files)) {
  const actual = createHash('sha256').update(readFileSync(resolve(base, 'upstream', path))).digest('hex');
  if (actual !== expected) throw new Error(`Upstream integrity mismatch: ${path}`);
  verifiedHashes[path] = actual;
}
runGroup('integrity', () => {
  for (const [path, expected] of Object.entries(manifest.files)) check(`Unchanged ${path}`, verifiedHashes[path], expected);
  check('Exactly 14 upstream JavaScript modules', Object.keys(verifiedHashes).filter(x => x.endsWith('.js')).length, 14);
});
const { LRCParser } = await import('./upstream/js/utils/LRCParser.js');
const { AudioController } = await import('./upstream/js/player/AudioController.js');
const { LyricsView } = await import('./upstream/js/ui/LyricsView.js');
const { ReadingSystem } = await import('./upstream/js/ReadingSystem.js');
const { CONFIG } = await import('./upstream/js/config.js');

class EventDouble {
  constructor() { this.listeners = new Map(); }
  addEventListener(type, handler, options = {}) {
    const list = this.listeners.get(type) || [];
    list.push({ handler, options }); this.listeners.set(type, list);
  }
  removeEventListener(type, handler) {
    this.listeners.set(type, (this.listeners.get(type) || []).filter(x => x.handler !== handler));
  }
  emit(type, detail = {}) {
    const event = { type, target: this, defaultPrevented: false, preventDefault() { this.defaultPrevented = true; }, ...detail };
    for (const record of [...(this.listeners.get(type) || [])]) {
      if (record.options?.signal?.aborted) continue;
      record.handler(event);
      if (record.options?.once) this.removeEventListener(type, record.handler);
    }
    return event;
  }
}
class ClassDouble {
  constructor() { this.items = new Set(); }
  add(...names) { names.forEach(x => this.items.add(x)); }
  remove(...names) { names.forEach(x => this.items.delete(x)); }
  contains(name) { return this.items.has(name); }
  toggle(name, force) {
    const value = force === undefined ? !this.items.has(name) : Boolean(force);
    value ? this.items.add(name) : this.items.delete(name); return value;
  }
}
class ElementDouble extends EventDouble {
  constructor() {
    super(); this.classList = new ClassDouble(); this.dataset = {}; this.attributes = {};
    this.children = []; this.parent = null; this.textContent = ''; this._html = '';
    this.scrollTop = 0; this.scrollCalls = []; this.styleValues = {};
    this.style = { setProperty: (key, value) => { this.styleValues[key] = value; } };
    this.rect = { top: 0, bottom: 200, height: 200, left: 10, width: 100 };
  }
  set className(value) { this.classList = new ClassDouble(); value.split(/\s+/).filter(Boolean).forEach(x => this.classList.add(x)); }
  get className() { return [...this.classList.items].join(' '); }
  set innerHTML(value) {
    this._html = value; this.children = [];
    // Deliberately narrow double for wrappers emitted by the unchanged LyricsView.
    for (const match of value.matchAll(/class="lyric-line" data-index="(\d+)" data-time="([^"]+)"/g)) {
      const child = new ElementDouble(); child.className = 'lyric-line';
      child.dataset = { index: match[1], time: match[2] };
      const top = 20 + Number(match[1]) * 20;
      child.rect = { top, bottom: top + 20, height: 20, left: 10, width: 100 };
      this.appendChild(child);
    }
  }
  get innerHTML() { return this._html; }
  appendChild(child) { child.parent = this; this.children.push(child); return child; }
  replaceChildren(...children) { this.children = []; children.forEach(x => this.appendChild(x)); }
  setAttribute(key, value) { this.attributes[key] = value; }
  removeAttribute(key) { delete this.attributes[key]; if (key === 'src') this.src = ''; }
  closest(selector) { return selector.startsWith('.') && this.classList.contains(selector.slice(1)) ? this : this.parent?.closest(selector) || null; }
  contains(candidate) { for (let p = candidate; p; p = p.parent) if (p === this) return true; return false; }
  querySelectorAll(selector) { return this.children.filter(child => selector === '.lyric-line' && child.classList.contains('lyric-line')); }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  getBoundingClientRect() { return this.rect; }
  scrollIntoView(options) { this.scrollCalls.push(options); }
  setPointerCapture(id) { this.pointerId = id; }
  releasePointerCapture(id) { if (id === this.pointerId) this.pointerId = null; }
  remove() { if (this.parent) this.parent.children = this.parent.children.filter(x => x !== this); }
}
class AudioDouble extends ElementDouble {
  constructor(duration = 8) {
    super(); this.currentTime = 0; this.duration = duration; this.paused = true;
    this.playbackRate = 1; this.loop = false; this.src = ''; this.calls = [];
  }
  play() { this.calls.push({ action: 'play', time: this.currentTime }); this.paused = false; this.emit('play'); return Promise.resolve(); }
  pause() { this.calls.push({ action: 'pause', time: this.currentTime }); const changed = !this.paused; this.paused = true; if (changed) this.emit('pause'); }
  load() { this.calls.push({ action: 'load', src: this.src }); this.emit('loadstart'); }
}
const originalGlobals = Object.fromEntries(['document', 'window', 'location', 'localStorage', 'fetch', 'Audio', 'setTimeout', 'clearTimeout'].map(k => [k, globalThis[k]]));
const originalNow = Date.now;
let simulatedNow = 1700000000000;
let timerId = 0;
const timers = new Map();
const storage = new Map();
const registry = new Map();
const doc = new EventDouble();
doc.body = new ElementDouble(); doc.hidden = false;
doc.querySelector = selector => registry.get(selector) || null;
doc.querySelectorAll = () => [];
doc.createElement = () => new ElementDouble();
globalThis.document = doc;
globalThis.window = new EventDouble();
globalThis.location = { hash: '' };
globalThis.localStorage = { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, String(value)) };
globalThis.fetch = (...args) => { report.networkAttempts.push({ kind: 'fetch', args }); throw new Error('Network forbidden in component simulation'); };
globalThis.Audio = class { constructor() { report.networkAttempts.push({ kind: 'Audio' }); throw new Error('Uncontrolled Audio construction forbidden'); } };
Date.now = () => simulatedNow;
globalThis.setTimeout = (fn, delay) => { timers.set(++timerId, { fn, delay }); return timerId; };
globalThis.clearTimeout = id => timers.delete(id);
const parsed = LRCParser.parse(fixture, CONFIG.PLAYER.TIME_OFFSET);
report.traces.parsedFixture = parsed;
function tick(audio, time) { simulatedNow += 40; audio.currentTime = time; audio.emit('timeupdate'); }
function active(view) { return view.lineEls.flatMap((line, index) => line.classList.contains('active') ? [index] : []); }

try {
  runGroup('parser', () => {
    check('Six original records parsed', parsed.length, 6);
    check('Sorted source order including equal timestamps', parsed.map(x => x.english), [
      'A small bell rings.', 'Place the blue tile here.', 'The green lamp glows.',
      'The red tile stays.', 'Turn the dial once.', 'Our tiny test is done.'
    ]);
    const invalid = ['# comment', '', '[00:01]Missing fraction.', '[00:01.1]One fraction digit.', '[00:60.00]Invalid seconds.', '[100:00.00]Three minute digits.', '[00:01.0000]Four fraction digits.', '[00:02.00] | Only right side.', '[ar:Original test]', '[offset:500]'].join('\n');
    check('Unsupported formats, metadata and empty English are ignored', LRCParser.parse(invalid), [], { input: invalid });
    check('Null and nonstring inputs return empty arrays', [null, 3, {}, undefined].map(x => LRCParser.parse(x)), [[], [], [], []]);
    const simple = '[0:01.20] Solo.\r\n[00:02.125]Left | Right | Tail';
    check('One-digit minutes, CRLF and optional translation', LRCParser.parse(simple), [
      { time: 1.2, english: 'Solo.', chinese: '', fullText: 'Solo.' },
      { time: 2.125, english: 'Left', chinese: 'Right', fullText: 'Left | Right | Tail' }
    ], { input: simple, classification: 'Extra pipe segments remain only in fullText.' });
    const repeated = '[00:01.00][00:02.00]Marker stays.';
    check('Multiple timestamps are not expanded', LRCParser.parse(repeated), [
      { time: 1, english: '[00:02.00]Marker stays.', chinese: '', fullText: '[00:02.00]Marker stays.' }
    ], { input: repeated });
  });

  runGroup('timeline', () => {
    check('Configured offset is 0.3 seconds', CONFIG.PLAYER.TIME_OFFSET, 0.3);
    check('Parser default is no offset', LRCParser.parse(fixture).map(x => x.time), [0.1, 1.25, 2.5, 2.5, 4.125, 6]);
    check('App offset subtracts and preserves a negative first timestamp', parsed.map(x => x.time), [-0.2, 0.95, 2.2, 2.2, 3.825, 5.7]);
    const times = [-0.201, -0.2, 0, 0.949, 0.95, 2.199, 2.2, 3.824, 3.825, 5.7, 8];
    check('Inclusive exact-time lookup and last-duplicate selection', times.map(t => LRCParser.findLyricIndexByTime(parsed, t)), [-1, 0, 0, 0, 1, 1, 3, 3, 4, 5, 5], { input: times });
    check('Empty lookup returns -1', LRCParser.findLyricIndexByTime([], 0), -1);
    check('First duplicate has zero-length interval', LRCParser.getSentenceBoundaries(parsed, 2, 8), { startTime: 2.2, endTime: 2.2, index: 2 }, { classification: 'Observed edge behavior, not fixed.' });
    check('Second duplicate spans until next timestamp', LRCParser.getSentenceBoundaries(parsed, 3, 8), { startTime: 2.2, endTime: 3.825, index: 3 });
    check('Last line uses provided duration', LRCParser.getSentenceBoundaries(parsed, 5, 8), { startTime: 5.7, endTime: 8, index: 5 });
    check('Without duration, last line gets minimum 0.1 seconds', LRCParser.getSentenceBoundaries(parsed, 5), { startTime: 5.7, endTime: 5.8, index: 5 });
    check('Invalid out-of-range boundaries return null', [-1, 6].map(index => LRCParser.getSentenceBoundaries(parsed, index, 8)), [null, null]);
  });

  runGroup('controller', () => {
    const audio = new AudioDouble(8), progress = new ElementDouble(), button = new ElementDouble();
    const current = new ElementDouble(), duration = new ElementDouble(), ticks = [], persist = [];
    const player = new AudioController({ audio, progressBar: progress, playBtn: button, currentTimeEl: current, durationEl: duration, onTick: (time, length) => ticks.push([time, length]), onPersist: time => persist.push(time) });
    for (const [input, expected] of [[-0.2, 0], [2.2, 2.2], [99, 8]]) {
      player.seek(input); check(`Known-duration seek(${input})`, audio.currentTime, expected);
    }
    player.seek(NaN); check('Nonfinite seek is ignored', audio.currentTime, 8);
    audio.duration = 0; player.seek(-0.2);
    check('Unknown-duration direct negative seek assigns a negative value in the double', audio.currentTime, -0.2, { classification: 'Observed controller assignment only. Real HTMLMediaElement behavior untested.' });
    audio.duration = 8; progress.emit('click', { clientX: 60 });
    check('Progress midpoint click seeks to media midpoint', audio.currentTime, 4);
    check('Seek updates progress without invoking onTick', { progress: progress.styleValues['--progress'], ticks: ticks.length }, { progress: '50%', ticks: 0 });
    progress.emit('pointerdown', { clientX: 10, pointerId: 7 });
    progress.emit('pointermove', { clientX: 110, pointerId: 7 });
    check('Pointer drag reaches media end', { current: audio.currentTime, dragging: player.dragging }, { current: 8, dragging: true });
    progress.emit('pointercancel', { pointerId: 7 });
    check('Pointer cancel ends dragging and persists', { dragging: player.dragging, stored: persist.at(-1) }, { dragging: false, stored: 8 });
    tick(audio, 1.25); audio.currentTime = 2; audio.emit('timeupdate');
    check('Same-clock tick suppressed by actual throttle', ticks, [[1.25, 8]]);
    tick(audio, 2); check('Later tick reads current media time', ticks.at(-1), [2, 8]);
    player.setRate(2); check('Playback rate changes without rewriting source time', { rate: audio.playbackRate, time: audio.currentTime }, { rate: 2, time: 2 });
    player.setSrc('synthetic://no-real-media', { startTime: 99, playbackRate: 1.25, loop: true });
    audio.emit('loadedmetadata');
    check('Restored position stays 0.05 seconds before end', { time: audio.currentTime, rate: audio.playbackRate, loop: audio.loop, disabled: button.disabled }, { time: 7.95, rate: 1.25, loop: true, disabled: false });
    const before = ticks.length; player.destroy(); tick(audio, 3);
    check('Destroyed controller does not deliver new tick', ticks.length, before);
    report.traces.controller = { calls: audio.calls, ticks, persistedTimes: persist };
  });

  runGroup('view', () => {
    const display = new ElementDouble(), container = new ElementDouble(), activations = [];
    const view = new LyricsView({ display, container, scrollThreshold: 0.1, onActivate: (index, time) => activations.push([index, time]) });
    view.render(parsed);
    check('Actual render emits six line wrappers', view.lineEls.length, 6);
    check('Rendered data-time preserves offset', view.lineEls.map(x => x.dataset.time), ['-0.2', '0.95', '2.2', '2.2', '3.825', '5.7']);
    view.highlight(0); view.highlight(1); check('Highlight removes old active class', active(view), [1]);
    view.lineEls[5].rect = { top: 190, bottom: 210, height: 20, left: 10, width: 100 };
    view.highlight(5); check('Off-threshold line requests scroll', view.lineEls[5].scrollCalls, [{ behavior: 'smooth', block: 'center' }], { classification: 'Method call only; visual scroll unverified.' });
    view.highlight(5); check('Repeated highlight requests no extra scroll', view.lineEls[5].scrollCalls.length, 1);
    view.highlight(-1); check('Negative index removes active class', active(view), []);
    display.emit('click', { target: view.lineEls[1] });
    const enter = display.emit('keydown', { target: view.lineEls[3], key: 'Enter' });
    const space = display.emit('keydown', { target: view.lineEls[4], key: ' ' });
    display.emit('keydown', { target: view.lineEls[4], key: 'Escape' });
    check('Click, Enter and Space activate actual callback', activations, [[1, 0.95], [3, 2.2], [4, 3.825]]);
    check('Enter and Space prevent default', [enter.defaultPrevented, space.defaultPrevented], [true, true]);
    const hostileLookingButOriginal = [{ time: 0, english: '<b>Tile</b> & "Lamp"', chinese: '<i>标记</i>' }];
    view.render(hostileLookingButOriginal);
    check('Text is escaped by actual render helper', display.innerHTML.includes('&lt;b&gt;Tile&lt;/b&gt; &amp; &quot;Lamp&quot;') && display.innerHTML.includes('&lt;i&gt;标记&lt;/i&gt;'), true);
    report.traces.view = { activations, escapedHtml: display.innerHTML };
    view.render([]); check('Empty lyrics clear lines', { lines: view.lineEls.length, index: view.activeIndex }, { lines: 0, index: -1 });
    view.destroy();
  });

  runGroup('integration', () => {
    const audio = new AudioDouble(8), display = new ElementDouble(), container = new ElementDouble();
    for (const [selector, value] of [['#audioPlayer', audio], ['#lyricsDisplay', display], ['.lyrics-container', container]]) registry.set(selector, value);
    class ComponentReadingSystem extends ReadingSystem {
      async init() { this.catalogBootSuppressed = true; }
    }
    const app = new ComponentReadingSystem();
    app.state.bookKey = 'ORIGINAL_SYNTHETIC'; app.state.currentUnitIndex = 0;
    app.state.currentLyrics = LRCParser.parse(fixture, app.config.PLAYER.TIME_OFFSET);
    app.lyricsView.render(app.state.currentLyrics); app.ready = true;
    check('Only init is overridden', Object.getOwnPropertyNames(ComponentReadingSystem.prototype).sort(), ['constructor', 'init']);
    check('Catalog boot suppressed', app.catalogBootSuppressed, true);
    const trace = [];
    function snapshot(action) {
      const row = { action, mediaTime: audio.currentTime, index: app.state.currentLyricIndex, active: active(app.lyricsView), mode: app.state.loopMode, locked: app.state.sentenceLoopIndex, paused: audio.paused };
      trace.push(row); return row;
    }
    tick(audio, 0); check('Normal timeline highlights early-offset first line at t=0', app.state.currentLyricIndex, 0); snapshot('tick 0');
    tick(audio, 0.95); check('Normal timeline changes exactly at boundary', app.state.currentLyricIndex, 1); snapshot('tick 0.95');
    tick(audio, 2.2); check('Normal timeline picks last duplicate at exact boundary', { index: app.state.currentLyricIndex, active: active(app.lyricsView) }, { index: 3, active: [3] }); snapshot('tick 2.2');
    display.emit('click', { target: app.lyricsView.lineEls[1] });
    check('Actual click chain highlights, seeks and calls play', { time: audio.currentTime, index: app.state.currentLyricIndex, paused: audio.paused, persisted: storage.get('ORIGINAL_SYNTHETIC/0/playTime') }, { time: 0.95, index: 1, paused: false, persisted: '0.95' }); snapshot('click line 1');
    app.player.seek(3.825);
    check('Direct seek does not immediately synchronize highlight', app.state.currentLyricIndex, 1, { classification: 'Observed event timing: seek updates progress; highlight waits for next tick.' }); snapshot('direct seek 3.825');
    tick(audio, 3.825); check('Next audio tick synchronizes highlight', app.state.currentLyricIndex, 4); snapshot('tick after seek');
    display.emit('click', { target: app.lyricsView.lineEls[0] });
    check('Negative parsed timestamp click is clamped with known duration', { parsed: app.state.currentLyrics[0].time, media: audio.currentTime, index: app.state.currentLyricIndex }, { parsed: -0.2, media: 0, index: 0 }); snapshot('click negative-offset line');
    app.state.loopMode = 'click';
    display.emit('click', { target: app.lyricsView.lineEls[1] }); tick(audio, 2.199);
    check('Click mode remains playing before sentence end', { time: audio.currentTime, index: app.state.currentLyricIndex, paused: audio.paused }, { time: 2.199, index: 1, paused: false }); snapshot('click mode before end');
    tick(audio, 2.2);
    check('Click mode resets and pauses at exact sentence end', { time: audio.currentTime, index: app.state.currentLyricIndex, paused: audio.paused }, { time: 0.95, index: 1, paused: true }); snapshot('click mode exact end');
    app.state.loopMode = 'one'; display.emit('click', { target: app.lyricsView.lineEls[1] }); tick(audio, 2.2);
    check('One mode resets at end without pausing', { time: audio.currentTime, index: app.state.currentLyricIndex, paused: audio.paused }, { time: 0.95, index: 1, paused: false }); snapshot('one mode exact end');
    app.state.loopMode = 'click'; display.emit('click', { target: app.lyricsView.lineEls[2] }); tick(audio, 2.2);
    check('First duplicate in click mode pauses on first same-time tick', { time: audio.currentTime, index: app.state.currentLyricIndex, paused: audio.paused }, { time: 2.2, index: 2, paused: true }, { classification: 'Zero-length interval observed; no automatic repair.' }); snapshot('click zero-length duplicate');
    display.emit('click', { target: app.lyricsView.lineEls[5] }); tick(audio, 8);
    check('Last click-mode sentence stops at known media duration', { time: audio.currentTime, index: app.state.currentLyricIndex, paused: audio.paused }, { time: 5.7, index: 5, paused: true }); snapshot('last sentence end');
    const indexBeforeDestroy = app.state.currentLyricIndex;
    app.persistProgress.cancel(); app.destroy(); tick(audio, 0);
    check('Destroyed actual system has no new timeline callbacks', app.state.currentLyricIndex, indexBeforeDestroy);
    report.traces.integration = trace;
    report.traces.integrationAudioCalls = audio.calls;
    report.traces.storage = Object.fromEntries(storage);
    registry.clear();
  });
  currentGroup = 'safety';
  check('No fetch or uncontrolled Audio construction attempted', report.networkAttempts, []);
} finally {
  Date.now = originalNow;
  for (const [key, value] of Object.entries(originalGlobals)) {
    if (value === undefined) delete globalThis[key]; else globalThis[key] = value;
  }
  report.finishedAt = new Date().toISOString();
  report.summary = { passed: report.tests.filter(x => x.pass).length, failed: report.tests.filter(x => !x.pass).length, assertions: report.tests.length, groups: [...new Set(report.tests.map(x => x.group))], verifiedUpstreamFiles: Object.keys(verifiedHashes).length };
  mkdirSync(dirname(output), { recursive: true });
  writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ ...report.summary, output, startedAt, finishedAt: report.finishedAt, scope: report.scope }, null, 2));
  if (report.summary.failed) process.exitCode = 1;
}
