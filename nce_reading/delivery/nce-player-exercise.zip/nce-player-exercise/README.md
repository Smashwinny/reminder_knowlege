# NCE 源码组件实验

公开副本说明：保留 2026-10-05 的历史组件实验，本次公开整理未重跑。只补充这段说明；14 个上游 JavaScript 模块、MIT 许可、实验脚本、原创样例和七份 JSON 结果均保留原字节。真实浏览器与音频仍未验收；HTML 浏览器视觉和 HTML 转 PDF 原路线受环境限制，本次未重试。

## 范围先说明

这是对真实上游 JavaScript 的**受控组件模拟**，不是完整播放器端到端测试。没有打开浏览器、启动本地服务器、安装依赖、访问账户，也没有下载、生成、解码或试听任何音频。HTML 的实际视觉效果、音频精度、浏览器媒体行为和网络资源加载均未验证。

- 上游：<https://github.com/iChochy/NCE>
- 固定提交：`0a92ab5af50e2898a104f15eac7adb00f17bd96b`
- 随包完整运行记录：2026-10-05 09:57:52 UTC，Node.js v24.19.0
- 随包结果：72 项断言通过，0 项失败。这里的“通过”也包含对已知边界问题的行为确认，不表示软件没有缺陷
- `upstream/` 保留 14 个实际依赖模块的原始字节以及 MIT LICENSE；运行前核验 SHA-256
- `fixtures/original.lrc` 为本实验原创的六句短文本，包含自行撰写的中文对应句；不来自教材
- 不包含教材正文、课文翻译、课程音频或外部课程资源包

## 关键替代条件

`ComponentReadingSystem` 只覆盖 `init()`，防止启动目录和课本加载。其余真实解析器、私有时间线处理、单句模式、seek、highlight 与事件处理均保持原样。

DOM、音频、localStorage、Date.now 和定时器由测试替身提供。DOM 替身只识别真实 LyricsView 输出的歌词行包装结构，不是浏览器 HTML 解析器。音频替身只记录属性赋值、方法调用和事件，不播放媒体。fetch 和全局 Audio 构造被设为抛错；本次运行均未尝试调用。

这些替代让结果可重复，但不能证明真实网页布局、浏览器自动播放、跨域、真实音频 seek 或播放节奏正确。

## 六步复现

使用已经安装的 Node.js，在此目录执行。测试无需 npm install，也不要启动网页或下载课程材料。

1. 校验固定源文件及 MIT：`node run.mjs --group integrity --output results/step1-integrity.json`
2. 验证实际 LRC 解析、过滤、分隔行为：`node run.mjs --group parser --output results/step2-parser.json`
3. 验证 0.3 秒偏移、负值、重复时间和句子边界：`node run.mjs --group timeline --output results/step3-timeline.json`
4. 验证真实 AudioController 的 seek 与事件逻辑：`node run.mjs --group controller --output results/step4-controller.json`
5. 验证真实 LyricsView 的 HTML 字符串、类名与回调：`node run.mjs --group view --output results/step5-view.json`
6. 验证实际 ReadingSystem 的点击和时间线组件链：`node run.mjs --group integration --output results/step6-integration.json`

统一复跑：`node run.mjs --output results/replay.json`

不同分组各自重复一次安全断言，因此六步统计相加与统一运行的 72 项统计不同。任一断言失败会使进程返回非零退出码。哈希不匹配会在上游模块执行前停止。

## 文件与原始证据

- `source-manifest.json`：提交、目录来源元数据、14 个 JS 与 LICENSE 的 SHA-256
- `run.mjs`：测试替身、实际模块调用、固定期望和逐项断言
- `fixtures/original.lrc`：完整原创输入
- `results/initial.json`：完整复跑结果；含输入、解析输出、每项 actual/expected、事件状态和时间
- `source-study.md`：源码位置、观测与限制
- `upstream/LICENSE`：原始 MIT 声明，须随所附上游代码保留

JSON 的主要字段：`startedAt`、`finishedAt`、`node`、`source`、`interventions`、`fixture`、`tests`、`traces`、`networkAttempts`、`limitations` 和 `summary`。

每次断言记录时深复制 actual/expected 快照，避免后续数组变化改写先前日志。随包七份结果的所有 pass=true 记录均已逐项复核实际值与期望值一致。

## 权利边界

仓库 LICENSE 标识软件/相关文档为 MIT，版权为 2025 iChochy。README 同时说明项目用于个人学习研究、内容来自互联网且作者不拥有内容版权。软件许可证不能证明第三方教材、翻译和录音的使用或再分发权限。本实验只研究代码并使用原创短句。
