"""Inspect actual upstream results and demonstrate a separate local policy.

The policy is authored for this exercise. It does NOT modify pe_core.py or
claim to be Qwen's complete official schema. It assumes two input references
for edit cases and chooses exactly one canvas selector for this consumer.
"""
from pathlib import Path
import json
import re
import sys
ROOT = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
report = json.loads((ROOT/'results.json').read_text(encoding='utf-8'))
assert report['all_passed'] and report['passed_count'] == report['test_count'] == 21
cases = {case['name']: case for case in report['cases']}

def local_policy(record, task, reference_count=2):
    errors=[]
    if not record.get('parse_ok'):
        errors.append('parse_failed')
    if not isinstance(record.get('positive_prompt'),str) or not record['positive_prompt'].strip():
        errors.append('empty_prompt')
    ratio=record.get('wh_ratio',''); follow=record.get('ratio_follow','')
    allowed={'1:1','4:3','3:4','3:2','2:3','16:9','9:16'}
    if ratio and ratio not in allowed: errors.append('unsupported_ratio')
    if task=='t2i':
        if not ratio: errors.append('missing_ratio')
        if follow: errors.append('unexpected_reference')
    elif task=='edit':
        if bool(ratio)==bool(follow): errors.append('choose_exactly_one_canvas_selector')
        if follow:
            m=re.fullmatch(r'<image([1-9][0-9]*)>',follow)
            if not m or not 1 <= int(m.group(1)) <= reference_count:
                errors.append('reference_out_of_range')
    else: errors.append('unknown_task')
    return errors

mode=sys.argv[1]
if mode=='messages':
    content=cases['image_marker_order']['actual'][1]['content']
    for index,item in enumerate(content,1):
        value=item['image_url']['url'] if item['type']=='image_url' else item['text']
        print(str(index)+'. '+item['type']+': '+value)
    print('ORDER PASS: image1, image2, text; markers were not fetched or decoded')
elif mode=='parser':
    names=['valid_t2i','valid_edit','legacy_key','final_candidate_wins','no_json_fallback',
           'truncated_json_fallback','trailing_comma_without_repair','empty_prompt_fallback']
    for name in names:
        r=cases[name]['actual']
        print(name+': parse_ok='+str(r['parse_ok'])+'; positive_prompt='+r['positive_prompt'])
    print('UPSTREAM EXPECTED-BEHAVIOR CHECKS: 21/21 passed; json_repair absent')
elif mode=='validate':
    names=['valid_t2i','valid_edit','edit_both_ratio_fields_accepted','unknown_aspect_ratio_accepted',
           'missing_ratio_fields_accepted','unverified_image_reference_accepted']
    accepted=0;rejected=0
    for name in names:
        case=cases[name]; errors=local_policy(case['actual'],case['input']['task'])
        expected_ok=name in {'valid_t2i','valid_edit'}
        assert (not errors)==expected_ok, (name,errors)
        accepted+=not errors;rejected+=bool(errors)
        print(name+': upstream_parse_ok='+str(case['actual']['parse_ok'])+
              '; local_policy='+('ACCEPT' if not errors else 'REJECT '+','.join(errors)))
    print(f'LOCAL POLICY CHECKS: 6/6 matched; {accepted} ACCEPT; {rejected} REJECT')
    print('Local policy is a teaching example, not upstream code or image-quality validation')
else:
    raise SystemExit('Choose messages, parser, or validate')
