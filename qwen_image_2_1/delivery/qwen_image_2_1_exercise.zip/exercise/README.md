# Qwen Image 2.1 CPU 接口练习

本材料记录 2026-10-05 07:05 UTC 的原学习实验。公开整理未重新运行实验；以下输出、时间与统计保留原始运行含义。 如需自行复现，请按下列命令重新生成结果。

研究与评估用途。需要 Python 3.10 或更新版本；不安装依赖、不联网、不需要 GPU、API 密钥或权重。
先解压 ZIP，再在终端进入解压后的 exercise 目录。保持此目录，逐步复制以下命令。

1. 检查 Python、隔离标志和上游 SHA-256
   python3 -I -S -B check_environment.py
2. 真实运行官方纯函数的 21 项预期行为检查，生成本次 results.json
   python3 -I -S -B experiment/verify_contract.py > results.json
3. 查看两个合成图像字符串标记和文本的顺序
   python3 -I -S -B inspect_results.py messages
4. 比较正常、兼容、坏 JSON 的解析结果
   python3 -I -S -B inspect_results.py parser
5. 用自建下游策略检查 2 个正常样本和 4 个越界样本
   python3 -I -S -B inspect_results.py validate

预期：步骤 1 返回 READY；步骤 2 退出码 0 并生成非空 JSON；步骤 3 返回 ORDER PASS；步骤 4 显示 21/21；步骤 5 显示 6/6 matched、2 ACCEPT、4 REJECT。

可见的中间成果：results.json 保留每个合成输入、实际结果、预期结果与通过标志；后续三步从它读取不同证据。所有内容都是人工构造的普通物体样本，不是任何模型生成的答复。expected_upstream_results.json 只是首次已验证运行的参考，正常复现必须重新生成 results.json。

## 许可与边界

experiment/upstream/pe_core.py 是未改动的官方代码；LICENSE 和 NOTICE 保留原许可与归属。使用材料应遵守 Qwen Research License，商业用途另需许可。练习新增脚本仅用于接口学习，不是上游补丁。inspect_results.py 的 local_policy 是本练习自定的消费者策略：文生图比例必须在列出的 7 个选项中；编辑恰好选择比例或引用一项；引用必须属于本练习假定的 2 张图。它不是官方完整 schema，也不评价图像质量。

输入中 synthetic: 开头的字符串仅供消息构建测试，不是可访问图片地址。未加载图片、模型、图像解码器或请求客户端。json_repair 在隔离运行下不存在，因此坏 JSON 的结果不可直接迁移到安装了该可选包的环境。

verify_contract.py 的 Python audit guard 是防御性限制，不是操作系统沙箱证明。它拒绝网络、子进程、文件写入及范围外读取；命令中的重定向由外部 shell 创建 results.json。

完整固定来源与哈希见 SOURCE_PROVENANCE.md。HTML 和 PDF 指南单独交付，不在此 ZIP 内。
