"""Read-only preflight for the standalone research exercise."""
from pathlib import Path
import hashlib
import sys
ROOT = Path(__file__).resolve().parent
assert sys.version_info >= (3, 10), 'Requires Python 3.10 or newer'
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
checks = {
 'experiment/upstream/pe_core.py': 'fd9732bbba71468fb24bd81de5c209f0db2941f01d1e556d52b5a6deba0f1fe5',
 'experiment/upstream/LICENSE': '8dc973f024ff95966bea25866efa443fd16776dcb1001e681e3d467ea572b28d',
}
for name, expected in checks.items():
    actual = hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    assert actual == expected, name + ': SHA-256 mismatch'
    print(name + ': SHA256 OK ' + actual)
print('Python ' + sys.version.split()[0])
print('isolated=True no_site=True no_bytecode=True')
print('READY: stdlib-only CPU exercise; no model, image loading, API or network')
