# 固定来源和归属

- 官方代码仓库：https://github.com/QwenLM/Qwen-Image-2.1
- GitHub commit：6627d87c6433151463ec4b48b8945a24fcf16a35
- 未改动代码：https://github.com/QwenLM/Qwen-Image-2.1/blob/6627d87c6433151463ec4b48b8945a24fcf16a35/prompt_rewrite/pe_core.py
- pe_core.py SHA-256：fd9732bbba71468fb24bd81de5c209f0db2941f01d1e556d52b5a6deba0f1fe5
- LICENSE SHA-256：8dc973f024ff95966bea25866efa443fd16776dcb1001e681e3d467ea572b28d
- 模型元数据：https://huggingface.co/Qwen/Qwen-Image-2.1/tree/d26bb61231c349cf6b7896fa83353113880e1ba3
- 模型 revision：d26bb61231c349cf6b7896fa83353113880e1ba3
- 官方代码与模型适用 Qwen Research License。LICENSE 和 NOTICE 在 experiment/upstream/ 下。包中没有任何模型权重。
- 新增独立材料：check_environment.py、inspect_results.py、experiment/verify_contract.py、README.md、此来源说明。没有修改官方源码。
- 查阅及首次执行日期：2026-10-05 UTC。Python 3.12.14，标准库隔离模式。
- 首次预期行为检查：21/21，其中预期结果包括宽松解析器接受的 4 个字段不合规样本。通过不表示这些边界被修复。
