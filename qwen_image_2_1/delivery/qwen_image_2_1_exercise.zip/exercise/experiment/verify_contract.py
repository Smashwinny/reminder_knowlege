#!/usr/bin/env python3
"""Local research harness for unmodified official Qwen prompt-rewriter helpers.

No model, image decoder, client, endpoint, installation, or generated image.
Run with: python3 -I -S -B verify_contract.py > results.json
The audit guard is defense-in-depth, not an operating-system sandbox.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import sysconfig

REVISION = "6627d87c6433151463ec4b48b8945a24fcf16a35"
EXPECTED_SHA256 = "fd9732bbba71468fb24bd81de5c209f0db2941f01d1e556d52b5a6deba0f1fe5"
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "upstream" / "pe_core.py"
STDLIB = Path(sysconfig.get_path("stdlib")).resolve()

if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
    raise SystemExit("Run with python3 -I -S -B to avoid external packages/startup hooks and bytecode writes")
source_bytes = SOURCE.read_bytes()
source_sha = hashlib.sha256(source_bytes).hexdigest()
if source_sha != EXPECTED_SHA256:
    raise SystemExit("Official source SHA-256 mismatch; refusing to execute")

blocked_events: list[str] = []


def audit_guard(event: str, args: tuple) -> None:
    denied = (
        event.startswith(("socket.", "subprocess.", "urllib.", "http.client.", "ctypes."))
        or event in {"os.system", "os.fork", "os.forkpty", "os.posix_spawn", "os.exec",
                     "os.spawn", "os.remove", "os.rmdir", "os.rename", "os.mkdir",
                     "os.chmod", "os.chown", "os.link", "os.symlink", "os.truncate"}
    )
    if event == "open":
        name, mode, flags = args
        writing = bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
        if isinstance(name, (str, bytes, os.PathLike)):
            target = Path(os.fsdecode(name)).resolve()
            allowed_read = target == SOURCE or target.is_relative_to(STDLIB)
        else:
            allowed_read = False
        denied = denied or writing or not allowed_read
    if denied:
        blocked_events.append(event)
        raise RuntimeError(f"Research harness blocked side effect: {event}")


sys.addaudithook(audit_guard)
spec = importlib.util.spec_from_file_location("official_qwen_pe_core", SOURCE)
if spec is None or spec.loader is None:
    raise SystemExit("Could not load the pinned source")
core = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = core
# Execute the already-hashed, unmodified bytes directly. A SourceFileLoader
# probes for local .pyc files even with -B; that would violate the read allowlist.
exec(compile(source_bytes, str(SOURCE), "exec"), core.__dict__)
if core.json_repair is not None:
    raise SystemExit("Unexpected json_repair package; this experiment requires the stdlib-only path")

tests: list[dict] = []


def check(name: str, category: str, input_value, actual, expected) -> None:
    tests.append({"name": name, "category": category, "input": input_value,
                  "actual": actual, "expected": expected, "passed": actual == expected})


def expected_parse(prompt: str, ratio: str = "", follow: str = "", ok: bool = True) -> dict:
    return {"positive_prompt": prompt, "wh_ratio": ratio, "ratio_follow": follow, "parse_ok": ok}


for task, values in [("t2i", [False, False, 1.5, 16256]), ("edit", [True, True, 0.0, 24000])]:
    profile = core.get_profile(task)
    check(f"profile_{task}", "task profile", task,
          [profile.takes_images, profile.has_ratio_follow, profile.presence_penalty, profile.max_new_tokens], values)

t2i = core.get_profile("t2i")
edit = core.get_profile("edit")
parser_cases = [
    ("valid_t2i", "normal extraction", t2i,
     '{"rewritten_prompt":"A blue ceramic mug on a shelf","wh_ratio":"1:1"}',
     expected_parse("A blue ceramic mug on a shelf", "1:1")),
    ("valid_edit", "normal extraction", edit,
     '{"rewritten_prompt":"Make the mug green","wh_ratio":"","ratio_follow":"<image1>"}',
     expected_parse("Make the mug green", "", "<image1>")),
    ("braces_in_string", "benign parser edge", t2i,
     '{"rewritten_prompt":"A mug with {leaf} printed on it","wh_ratio":"4:3"}',
     expected_parse("A mug with {leaf} printed on it", "4:3")),
    ("escaped_quotes", "benign parser edge", t2i,
     json.dumps({"rewritten_prompt": 'A box labelled "TOOLS"', "wh_ratio": "1:1"}),
     expected_parse('A box labelled "TOOLS"', "1:1")),
    ("final_candidate_wins", "benign parser edge", t2i,
     '{"rewritten_prompt":"A red cube"} Text {"rewritten_prompt":"A blue cube","wh_ratio":"16:9"}',
     expected_parse("A blue cube", "16:9")),
    ("trailing_irrelevant_object", "benign parser edge", t2i,
     '{"rewritten_prompt":"A wooden spoon","wh_ratio":"3:4"} Note {"status":"done"}',
     expected_parse("A wooden spoon", "3:4")),
    ("legacy_key", "compatibility", t2i,
     '{"rewrited_prompt":"A glass vase","wh_ratio":"2:3"}',
     expected_parse("A glass vase", "2:3")),
    ("no_json_fallback", "invalid extraction", t2i, "A yellow bowl", expected_parse("A yellow bowl", ok=False)),
    ("truncated_json_fallback", "invalid extraction", t2i,
     '{"rewritten_prompt":"A yellow bowl"', expected_parse('{"rewritten_prompt":"A yellow bowl"', ok=False)),
    ("trailing_comma_without_repair", "invalid extraction", t2i,
     '{"rewritten_prompt":"A yellow bowl",}', expected_parse('{"rewritten_prompt":"A yellow bowl",}', ok=False)),
    ("empty_prompt_fallback", "invalid extraction", t2i,
     '{"rewritten_prompt":"   ","wh_ratio":"1:1"}',
     expected_parse('{"rewritten_prompt":"   ","wh_ratio":"1:1"}', ok=False)),
    ("t2i_ignores_edit_reference", "task-specific field", t2i,
     '{"rewritten_prompt":"A folded paper boat","wh_ratio":"3:2","ratio_follow":"<image1>"}',
     expected_parse("A folded paper boat", "3:2")),
    ("edit_both_ratio_fields_accepted", "domain validation gap", edit,
     '{"rewritten_prompt":"Make the cup blue","wh_ratio":"16:9","ratio_follow":"<image1>"}',
     expected_parse("Make the cup blue", "16:9", "<image1>")),
    ("unknown_aspect_ratio_accepted", "domain validation gap", t2i,
     '{"rewritten_prompt":"A green notebook","wh_ratio":"wide-ish"}',
     expected_parse("A green notebook", "wide-ish")),
    ("missing_ratio_fields_accepted", "domain validation gap", edit,
     '{"rewritten_prompt":"Make the cube green"}', expected_parse("Make the cube green")),
    ("unverified_image_reference_accepted", "domain validation gap", edit,
     '{"rewritten_prompt":"Make the cube green","ratio_follow":"<image99>"}',
     expected_parse("Make the cube green", "", "<image99>")),
]
for name, category, profile, answer, expected in parser_cases:
    check(name, category, {"task": profile.name, "answer": answer}, core.parse_answer(answer, profile), expected)

markers = ["synthetic:image1:blue_cube", "synthetic:image2:wooden_shelf"]
messages = core.build_messages("Describe ordinary objects", "Place the cube on the shelf", markers)
check("image_marker_order", "message construction", markers, messages, [
    {"role": "system", "content": [{"type": "text", "text": "Describe ordinary objects"}]},
    {"role": "user", "content": [
        {"type": "image_url", "image_url": {"url": markers[0]}},
        {"type": "image_url", "image_url": {"url": markers[1]}},
        {"type": "text", "text": "Place the cube on the shelf"}]}])

case = {"id": "ordinary_object_1", "prompt": "A blue mug"}
record = core.build_record(case, "", '{"rewritten_prompt":"A blue ceramic mug","wh_ratio":"1:1"}', t2i)
check("record_field_order", "output contract", case, list(record), list(core.OUTPUT_FIELDS))
check("record_contents", "output contract", case, record, {
    "id": "ordinary_object_1", "task": "t2i", "raw_prompt": "A blue mug", "input_images": [],
    "task_type": "", "thinking": "", "positive_prompt": "A blue ceramic mug", "negative_prompt": "",
    "wh_ratio": "1:1", "ratio_follow": "", "parse_ok": True})

report = {
    "experiment": "Actual official pe_core.py pure-function contract tests; not model inference",
    "source_repository": "https://github.com/QwenLM/Qwen-Image-2.1",
    "source_revision": REVISION,
    "source_path": "prompt_rewrite/pe_core.py",
    "source_sha256": source_sha,
    "python_version": sys.version.split()[0],
    "isolation": {"isolated": bool(sys.flags.isolated), "no_site": bool(sys.flags.no_site),
                  "no_bytecode": sys.dont_write_bytecode, "json_repair": "absent",
                  "audit_guard": "denies network/processes/filesystem writes; permits only source and stdlib file reads",
                  "blocked_events": blocked_events},
    "test_count": len(tests),
    "passed_count": sum(t["passed"] for t in tests),
    "all_passed": all(t["passed"] for t in tests) and not blocked_events,
    "cases": tests,
    "interpretation": [
        "Pass means observed upstream behavior matches stated expectations, including observed validation gaps.",
        "parse_ok is extraction success, not complete schema/domain validation.",
        "No prompt rewriting, image loading, model inference, quality, transparency, GPU performance, or deployment was tested.",
        "Synthetic image markers were only copied as strings; they were not fetched or decoded.",
        "The Python audit guard is defense-in-depth, not a claim of OS-level sandboxing."
    ]}
print(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(0 if report["all_passed"] else 1)
