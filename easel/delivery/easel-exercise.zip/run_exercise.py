#!/usr/bin/env python3
"""Offline Easel component exercise. Local test harness, not upstream app/agent."""
from __future__ import annotations
import contextlib, hashlib, importlib.util, io, json, os, platform, runpy, shutil, sys, tempfile, time
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
UP = BASE / 'upstream'
FIX = BASE / 'fixtures'
LOGS = BASE / 'logs'
SNAP = BASE / 'snapshots'
TOPIC = '雨天书桌微整理'
PROFILE = '纸页角落虚构账号'
PROJECT = FIX / 'outputs' / TOPIC
os.chdir(BASE)
os.environ['EASEL_ROOT'] = str(FIX)
os.environ['HOME'] = str(BASE / 'runtime/home')
os.environ['TMPDIR'] = str(BASE / 'runtime/tmp')
tempfile.tempdir = str(BASE / 'runtime/tmp')
sys.dont_write_bytecode = True
for d in [FIX, LOGS, SNAP, PROJECT, BASE/'runtime/home', BASE/'runtime/tmp']:
    d.mkdir(parents=True, exist_ok=True)
# Guardrails are process-local. No host security/network settings are changed.
def within(p):
    return Path(p).resolve().is_relative_to(BASE)
def audit(event, args):
    if event.startswith(('socket.', 'subprocess.')) or event in {'os.system','os.exec','os.posix_spawn'}:
        raise RuntimeError('Offline exercise forbids external process/network: '+event)
    if event == 'open':
        path, mode, flags = args
        if isinstance(path, (str, bytes, os.PathLike)):
            p = Path(os.fsdecode(path))
            writing = (isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
            if writing and not within(p): raise RuntimeError('Write outside exercise: '+str(p))
            if p.name == '.env' and not within(p): raise RuntimeError('Env read outside exercise')
    if event in {'os.mkdir','os.remove','os.rmdir','os.rename','os.replace'}:
        for p in args[:2] if event in {'os.rename','os.replace'} else args[:1]:
            if isinstance(p,(str,bytes,os.PathLike)) and not within(os.fsdecode(p)):
                raise RuntimeError('Filesystem mutation outside exercise: '+str(p))
sys.addaudithook(audit)

def stamp(): return datetime.now(timezone.utc).isoformat()
def save(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
RESULT={'started_utc':stamp(),'python':sys.version,'platform':{'system':os.uname().sysname,'release':os.uname().release,'machine':os.uname().machine},'steps':[], 'upstream_selftests':[], 'custom_cases':[], 'operations':[], 'limitations':[
    'Fictional profile and locally authored text fixture; Easel agent/model generation was not run.',
    'No app/web/gateway/platform login/publisher API/network/paid model/install/global configuration.',
    'Passed component preflight is not full semantic quality, legal review, platform acceptance, or publication authorization.',
    'Full pytest suite not run; pytest is not installed. Only the three unmodified upstream selftest entrypoints and named custom integration cases run.',
    'Upstream metadata and asset indexes are separate contracts; archive/apply excluded.',
]}

def check(name, condition, details=None):
    row={'name':name,'passed':bool(condition),'details':details}
    RESULT['custom_cases'].append(row)
    if not condition:
        save(BASE/'results.json',RESULT)
        raise AssertionError(name+': '+repr(details))

def cli(label, rel, argv, expected=0):
    start=stamp(); t=time.perf_counter(); out=io.StringIO(); err=io.StringIO(); old=sys.argv[:]
    code=0
    try:
        sys.argv=[str(UP/rel),*map(str,argv)]
        with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
            try: runpy.run_path(str(UP/rel),run_name='__main__')
            except SystemExit as exc: code=exc.code or 0
    finally: sys.argv=old
    row={'label':label,'source':rel,'argv':list(map(str,argv)),'started_utc':start,'elapsed_seconds':round(time.perf_counter()-t,6),'exit_code':code,'expected_exit':expected,'stdout':out.getvalue(),'stderr':err.getvalue()}
    save(LOGS/(label+'.json'),row); RESULT['operations'].append(row)
    if code != expected: raise AssertionError(f'{label}: exit {code}, expected {expected}')
    return row

def load_module(name,rel):
    spec=importlib.util.spec_from_file_location(name,UP/rel)
    mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; spec.loader.exec_module(mod); return mod

def step(n,title,fn):
    s=stamp(); t=time.perf_counter(); fn(); RESULT['steps'].append({'number':n,'title':title,'started_utc':s,'elapsed_seconds':round(time.perf_counter()-t,6),'passed':True}); save(BASE/'results.json',RESULT)

M='skills/shared/scripts/manifest.py'; W='skills/shared/scripts/wordcount.py'; G='skills/shared/scripts/content_guard.py'; A='skills/openclaw/asset-manager/scripts/assets.py'
manifest_args=['--topic',TOPIC]
relpost=f'{TOPIC}/weibo-post.md'
FINAL='书桌总是越收越乱？先别急着买收纳盒。\n\n今晚只试三步：把明天要读的一本书放在手边；给正在用的笔留一个固定位置；把暂时不用的纸放进同一个纸袋。做完就停，不需要把每个角落整理得像照片。\n\n明天坐下时，看看能不能更快找到第一件要用的东西。你书桌上最容易找不到什么？评论里聊聊。\n\n#书桌整理# #阅读日常#'
DRAFT=FINAL+'\n'+('收纳之前先观察自己的使用习惯。'*14)+'\n虚构测试串：10.23.45.67:3128\n'
modules={}

def step1():
    lock=json.loads((BASE/'source-lock.json').read_text(encoding='utf-8'))
    check('upstream_copies_match_pinned_source_fingerprints',all(sha(UP/f['path'])==f['sha256'] for f in lock['copied_files']))
    profile=FIX/'profiles'/PROFILE; profile.mkdir(parents=True,exist_ok=True)
    fields={'identity':'# 身份定位\n\n虚构账号“纸页角落”，分享普通书桌和阅读习惯；只用于本地实验。\n','style':'# 内容风格\n\n简短、具体，不把建议说成保证；一条只讲一个小动作。\n','audience':'# 目标受众\n\n希望整理书桌、建立轻量阅读习惯的成年读者。\n','platforms':'# 平台运营\n\n目标格式：微博短文本；无真实账号、主页、登录态或授权。\n','preferences':'# 偏好与红线\n\n不虚构测量结果，不作效果保证，不含推广，不发布个人信息。仅本地保存，不发送。\n','memory':'# 经验沉淀\n\n本地合成练习，无历史运营数据或真实受众反馈。\n'}
    for field,text in fields.items(): (profile/(field+'.md')).write_text(text,encoding='utf-8')
    mod=load_module('easel_exercise_persona','easel/persona.py'); mod.PROJECT_ROOT=FIX; mod.PROFILES_DIR=FIX/'profiles'; modules['persona']=mod
    before={p.name:sha(p) for p in profile.glob('*.md')}; combined=mod.load_profile_text(PROFILE)
    check('profile_six_files_load_and_prefix_scope',len(before)==6 and PROFILE in mod.list_personas() and all(s in combined for s in ['身份定位','内容风格','目标受众','平台运营','偏好与红线','经验沉淀']) and f'profiles/{PROFILE}/memory.md' in mod.persona_prefix(PROFILE) and mod.persona_prefix('不存在的画像')=='')
    (SNAP/'profile-style-before.md').write_text((profile/'style.md').read_text(encoding='utf-8'),encoding='utf-8')
    with (profile/'style.md').open('a',encoding='utf-8') as f: f.write('\n修改：最后只问一个具体问题，不要求转发或关注。\n')
    after={p.name:sha(p) for p in profile.glob('*.md')}
    check('profile_style_edit_preserves_other_dimensions',before['style.md']!=after['style.md'] and all(before[k]==after[k] for k in before if k!='style.md') and '最后只问一个具体问题' in mod.load_profile_text(PROFILE))
    save(SNAP/'profile-load.json',{'before_sha256':before,'after_sha256':after,'prefix':mod.persona_prefix(PROFILE),'loaded_after':mod.load_profile_text(PROFILE)})

def step2():
    p=load_module('easel_exercise_paths','skills/shared/scripts/output_paths.py'); modules['paths']=p
    valid=p.validate_output_path(f'outputs/{relpost}',create_parent=True)
    check('valid_output_is_scoped_project_path',valid==PROJECT/'weibo-post.md')
    rejected=[]
    for bad in ['outputs/loose.md','outputs/test/result.md','outputs/_scratch/file.md','outputs/主题/../../escape.md']:
        try: p.validate_output_path(bad)
        except p.OutputPathError as e: rejected.append({'input':bad,'error':str(e)})
    check('four_invalid_output_paths_rejected',len(rejected)==4,rejected); save(LOGS/'path-rejections.json',rejected)
    valid.write_text(DRAFT,encoding='utf-8'); (SNAP/'post-before.md').write_text(DRAFT,encoding='utf-8')
    (PROJECT/'assets').mkdir(exist_ok=True)
    (PROJECT/'assets'/'brief.md').write_text('# 本地实验简报\n\n虚构画像、微博纯文本，主题为书桌微整理。文案由本地测试作者提供，不是Easel模型输出。长度目标140±5%，仅作测试阈值，不冒称平台硬限制。\n',encoding='utf-8')
    cli('02-save-metadata',M,['meta',*manifest_args,'--profile',PROFILE,'--title','初稿：雨天书桌微整理','--platform','微博','--kind','other','--status','draft','--tags','书桌整理,阅读日常','--deliverables','weibo-post.md'])
    cli('02-record-local-fixture',M,['record',*manifest_args,'--profile',PROFILE,'--layer','produce','--skill','local-authored-fixture','--outputs','weibo-post.md,assets/brief.md','--summary','本地合成文案；未运行Easel Agent生成'])
    data=json.loads((PROJECT/'.easel.json').read_text(encoding='utf-8')); save(SNAP/'manifest-before.json',data)
    check('manifest_persists_profile_draft_deliverable_history',data['profile']==PROFILE and data['status']=='draft' and data['deliverables']==['weibo-post.md'] and len(data['steps'])==1)

def step3():
    a=cli('03-before-length-rejection',W,['check','--target','140','--tolerance','0.05','--file',PROJECT/'weibo-post.md','--json'],1)
    b=cli('03-before-contentguard-rejection',G,['scan','--file',PROJECT/'weibo-post.md'],7)
    metrics=json.loads(a['stdout']); check('draft_fails_real_length_and_content_guards',metrics['status']=='over' and 'proxy-ip' in b['stderr'],{'count':metrics['actual'],'range':metrics['range'],'guard_exit':b['exit_code']})
    cli('03-record-preflight-failed',M,['record',*manifest_args,'--layer','publish','--skill','offline-component-preflight','--status','failed','--upstream','weibo-post.md','--summary','本地字数超标且合成私网IP被拦；未调用发布器'])
    latest=cli('03-latest-includes-failed',M,['latest',*manifest_args,'--layer','publish']); check('manifest_latest_returns_failed_step_without_success_filter',json.loads(latest['stdout'])['step']['status']=='failed')

def step4():
    p=modules['paths'].validate_output_path(f'outputs/{relpost}')
    p.write_text(FINAL+'\n',encoding='utf-8')
    a=cli('04-after-length-pass',W,['check','--target','140','--tolerance','0.05','--file',p,'--json'])
    b=cli('04-after-contentguard-pass',G,['scan','--file',p])
    stats=json.loads(a['stdout']); check('revised_post_passes_component_preflight',stats['pass'] and b['exit_code']==0,{'count':stats['actual'],'range':stats['range'],'guard_exit':b['exit_code']})
    old=json.loads((PROJECT/'.easel.json').read_text(encoding='utf-8'))
    cli('04-update-selected-metadata',M,['meta',*manifest_args,'--title','书桌微整理：从三件小事开始','--tags','书桌整理,阅读日常,本地实验'])
    new=json.loads((PROJECT/'.easel.json').read_text(encoding='utf-8'))
    check('metadata_upsert_preserves_omitted_fields_and_history',old['created']==new['created'] and old['profile']==new['profile'] and old['steps']==new['steps'] and new['status']=='draft' and old['title']!=new['title'])
    cli('04-record-preflight-passed',M,['record',*manifest_args,'--layer','publish','--skill','offline-component-preflight','--status','done','--upstream','weibo-post.md','--summary','仅本地字数与泄露扫描通过；无真实发布、无完整语义审核'])
    latest=cli('04-latest-preflight-passed',M,['latest',*manifest_args,'--layer','publish']); data=json.loads((PROJECT/'.easel.json').read_text(encoding='utf-8'))
    check('component_pass_does_not_mark_project_published',json.loads(latest['stdout'])['step']['status']=='done' and data['status']=='draft' and len(data['steps'])==3)
    before=sha(PROJECT/'.easel.json'); cli('04-invalid-kind-rejected',M,['meta',*manifest_args,'--kind','not-a-real-kind'],2)
    check('invalid_metadata_rejection_preserves_file',before==sha(PROJECT/'.easel.json'))
    save(SNAP/'manifest-after.json',data); shutil.copyfile(p,SNAP/'post-after.md')

def step5():
    root=FIX/'outputs'; cli('05-asset-scan',A,['--root',root,'scan'])
    cli('05-asset-tag-draft',A,['--root',root,'tag',relpost,'--add','虚构画像,待修订'])
    cli('05-asset-retag',A,['--root',root,'tag',relpost,'--add','已本地检查','--remove','待修订'])
    result=cli('05-asset-search',A,['--root',root,'search','书桌','--platform','weibo','--tag','虚构画像,已本地检查'])
    idx=json.loads((root/'INDEX.json').read_text(encoding='utf-8')); tags=json.loads((root/'tags.json').read_text(encoding='utf-8')); item=next(x for x in idx['files'] if x['path']==relpost)
    check('asset_index_tags_and_search_match_saved_post',item['platform']=='weibo' and item['type']=='text' and item['tags']==tags[relpost] and '待修订' not in item['tags'] and '找到 1 个匹配项' in result['stdout'],{'indexed_count':idx['count'],'item':item,'metadata_indexed':any(x['path'].endswith('.easel.json') for x in idx['files'])})
    cli('05-asset-report',A,['--root',root,'report'])

def step6():
    for label,rel in [('manifest',M),('wordcount',W),('content_guard',G)]:
        row=cli('06-upstream-selftest-'+label,rel,['selftest']); RESULT['upstream_selftests'].append({'name':label,'exit_code':row['exit_code'],'log':'logs/'+row['label']+'.json'})
    check('all_temp_writes_scoped_and_no_temp_files_left',Path(tempfile.gettempdir())==BASE/'runtime/tmp' and not list((BASE/'runtime/tmp').iterdir()))
    lock=json.loads((BASE/'source-lock.json').read_text(encoding='utf-8'))
    check('upstream_copies_unchanged_after_execution',all(sha(UP/f['path'])==f['sha256'] for f in lock['copied_files']))

for n,title,fn in [(1,'Pin source and create/edit fictional six-file profile',step1),(2,'Validate output paths and persist draft project',step2),(3,'Run actual failing prepublication component checks',step3),(4,'Repair text and metadata then recheck',step4),(5,'Index tag and retrieve the saved content artifact',step5),(6,'Run original selftests and verify isolation',step6)]: step(n,title,fn)
RESULT['finished_utc']=stamp(); RESULT['custom_cases_passed']=sum(x['passed'] for x in RESULT['custom_cases']); RESULT['custom_cases_total']=len(RESULT['custom_cases']); RESULT['upstream_selftest_entrypoints_passed']=len(RESULT['upstream_selftests']); RESULT['operations_total']=len(RESULT['operations'])
save(BASE/'results.json',RESULT)
print(json.dumps({k:RESULT[k] for k in ['started_utc','finished_utc','custom_cases_passed','custom_cases_total','upstream_selftest_entrypoints_passed','operations_total']},ensure_ascii=False,indent=2))
