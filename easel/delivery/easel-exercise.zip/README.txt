Easel offline component exercise, fixed source 6c049ceb73b1b74a73448664dcd4dbc7e051442a

Purpose
Create/edit one fictional six-file profile and one locally authored Chinese short-text fixture, then use genuine unmodified Easel modules for profile loading, project metadata/history, path validation, word counting, leakage scanning, asset indexing/tagging/search. This is not an Easel Agent/model-generation or social-platform publishing run.

Requirements
Linux/POSIX shell, Python 3.10+ standard library. No package installation or network needed. Tested on Python 3.12.14. Fresh extraction directory required; do not rerun over existing fixtures. All filenames/data are fictional local exercise material.

Reproduce
1. Extract the ZIP into a NEW empty directory.
2. cd to that directory.
3. mkdir -p runtime/home runtime/tmp logs
4. env -i PATH="$PATH" HOME="$PWD/runtime/home" TMPDIR="$PWD/runtime/tmp" LANG=C.UTF-8 PYTHONDONTWRITEBYTECODE=1 python -B run_exercise.py > logs/replay.stdout.txt 2> logs/replay.stderr.txt
5. echo "$?"
6. Read results.json; expected 15 named custom cases passed, 3 upstream selftest entrypoints passed, 20 component invocations. Expected whole-harness exit 0.

The runner invokes original modules through Python runpy with the exact argv captured in results.json and logs/*.json. It does not spawn the Easel CLI, Web app, gateway or publisher. Replays regenerate runtime files under fixtures/, snapshots/, and logs/. Publicly sanitized original-run evidence is preserved separately in the ZIP's evidence/ directory. All original upstream source files are under upstream/ with unmodified bytes; source-lock.json holds SHA-256 fingerprints and license information.

Isolation
The outer env -i command starts with no inherited credentials. The runner supplies EASEL_ROOT=fixtures and exercise-local HOME/TMPDIR before loading upstream code. Python bytecode writing is disabled. A process-local audit hook rejects network/subprocess activity and writes outside the extraction directory. This is a narrowly scoped test guard, not an OS security sandbox or general hostile-code isolation guarantee. No machine/global settings were changed. content_guard's .env candidate paths resolve only to this local fixture/copy; no .env or real token is supplied.

Expected negative cases
- Four invalid output-path inputs raise OutputPathError.
- Initial post social_count=365; chosen local target 140 plus/minus 5% (133–147) returns exit 1.
- Initial post includes one SYNTHETIC private-IP string: content_guard detects one proxy-IP finding and returns exit code 7. Seven is not a case/finding count.
- Revised post social_count=143 returns exit 0; revised content scan returns exit 0.
- Invalid manifest kind returns exit 2 and leaves metadata bytes unchanged.
- manifest selftest intentionally emits an invalid-kind argparse error on stderr, then finishes exit 0.

Counting
15 custom named integration cases, 3 original selftest entrypoints, and 20 component invocations are different units; do not add them into a test-case total. wordcount selftest prints eight internal PASS lines; content_guard prints its own category counts. These are not a count of all Easel tests or skills. The pytest suite was not run.

What the result does not prove
No current social-platform rule verification; the 140±5% target is only this exercise's length criterion. No complete semantic quality/accuracy/copyright review, no full publish-checklist agent execution, no model/provider or multimedia pipeline, no authenticated account access, no real publication. Project status remains draft. A profile is context, not an authenticated platform identity; a manifest status is recorded metadata, not external delivery proof.

Observed source boundaries
manifest meta merges selected fields and preserves steps; latest returns the latest step even if failed. manifest does not itself validate output paths. assets derives platform from paths, and indexes the .easel.json file as text; its INDEX.json/tags.json are separate from project .easel.json. archive/apply was deliberately excluded. Some older skill docs mention meta.json while SKILL-SPEC specifies .easel.json. Root license is Apache-2.0, but licensing of all bundled third-party skill references has not been certified; no such skill/reference files are redistributed here.

Attempt history
The original social-source read returned HTTP 403; its full text was not retrieved. Repository contents were inspected. Harness attempt 1 stopped before upstream execution because platform.platform() attempted a subprocess/devnull access; the process-local guard blocked it. The harness's environment-reporting call was changed to os.uname(); attempt 2 completed successfully. Both attempt logs are retained under evidence/logs. No upstream code was changed.

Timestamps
Driver times are UTC. Upstream manifest timestamps use UTC+8 by design; asset-index timestamps use the host local clock (the original isolated run reported UTC-7). Do not compare these strings without accounting for their timezone behavior.

Public edition
This is a publication derivative of the 2026-10-05 learning package, not a new learning run. Historical times, measured results, failure traces, source modules and executable commands are retained. Internal absolute paths in evidence are replaced with <EXERCISE_ROOT> (the historical extraction root) and <PYTHON_STDLIB> (the Python standard-library directory). These placeholders describe recorded paths, not commands to execute. Private retrieval/approval context and the original social-source locator are omitted. The runnable harness and all six upstream modules plus LICENSE retain their original bytes. Replaying the exercise will create paths for your own fresh extraction directory.
