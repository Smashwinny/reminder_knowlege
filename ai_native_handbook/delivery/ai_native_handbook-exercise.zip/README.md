# Task-scoped read delegation: a small reproducible exercise

This is a **self-authored teaching implementation**, derived from concepts in chapter 3 of Alibaba's AI Native handbook. It is not Alibaba code, an official implementation, an OS sandbox, or evidence of enterprise security.

## Publication note

This package preserves the historical experiment evidence from 2026-10-05. Publication preparation did not rerun the experiment. The historical execution record uses `.` for the exercise root in place of the private absolute working directory; commands, timestamps, exit codes, stdout and stderr are unchanged. PACKAGE-MANIFEST.json has been refreshed for the sanitized package.

## Run

Requires Python 3.10 or later. Uses the standard library only; no installation, network, account, secret, production system, or global setting is needed.

Run the six-command sequence below once from this directory.

The output directory must be new. Choose another name for another run so earlier evidence is never overwritten. The script creates three clearly fictional files inside that directory, executes two fresh copies of the same deterministic suite, checks file hashes, and writes summary.json, cases.json, audit.jsonl, normalized-suite.json and stdout.txt.

For six concrete execution-and-inspection commands, run these in order from the standalone exercise directory:

```sh
python3 -B run_experiment.py --output replay-results
python3 -B inspect_results.py --input replay-results --section scope
python3 -B inspect_results.py --input replay-results --section revocation
python3 -B inspect_results.py --input replay-results --section negative-control
python3 -B inspect_results.py --input replay-results --section audit
python3 -B inspect_results.py --input replay-results --section reproducibility
```

The first command performs all six conceptual stages below. Commands 2–6 independently inspect the saved evidence in five dimensions; they do not represent five additional production components or deployments. To run again, replace `replay-results` in all six commands with the same fresh output directory name.

## Six steps

1. Create fixed synthetic task A and task B resources and a trusted resource catalog
2. Model fictional user, Agent, runtime and task identities separately from a bounded read grant
3. Permit only narrower child delegations; check the full active parent chain before each read
4. Test valid reads and denials for another task/runtime, another resource, write, missing grant, expiry and scope expansion
5. Revoke a root grant and test the root, existing child and attempted new child; compare with an intentionally unsafe stale-allow-cache negative control
6. Correlate decisions with actual synthetic file reads, preserve audit records, verify no fixture changes and repeat deterministically

The negative control is deliberately wrong: it checks a previous cached allow before the current revocation state. Its expected result is one synthetic file read after revocation. A passing negative-control test means that the flaw was successfully demonstrated, **not** that this implementation is safe.

## Expected results

- 17 cases meet expectations: 16 intended-design checks and 1 expected unsafe negative control
- The intended-design broker denies new reads after revoking either the root used directly or the ancestor of a child
- No rejected request reaches the actual read function
- A new child cannot be issued from the revoked parent
- Two independently initialized suites produce identical normalized results
- Synthetic source-file hashes remain unchanged

## Source links

Official source: https://g.alistatic.com/s/v/ainativeinfra/ai-native-handbook/0.0.1/ai-native-handbook.pdf

- Printed pp35–38 / PDF40–43: execution/verification loop and independent enforcement
- Printed pp51–54 / PDF56–59: identity, delegation, policy, scope attenuation, resource-side checks and revocation
- Printed p53 / PDF58: short-lived tokens do not replace revocation; audit should correlate the chain
- Printed pp59–61 / PDF64–66: system observability and task trajectories
- Printed p62 / PDF67: handbook's own early-stage/partial-practice limitations

Do not bundle the copyrighted full source PDF or rendered page copies when redistributing this exercise. Link to the official original instead.

## Deliberate limits

The trusted Python process can access its filesystem regardless of this wrapper. Context strings are not authenticated identities; grants are registry records, not real access tokens. Root issuance and revocation represent trusted controller fixtures, not actual user approval flows. The exercise does not implement OAuth, MCP, a credential broker or approval challenges. It does not resist same-process bypass, registry/log tampering, concurrent time-of-check/time-of-use or symlink races. It does not test OS/network isolation, distributed cache invalidation, downstream session termination, crash recovery, revocation latency or data already read. Audit logs are reviewable plain files, not tamper-proof evidence. Resource IDs resolve through a fixed trusted catalog; a path check alone is not claimed as security.

`broker.py` owns the conceptual policy. `run_experiment.py` owns fixtures, cases, assertions and evidence output. The source PDF remains outside this standalone directory.
