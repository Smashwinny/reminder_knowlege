"""Read-only checks on the synthetic experiment's saved evidence."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise SystemExit("FAIL: " + message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--section", required=True,
                        choices=["scope", "revocation", "negative-control", "audit", "reproducibility"])
    args = parser.parse_args()
    directory = Path(args.input)
    summary = json.loads((directory / "summary.json").read_text(encoding="utf-8"))
    cases = json.loads((directory / "cases.json").read_text(encoding="utf-8"))
    audit = [json.loads(line) for line in (directory / "audit.jsonl").read_text(encoding="utf-8").splitlines()]
    by_number = {int(case["case_id"].split("_")[0]): case for case in cases}
    require(len(cases) == 17 and set(by_number) == set(range(1, 18)), "missing/duplicate cases")
    require(all(case["status"] == "pass" for case in cases), "some expectations failed")
    require(all(not event["read_performed"] for event in audit if event["decision"] == "deny"),
            "denied event contains an actual read")

    if args.section == "scope":
        selected = [by_number[n] for n in [*range(1, 12), 15]]
        require(all(by_number[n]["file_reads"] == 0 for n in [3, 4, 5, 6, 7, 9, 10, 11, 15]),
                "scope denial cases performed reads")
        print("PASS scope: 12 cases cover valid root/subset reads, task/runtime/resource/action/grant/expiry limits and untrusted approval text")
        print("PASS denied requests: zero actual file reads on denial paths")
    elif args.section == "revocation":
        for n in [12, 13]:
            require(by_number[n]["detail"].get("post_revoke_reads") == 0, "post-revocation read")
            events = [event for event in audit if event["case_id"] == by_number[n]["case_id"]]
            revoked_at = next(event["event_index"] for event in events if event["event_kind"] == "revocation")
            later_reads = [event for event in events if event["event_index"] > revoked_at
                           and event["event_kind"] == "resource_request"]
            require(later_reads and all(event["decision"] == "deny" and not event["read_performed"]
                                        for event in later_reads), "revocation not enforced in saved events")
        issuance = [event for event in audit if event["case_id"] == by_number[14]["case_id"]
                    and event["event_kind"] == "delegation"]
        require(len(issuance) == 1 and issuance[0]["decision"] == "deny", "new grant issued after revoke")
        print("PASS revocation: new root read denied; existing child read denied; new child delegation denied")
        print("PASS intended-design post-revocation actual reads: 0")
    elif args.section == "negative-control":
        control = by_number[17]
        require(control["negative_control"] and control["detail"].get("expected_vulnerability_observed")
                and control["detail"].get("post_revoke_reads") == 1, "negative control did not expose flaw")
        stale = [event for event in audit if event["case_id"] == control["case_id"]
                 and event["reason"] == "INTENTIONAL_FLAW_stale_cached_allow"]
        require(len(stale) == 1 and stale[0]["read_performed"], "no actual stale-cache read observed")
        print("EXPECTED VULNERABILITY OBSERVED: stale cached allow caused 1 synthetic file read after revocation")
        print("This intentionally unsafe control must not be used as a security implementation")
    elif args.section == "audit":
        require(len({(event["case_id"], event["request_id"]) for event in audit}) == len(audit),
                "duplicate request correlation")
        reads = Counter(event["case_id"] for event in audit if event["read_performed"])
        indices = defaultdict(list)
        for event in audit:
            indices[event["case_id"]].append(event["event_index"])
            for key in ["task", "runtime", "agent", "user", "grant_id", "resource_id", "action", "policy_version", "reason"]:
                require(key in event, "missing audit field: " + key)
        for case in cases:
            require(reads[case["case_id"]] == case["file_reads"], "audit read count mismatch")
            require(indices[case["case_id"]] == list(range(1, case["audit_events"] + 1)), "event sequence mismatch")
        print(f"PASS audit: {len(audit)} events correlate case/request/task/runtime/grant/resource/decision with actual IO")
        print("LIMIT: plain reviewable JSONL, not authenticated or tamper-proof audit storage")
    else:
        normalized = json.loads((directory / "normalized-suite.json").read_text(encoding="utf-8"))
        require(normalized == {"cases": cases, "audit": audit}, "normalized result and individual files disagree")
        serialized = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
        digest = hashlib.sha256(serialized).hexdigest()
        require(digest == summary["normalized_suite_sha256"], "normalized hash mismatch")
        require(summary["two_fresh_suites_identical"] and summary["synthetic_files_unchanged"], "repeat/hash check failed")
        require(summary["fixture_sha256_before"] == summary["fixture_sha256_after"], "before/after mismatch")
        for name, expected in summary["fixture_sha256_after"].items():
            # Names are generated by this experiment, not supplied by an agent request.
            require(name in {"task-a-notes.txt", "task-a-appendix.txt", "task-b-notes.txt"}, "unexpected fixture name")
            require(hashlib.sha256((directory / "synthetic" / name).read_bytes()).hexdigest() == expected,
                    "current synthetic fixture changed")
        print("PASS reproducibility: two fresh suites matched; normalized evidence agrees; all 3 current fixture hashes match")
        print("NORMALIZED_SUITE_SHA256: " + digest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
