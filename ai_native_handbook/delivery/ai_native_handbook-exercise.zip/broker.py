"""Self-authored educational policy model; NOT a security boundary.

All identities and approvals are synthetic trusted fixtures. This module does not
authenticate real callers or defend against code running in its Python process.
"""
from dataclasses import asdict, dataclass
import hashlib
from pathlib import Path


@dataclass(frozen=True)
class Context:
    user: str
    agent: str
    runtime: str
    task: str


@dataclass(frozen=True)
class Grant:
    grant_id: str
    context: Context
    resources: frozenset[str]
    actions: frozenset[str]
    expires_at: int
    parent_id: str | None = None


@dataclass(frozen=True)
class Resource:
    task: str
    path: Path


@dataclass(frozen=True)
class Decision:
    allowed: bool
    reason: str


class Broker:
    """A trusted, single-process application broker over a fixed synthetic catalog.

    No cached allow decision is used. Every read rechecks the current grant chain.
    Paths come only from the fixture catalog, never from a requester-supplied path.
    This is an application design choice, NOT an OS filesystem restriction.
    """

    POLICY_VERSION = "teaching-read-policy-v1"

    def __init__(self, catalog: dict[str, Resource], case_id: str):
        self.catalog = dict(catalog)
        self.case_id = case_id
        self.now = 0
        self.grants: dict[str, Grant] = {}
        self.revoked: set[str] = set()
        self.audit: list[dict] = []
        self.file_reads = 0

    def seed_root_fixture(self, grant: Grant) -> None:
        """Trusted test setup only: models an already-approved root delegation."""
        if grant.parent_id is not None or grant.grant_id in self.grants:
            raise ValueError("invalid root fixture")
        if grant.actions != frozenset({"read"}):
            raise ValueError("fixture supports read only")
        if not grant.resources or any(
            r not in self.catalog or self.catalog[r].task != grant.context.task
            for r in grant.resources
        ):
            raise ValueError("root fixture must belong to one synthetic task")
        self.grants[grant.grant_id] = grant

    def _chain_decision(self, grant_id: str) -> Decision:
        current = grant_id
        seen: set[str] = set()
        while current is not None:
            if current in seen:
                return Decision(False, "grant_cycle")
            seen.add(current)
            grant = self.grants.get(current)
            if grant is None:
                return Decision(False, "unknown_grant")
            if current in self.revoked:
                return Decision(False, "revoked_grant_or_ancestor")
            if self.now >= grant.expires_at:
                return Decision(False, "expired_grant_or_ancestor")
            current = grant.parent_id
        return Decision(True, "active_chain")

    def decide(self, context: Context, grant_id: str, resource_id: str,
               action: str) -> Decision:
        chain = self._chain_decision(grant_id)
        if not chain.allowed:
            return chain
        grant = self.grants[grant_id]
        if context != grant.context:
            return Decision(False, "context_binding_mismatch")
        if action != "read" or action not in grant.actions:
            return Decision(False, "action_out_of_scope")
        resource = self.catalog.get(resource_id)
        if resource is None:
            return Decision(False, "unknown_resource")
        if resource.task != context.task:
            return Decision(False, "resource_task_mismatch")
        if resource_id not in grant.resources:
            return Decision(False, "resource_out_of_scope")
        return Decision(True, "current_policy_allows")

    def _event(self, request_id: str, kind: str, context: Context, grant_id: str,
               resource_id: str, action: str, decision: Decision,
               read_performed: bool = False, **details) -> None:
        self.audit.append({
            "case_id": self.case_id,
            "event_index": len(self.audit) + 1,
            "request_id": request_id,
            "event_kind": kind,
            **asdict(context),
            "grant_id": grant_id,
            "parent_grant_id": self.grants[grant_id].parent_id if grant_id in self.grants else None,
            "resource_id": resource_id,
            "action": action,
            "policy_version": self.POLICY_VERSION,
            "logical_time": self.now,
            "decision": "allow" if decision.allowed else "deny",
            "reason": decision.reason,
            "read_performed": read_performed,
            "details": details,
        })

    def request(self, request_id: str, context: Context, grant_id: str,
                resource_id: str, action: str = "read", *,
                untrusted_claim: str | None = None) -> tuple[Decision, str | None]:
        # The model's self-reported approval text is intentionally not consulted.
        decision = self.decide(context, grant_id, resource_id, action)
        content = None
        details = {"untrusted_claim_ignored": untrusted_claim is not None}
        if decision.allowed:
            content = self.catalog[resource_id].path.read_text(encoding="utf-8")
            self.file_reads += 1
            details["content_sha256"] = hashlib.sha256(content.encode()).hexdigest()
        self._event(request_id, "resource_request", context, grant_id, resource_id,
                    action, decision, read_performed=content is not None, **details)
        return decision, content

    def delegate(self, request_id: str, parent_id: str, caller: Context,
                 child: Grant) -> Decision:
        """Model monotonic scope attenuation; never creates a real credential."""
        decision = self._chain_decision(parent_id)
        parent = self.grants.get(parent_id)
        if decision.allowed:
            if caller != parent.context:
                decision = Decision(False, "parent_context_mismatch")
            elif child.grant_id in self.grants:
                decision = Decision(False, "duplicate_grant_id")
            elif child.parent_id != parent_id:
                decision = Decision(False, "parent_binding_mismatch")
            elif child.context.user != parent.context.user or child.context.task != parent.context.task:
                decision = Decision(False, "child_task_or_user_expansion")
            elif not child.resources or not child.resources <= parent.resources:
                decision = Decision(False, "child_resource_expansion")
            elif not child.actions or not child.actions <= parent.actions:
                decision = Decision(False, "child_action_expansion")
            elif child.expires_at > parent.expires_at or child.expires_at <= self.now:
                decision = Decision(False, "child_expiry_invalid")
            else:
                self.grants[child.grant_id] = child
                decision = Decision(True, "narrower_delegation_created")
        self._event(request_id, "delegation", caller, parent_id, child.grant_id,
                    "delegate", decision, child_context=asdict(child.context),
                    requested_resources=sorted(child.resources),
                    requested_actions=sorted(child.actions),
                    requested_expiry=child.expires_at)
        return decision

    def revoke_from_trusted_controller(self, request_id: str, grant_id: str) -> None:
        """Test control-plane event. Authentication of this controller is unmodeled."""
        grant = self.grants[grant_id]
        self.revoked.add(grant_id)
        self._event(request_id, "revocation", grant.context, grant_id, grant_id,
                    "revoke", Decision(True, "trusted_fixture_revoked"))


class IntentionallyStaleCacheBroker(Broker):
    """Negative control ONLY: demonstrably unsafe cached allow after revocation.

    Used only on this experiment's fictional files. Never use as an implementation.
    """

    POLICY_VERSION = "INTENTIONALLY-UNSAFE-stale-cache-negative-control"

    def __init__(self, catalog: dict[str, Resource], case_id: str):
        super().__init__(catalog, case_id)
        self.allow_cache: set[tuple] = set()

    def decide(self, context: Context, grant_id: str, resource_id: str,
               action: str) -> Decision:
        key = (context, grant_id, resource_id, action)
        if key in self.allow_cache:
            # Intentional flaw: bypasses current chain/revocation/expiry checks.
            return Decision(True, "INTENTIONAL_FLAW_stale_cached_allow")
        decision = super().decide(context, grant_id, resource_id, action)
        if decision.allowed:
            self.allow_cache.add(key)
        return decision
