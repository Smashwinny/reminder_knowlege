# Metrik 真实组件离线实验

历史执行记录：随包测试与结果形成于 2026-10-05 UTC。公开整理仅调整说明文字，未重新执行学习实验；源码、测试、合成输入、结果日志和许可保持原样。

固定源码：keros68/metrik，提交 `637444bdc8d91475f66f5319a15dda0e4be1c652`，版本 0.21.1。上游许可为 AGPL-3.0-or-later，完整许可见 LICENSE。这里包含未经改动的三个真实 JavaScript 模块及两个上游测试文件，哈希和固定链接见 source-manifest.json。

## 实验范围

本实验直接运行真实配额窗口选择、托盘数字决策、倒计时与 token 显示格式化函数。输入全部是合成数据，绝不读取个人日志或凭据，不查询厂商接口，不启动完整桌面应用，不安装 npm 依赖。

这不是后端解析器或账本复刻。Rust/Cargo 在本次环境不可用，因此 Rust 解析、去重、SQLite 合并、缓存输入/输出归一化、配额时效计算与原生桌面效果均没有实测。fixtures/backend-review-NOT-EXECUTED.json 仅保留四个源码阅读例子，不能计入通过数。

## 五步复现

先解压 ZIP，用终端进入本 README 所在目录。需已安装 Node.js 24；本次验证为 Linux x64 / Node.js 24.19.0，其他 Node 主版本未验证。下面五条命令在 Linux 终端依次执行，全部只依赖解压包内材料与 Node，不需要父目录脚本。Windows、PowerShell 与原生桌面应用均未验证。

1. 检查运行时

   `node --version`

2. 核验六个上游文件（含完整许可）的 SHA-256

   `node --permission --allow-fs-read=. verify-source.mjs`

3. 运行两个未经改动的上游测试文件

   `node --permission --allow-fs-read=. --test --test-isolation=none upstream/src/quotaWindows.test.js upstream/src/trayBadge.test.js`

4. 调用真实模块运行 27 个合成场景，并保存完整输入、输出、质量及缺失标记

   `node --permission --allow-fs-read=. --allow-fs-write=./run-output run-scenarios.mjs`

5. 独立重放每个场景两次，核对输出与输入记录

   `node --permission --allow-fs-read=. verify-results.mjs`

预期：第 2、4、5 步 PASS；第 3 步为 23 个上游测试全部通过；第 4、5 步为 27 个场景通过。结果保存在 run-output/results.json。交付前的首轮结果副本和日志在 evidence/，再次运行会更新 run-output/results.json，不会修改源码。

## 如何读结果

- 默认选最短、靠前的有效窗口。只有剩余额度 ≤15% 的百分比窗口进入“最少余量接管”规则。80% 的短窗与 40% 的周窗会选择短窗，而非 40%。README 的“取余量最低窗口”描述较简略，实际算法以固定版本模块和执行结果为准，PRODUCT-CONSTRAINTS 的对应段落可作为辅助说明。
- unavailable 与真实 0 分开；resetExpired 被排除；stale 但未过重置点仍保留。本实验只提供这些标记，未运行产生标记的后端时钟逻辑。
- balance_cny 的 8.4 是金额，不能解释为 8.4%，也不能送入百分比徽标函数。余额 168.5 不受 100% 上限约束。
- exact_duplicate_window 保留三项输入，证明选择操作未变造输入；这不证明账本事件去重。
- compactTokens(null) 实际返回 "0"，它只是格式化器，不能单凭它断言“用量为零”。缺失状态应由调用层维护；本实验不据此判定完整应用有 bug。
- 27 个场景各核对实际输出及输入未改动；后端源码阅读的四例单列，未执行。

## 安全与依赖说明

三个实际模块没有外部导入；测试只用 Node 内置模块。脚本只读本目录及向 run-output 写结果。Node permission 模式限制文件和子进程等能力，但本实验不把它声称为网络隔离机制；执行代码未调用网络接口。托盘画布函数存在于原模块中，但本实验没有调用它，未创建窗口。完整上游 npm 锁文件的 137 个下载位置为 registry.npmjs.org，Rust 工程还含 macOS 专用 Git 依赖；这些依赖均未安装或运行。

## 来源与许可

完整固定版本源码：https://github.com/keros68/metrik/tree/637444bdc8d91475f66f5319a15dda0e4be1c652

included upstream/ 文件均来自上述提交，Copyright © 2026 keros68。本实验配套脚本以同一 AGPL-3.0-or-later 许可提供；无保证。未复制个人日志、私人配置或任何认证材料。
