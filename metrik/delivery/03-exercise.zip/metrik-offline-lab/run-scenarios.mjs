import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { evaluateScenario } from './scenario-engine.mjs';

const fixtureUrl = new URL('./fixtures/scenarios.json', import.meta.url);
const fixtureBytes = fs.readFileSync(fixtureUrl);
const fixture = JSON.parse(fixtureBytes);
const manifest = JSON.parse(fs.readFileSync(new URL('./source-manifest.json', import.meta.url), 'utf8'));
const results = fixture.cases.map((item) => {
  const before = JSON.stringify(item.input);
  const actual = evaluateScenario(item);
  assert.deepEqual(actual, item.expected, `${item.id}: actual upstream output differs from expected`);
  assert.equal(JSON.stringify(item.input), before, `${item.id}: upstream function changed fixture input`);
  return { id: item.id, operation: item.operation, input: item.input, expected: item.expected, actual, note: item.note, status: 'PASS', inputUnchanged: true };
});
const output = {
  schemaVersion: 1,
  generatedAt: new Date().toISOString(),
  runtime: process.version,
  platform: process.platform,
  architecture: process.arch,
  upstreamCommit: manifest.commit,
  fixtureSha256: createHash('sha256').update(fixtureBytes).digest('hex'),
  syntheticDataOnly: true,
  passed: results.length,
  failed: 0,
  results,
  notExecuted: ['Rust adapters', 'Rust token normalization', 'SQLite ledger reconciliation/deduplication', 'backend freshness derivation', 'provider fetch or authentication', 'Tauri desktop application', 'Windows or macOS native UI'],
};
const outputDir = new URL('./run-output/', import.meta.url);
fs.mkdirSync(outputDir, { recursive: true });
fs.writeFileSync(new URL('results.json', outputDir), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({ status: 'PASS', passed: results.length, failed: 0, output: 'run-output/results.json', generatedAt: output.generatedAt }, null, 2));
