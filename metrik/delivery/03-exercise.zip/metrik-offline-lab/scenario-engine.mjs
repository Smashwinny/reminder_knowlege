// Exercise glue only. All decisions and formatting below call unchanged upstream functions.
// There is deliberately no custom implementation of token parsing, deduplication, or quota freshness.
import { bindingWindow, formatReset, isBalanceWindow } from './upstream/src/quotaWindows.js';
import { trayBadgeSpec, trayBadgeText, trayBadgeTooltip, trayBadgeKey } from './upstream/src/trayBadge.js';
import { compactTokens } from './upstream/src/tokenFormat.js';

export function evaluateScenario(item) {
  switch (item.operation) {
    case 'bindingWindow': {
      const selected = bindingWindow(item.input);
      return { selected, selectedIndex: selected === null ? null : item.input.indexOf(selected), isBalance: isBalanceWindow(selected) };
    }
    case 'trayBadge': {
      const spec = trayBadgeSpec(item.input.items);
      return {
        spec,
        text: trayBadgeText(spec?.percent ?? null),
        tooltip: trayBadgeTooltip(item.input.label, spec?.percent ?? null, spec?.stale ?? false),
        key: trayBadgeKey(spec),
      };
    }
    case 'formatReset': return formatReset(item.input);
    case 'compactTokens': return compactTokens(item.input);
    default: throw new Error(`Unknown fixture operation: ${item.operation}`);
  }
}
