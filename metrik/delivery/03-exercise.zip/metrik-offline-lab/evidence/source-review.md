# Metrik 固定版本源码核验

核验时间：2026-10-05。官方仓库 https://github.com/keros68/metrik ，实际取得的提交为 637444bdc8d91475f66f5319a15dda0e4be1c652，提交时间 2026-10-05T11:36:22+08:00，主题 Merge pull request #249 from keros68/release/v0.21.1。package.json 与 Cargo.toml 版本均为 0.21.1。源码工作树保持干净，无改动、提交或推送。

## 1. 产品与依赖：已阅读源码，不等于安装验证

- README 声明它是 Tauri 2 桌面应用，支持 Windows、macOS、Ubuntu 24.04 x86_64。前端 React/ESM JavaScript，后端 Rust/SQLite。
- 本地解析用量、官方额度、估算成本是三种事实。界面不能用 API 价目折算的估值冒充账单；也不能由本地 token 数推导订阅剩余百分比。
- “local-first/没有项目自有云端服务”并不表示完全不联网：配额查询、可选 Cursor 仪表盘、更新检查有网络路径。本次离线实验没有执行这些路径。
- docs/development.md 明确说明 npm run desktop:dev 读取真实本机日志；npm run dev 是演示数据。浏览器演示不应作为真实解析的证明。
- 上游完整构建声明 Node.js 22+、Rust 1.90+；Linux 完整构建还依赖 WebKitGTK/AppIndicator 等系统库。Rust/Cargo 在本次环境的 PATH 与常见标准路径均未发现，因此后端未编译或运行。
- package-lock.json 有 137 个 resolved 下载项，主机全部为 registry.npmjs.org。Cargo.toml 的多数依赖来自 crates.io，另有仅 macOS 使用的 tauri-nspanel Git v2 分支依赖。此次没有安装任何依赖、下载预编译应用、启动桌面应用或执行安装脚本。
- 当前 README、package.json、Cargo.toml 声明 AGPL-3.0-or-later，LICENSE 为完整 GNU AGPL v3 文本。实验包保留完整 LICENSE、逐文件哈希与固定源码地址，不把旧版本 MIT 许可套用到当前提交。

来源：[README](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/README.md)、[开发说明](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/docs/development.md)、[Cargo.toml](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src-tauri/Cargo.toml)、[LICENSE](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/LICENSE)

## 2. Token 与事件身份：仅源码核验

domain.rs:59–120 的 TokenVector.processed = input_uncached + cache_read + cache_write + output，reasoning_output 是子明细，不重复加总。positive_delta 对累积计数取增量；任何主要分量下降视为源计数重置，返回新快照；component_max 对每个分量取最大。

Codex 适配器 codex.rs:310–390 把 input_tokens 拆成未缓存输入及 cache_read，cache_write 为 0；缓存读先限制到输入范围。以累积快照计算正增量，未变化快照不会产生新事件。事件键包含会话身份、时间和累积计数指纹。fork 重放仍推进基线，但在首个 turn_context 前不产生新用量。自报 total 与归一化量不符会增加 total_mismatches。源码内有重复累积快照、语义不一致、占位快照、fork、坏行等单测，但此次未运行。

Claude 适配器 claude.rs:114–195 用 provider message id 分组；缺 id 时退回会话/时间/行身份。同一消息渐进更新采用分量最大值，不把重复快照求和。request/model 冲突只丢弃该分组并记录拒绝，不把其他合法事件一起丢掉。缺 usage 的记录直接跳过。

storage.rs:157–187 用大小、mtime、解析器版本、覆盖起点判断扫描缓存是否可复用。replace_source 在事务中重建观察关系、更新事件和配额，提交后生效。usage_event 与 event_observation 将事件身份与文件观察分离：同一事件来自多个文件不自动计成多个事件。非允许合并的身份冲突报错；Claude/Pi/DSH/部分累计来源按具体规则合并。这个过程没有在本实验中运行。

来源：[TokenVector](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src-tauri/src/domain.rs#L59-L120)、[Codex](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src-tauri/src/adapters/codex.rs#L250-L390)、[Claude](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src-tauri/src/adapters/claude.rs#L114-L195)、[账本](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src-tauri/src/storage.rs#L157-L460)

## 3. 质量、时效和配额缓存：计算仅源码核验

- adapters/mod.rs:64–105 的 malformed_lines、unreadable_lines、rejected_events、total_mismatches 任一大于 0 即 partial。engine.rs:1415–1443 将缺口、错误、部分来源映射为“数据不完整”。这不是精度百分比。
- engine.rs:1343–1372 以同一 now_ms 算 age；official_live 超过 7 分钟标 stale，其他质量超过 15 分钟标 stale；重置点已过去也为 stale，另有 resetExpired=true。阈值判断是 >，不是 >=。
- quota.rs:287–344 成功取得非空窗口后事务性整体替换该 adapter 的配额；没有样本时保留旧行，不写假零。账户变化和开关变化另有失效边界。
- quota.rs:362–415 区分成功缓存 TTL 与失败/空结果重试 TTL，手动 force 可绕过。不同 provider 的 TTL 不同，所以不能把显示 stale 阈值当成统一轮询周期。
- “陈旧但未过重置点”和“旧周期已结束”不同：JS 选择器保留前者，排除后者。我们的实测只覆盖已有标记进入 JS 后的行为，不覆盖上述时间差计算、缓存读写、鉴权或网络调用。

来源：[诊断](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src-tauri/src/adapters/mod.rs#L64-L105)、[时效派生](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src-tauri/src/engine.rs#L1343-L1372)、[配额刷新](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src-tauri/src/quota.rs#L287-L415)

## 4. 已执行的真实组件实验

实际复制并核对哈希的文件为 src/quotaWindows.js、src/quotaWindows.test.js、src/trayBadge.js、src/trayBadge.test.js、src/tokenFormat.js。没有改写其中算法。模块无外部导入，测试只有 Node 内置依赖。调用托盘决策函数，但不调用画布绘图函数。

2026-10-05T06:07:26Z 至 06:07:27Z，Linux x64 / Node.js v24.19.0：两个上游测试文件 23/23 通过；合成场景 27/27 通过；27 个场景各重放两次结果一致，记录的输入与输出相符。四个后端阅读例子明确 NOT_EXECUTED，不计入通过数。

关键已验证结果：

1. 80% 的短窗 + 40% 周窗选择 80%，不是全局最小；周窗 15% 时才接管。多个告急窗再取最低，平局保留输入排名。
2. available=false 的占位 0 被排除；available=true 的 0 正常代表耗尽。托盘 null 显示 --，真 0 显示 0。
3. resetExpired=true 被排除；stale=true 且未过重置点仍可选，stale 与 quality 字段原样保留。
4. balance_cny=8.4 不参与 15% 告急比较；单余额 168.5 原样保留。金额不得传入百分比徽标，否则会按百分比规则钳制。
5. 重复窗口输入完整保留，选择器取第一项；这不等价于用量事件去重。
6. formatReset(119.7) 为“2 小时 0 分”；null 为“暂不可用”。它不计算配额过期。
7. compactTokens(null) 实际返回 "0"；说明格式化器无法独自表达缺失，用量可用性必须另看。没有测试完整 UI，因此不能据此宣称整个产品误报。

来源：[配额选择模块](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src/quotaWindows.js)、[产品规则](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/docs/PRODUCT-CONSTRAINTS.md#L45-L64)、[托盘模块](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src/trayBadge.js)、[格式化](https://github.com/keros68/metrik/blob/637444bdc8d91475f66f5319a15dda0e4be1c652/src/tokenFormat.js)

## 5. 文档与当前源码的边界

README/guide 用“最低余量”概括窗口选择，当前代码和 PRODUCT-CONSTRAINTS 的规则更精确，应以前述实测为准。ARCHITECTURE 开头仍描述按 Today/7/30 天扩展扫描，末尾有“计划中的同步”；当前 engine.rs:30–44、186–203 则使用 182 天保留期并执行 sync::run_sync。教学不要把这些旧说明直接当当前完整行为。保留期/同步实现仅阅读，未做执行验证。

## 6. 仍未验证

完整 npm/build/cargo 测试；真实各 Agent 日志语义；Rust 解析、事件去重、SQLite 事务与质量推导；后台 quota TTL、时钟时效计算、账户切换；所有实时额度/认证/凭据；Windows、macOS、Ubuntu 原生 UI；真实性能、系统钩子与更新器；多设备同步。

实验失败/环境边界应说“Rust 后端无法在此次范围内执行”，不能以自写 Python/JS 仿造 ledger 替代上游并宣称验证完成。
