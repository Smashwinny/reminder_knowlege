import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { evaluateScenario } from './scenario-engine.mjs';

const fixtureBytes = fs.readFileSync(new URL('./fixtures/scenarios.json', import.meta.url));
const fixture = JSON.parse(fixtureBytes);
const output = JSON.parse(fs.readFileSync(new URL('./run-output/results.json', import.meta.url), 'utf8'));
assert.equal(output.fixtureSha256, createHash('sha256').update(fixtureBytes).digest('hex'));
assert.equal(output.results.length, fixture.cases.length);
for (const [i, item] of fixture.cases.entries()) {
  const first = evaluateScenario(item);
  const second = evaluateScenario(item);
  assert.deepEqual(first, second, `${item.id}: non-deterministic replay`);
  assert.deepEqual(first, item.expected, `${item.id}: replay disagrees with expected result`);
  assert.deepEqual(output.results[i].input, item.input, `${item.id}: recorded input lost metadata`);
  assert.deepEqual(output.results[i].actual, first, `${item.id}: captured output differs from rerun`);
}
const stale = output.results.find(r => r.id === 'stale_retained');
assert.equal(stale.actual.selected.view.stale, true);
assert.equal(stale.actual.selected.view.quality, 'official_snapshot');
const duplicates = output.results.find(r => r.id === 'exact_duplicate_window');
assert.equal(duplicates.input.length, 3);
assert.equal(duplicates.actual.selectedIndex, 0);
const notExecuted = JSON.parse(fs.readFileSync(new URL('./fixtures/backend-review-NOT-EXECUTED.json', import.meta.url), 'utf8'));
assert.equal(notExecuted.status, 'SOURCE_REVIEW_ONLY_NOT_EXECUTED');
console.log(JSON.stringify({ checkedAt: new Date().toISOString(), status: 'PASS', deterministicCases: fixture.cases.length, capturedInputsAndOutputsMatch: true, backendReviewCasesExcludedFromPassCount: notExecuted.cases.length }, null, 2));
