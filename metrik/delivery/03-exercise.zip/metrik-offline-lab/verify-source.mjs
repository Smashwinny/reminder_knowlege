import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const manifest = JSON.parse(fs.readFileSync(new URL('./source-manifest.json', import.meta.url), 'utf8'));
for (const file of manifest.files) {
  const bytes = fs.readFileSync(new URL(file.path, import.meta.url));
  const actual = createHash('sha256').update(bytes).digest('hex');
  assert.equal(actual, file.sha256, `Upstream source differs: ${file.path}`);
}
console.log(JSON.stringify({
  checkedAt: new Date().toISOString(),
  status: 'PASS',
  checkedFiles: manifest.files.length,
  commit: manifest.commit,
  license: manifest.license,
  runtime: process.version,
  platform: process.platform,
  dependencyInstallRequired: false,
}, null, 2));
