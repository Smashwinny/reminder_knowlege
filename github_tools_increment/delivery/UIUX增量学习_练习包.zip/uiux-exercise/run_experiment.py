#!/usr/bin/env python3
"""Portable, standard-library-only source exercise. Never install this as a skill.

Run from this file's directory, in order:
  python3 -B run_experiment.py snapshot
  python3 -B run_experiment.py search
  python3 -B run_experiment.py rank
  python3 -B run_experiment.py design
  python3 -B run_experiment.py tests
  python3 -B run_experiment.py verify

The synthetic brief contains no private data. Only results/ and a scratch
temporary directory are written. Upstream persistence functions are not called.
"""
import collections
import csv
import datetime
import hashlib
import importlib
import io
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
SCRIPTS = SOURCE / "src/ui-ux-pro-max/scripts"
DATA = SCRIPTS.parent / "data"
RESULTS = ROOT / "results"
COMMIT = "477bcb28c9812b385cb51a4605ddf30d7b2266e2"
REPOSITORY = "https://github.com/nextlevelbuilder/ui-ux-pro-max-skill"
sys.dont_write_bytecode = True
sys.path.insert(0, str(SCRIPTS))


def no_network(event, args):
    if event.startswith("socket."):
        raise RuntimeError("This source exercise does not permit networking")


sys.addaudithook(no_network)
import core  # noqa: E402
import design_system as ds  # noqa: E402

QUERIES = [
    ("product", "SaaS dashboard"),
    ("style", "minimalism"),
    ("color", "SaaS"),
    ("ux", "keyboard focus modal"),
    ("ux", "zzqqxx totally made up gibberish"),
]
DESIGN_QUERIES = {
    "base": "SaaS dashboard accessible",
    "dark_words": "SaaS dashboard accessible dark mode",
    "unknown": "zzqqxx flarble blorpt",
}
CHECKS = []


def stable(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value):
    return hashlib.sha256(stable(value).encode("utf-8")).hexdigest()


def check(name, condition, detail=None):
    CHECKS.append({"name": name, "passed": bool(condition), "detail": detail})


def clear_caches():
    core._csv_cache.clear()
    core._bm25_cache.clear()
    core._DOMAIN_KEYWORDS = None
    core._DOMAIN_KEYWORDS_SIGNATURE = None


def source_manifest():
    return {str(p.relative_to(SOURCE)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(SOURCE.rglob("*")) if p.is_file()}


def read_rows(filename):
    records = []
    with (DATA / filename).open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        previous = 1
        for row_number, row in enumerate(reader, 1):
            records.append({"logical_data_row": row_number,
                            "physical_lines": [previous + 1, reader.line_num],
                            "row": row})
            previous = reader.line_num
    return records


def row_evidence(filename, record, key=None):
    path = "src/ui-ux-pro-max/data/" + filename
    start, end = record["physical_lines"]
    return {"file": path, "logical_data_row": record["logical_data_row"],
            "physical_lines": [start, end], "source_key": key,
            "file_sha256": hashlib.sha256((DATA / filename).read_bytes()).hexdigest(),
            "canonical_row_json_sha256": digest(record["row"]),
            "url": f"{REPOSITORY}/blob/{COMMIT}/{path}#L{start}-L{end}",
            "row": record["row"]}


def search_probe():
    return [core.search(query, domain, 3, diagnostics=True) for domain, query in QUERIES]


def design_probe():
    generator = ds.DesignSystemGenerator()
    return {label: generator.generate(query, "Synthetic Team Dashboard")
            for label, query in DESIGN_QUERIES.items()}


def fresh_probe(kind, seed):
    env = {"PATH": os.defpath, "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
           "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": str(seed)}
    command = [sys.executable, "-B", str(Path(__file__).resolve()), "_probe", kind]
    p = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True,
                       encoding="utf-8", timeout=45, check=False)
    if p.returncode:
        raise RuntimeError(f"Probe failed: {p.returncode}: {p.stderr}")
    return json.loads(p.stdout), {"argv": command, "hash_seed": seed,
                                 "return_code": p.returncode}


def step_snapshot():
    files = source_manifest()
    check("pinned canonical source files present", all(
        f"src/ui-ux-pro-max/scripts/{name}" in files
        for name in ("core.py", "design_system.py", "reasoning_contract.py", "search.py", "validate_data.py")))
    check("MIT copyright and permission notice retained", all(
        text in (SOURCE / "LICENSE").read_text()
        for text in ("MIT License", "Copyright (c) 2024 Next Level Builder",
                     "The above copyright notice and this permission notice")))
    return {"repository": REPOSITORY, "commit": COMMIT,
            "python": sys.version, "file_count": len(files), "files": files,
            "dataset_counts": {name: len(read_rows(name)) for name in
                               ("products.csv", "colors.csv", "styles.csv", "ui-reasoning.csv",
                                "landing.csv", "typography.csv", "ux-guidelines.csv")},
            "network_policy": "Python socket audit events rejected; no network needed",
            "scope": "Pinned source study only; no generated website or measured usability"}


def step_search():
    clear_caches()
    baseline = search_probe()
    for repetition in range(1, 4):
        check(f"warm repeated search set {repetition} equals baseline", search_probe() == baseline)
    clear_caches()
    check("cold rebuilt search set equals baseline", search_probe() == baseline)
    fresh = []
    for seed in (0, 1, 8675309):
        value, command = fresh_probe("search", seed)
        check(f"fresh search process seed {seed} equals baseline", value == baseline)
        fresh.append({**command, "output_sha256": digest(value)})
    evidence = []
    for result in baseline:
        records = read_rows(result["file"])
        trace = []
        for rank, output in enumerate(result["results"], 1):
            matches = [record for record in records if all(record["row"].get(k) == v for k, v in output.items())]
            check(f"{result['domain']} / {result['query']} result {rank} has one exact source row", len(matches) == 1)
            if len(matches) == 1:
                trace.append({"rank": rank, **row_evidence(result["file"], matches[0])})
        evidence.append({"result": result, "source_trace": trace})
    check("nonsense direct UX search abstains", baseline[-1]["count"] == 0 and baseline[-1]["diagnostics"]["abstained"])
    check("style alias is exact identity rather than zero-score failure",
          baseline[1]["diagnostics"]["reason"] == "exact-identity" and baseline[1]["count"] == 1)
    return {"queries": QUERIES, "baseline_sha256": digest(baseline), "results": evidence,
            "fresh_processes": fresh,
            "caveat": "Stable retrieval does not establish fit or usability; standalone color query selects Micro SaaS first."}


# Independent scorer: same documented token contract, separate counting and formula.
STOPWORDS = set("to in on at is of by or an if no so do be we it as the and for are was".split())
SYNONYMS = {"q&a": "question answer", "e-commerce": "ecommerce", "dark-mode": "dark",
            "darkmode": "dark", "light-mode": "light", "lightmode": "light", "a11y": "accessibility",
            "nav": "navigation", "sign-up": "signup", "log-in": "login", "colour": "color",
            "colours": "colors", "customisation": "customization", "organisation": "organization",
            "behaviour": "behavior", "ux/ui": "ux ui"}


def independent_tokens(text):
    text = text.lower()
    for old, new in sorted(SYNONYMS.items(), key=lambda item: -len(item[0])):
        text = re.sub(r"(?<!\w)" + re.escape(old) + r"(?!\w)", new, text, flags=re.I)
    return [x for x in re.sub(r"[^\w\s]", " ", text).split() if len(x) >= 2 and x not in STOPWORDS]


def step_rank():
    query = "SaaS dashboard"
    config = core.CSV_CONFIG["product"]
    records = read_rows(config["file"])
    documents = [" ".join(record["row"].get(col, "") for col in config["search_cols"]) for record in records]
    tokens = [independent_tokens(doc) for doc in documents]
    N = len(tokens)
    avgdl = sum(map(len, tokens)) / N
    df = collections.Counter(term for doc in tokens for term in set(doc))
    q_tokens = independent_tokens(query)
    calculated = []
    for i, document in enumerate(tokens):
        tf = collections.Counter(document)
        score = sum(math.log(1 + (N - df[t] + 0.5) / (df[t] + 0.5)) *
                    (tf[t] * 2.5) / (tf[t] + 1.5 * (0.25 + 0.75 * len(document) / avgdl))
                    for t in q_tokens if t in df)
        calculated.append((i, score))
    calculated.sort(key=lambda item: (-item[1], item[0]))
    upstream = core.BM25()
    upstream.fit(documents)
    actual = upstream.score(query)
    deltas = [abs(dict(calculated)[i] - score) for i, score in actual]
    check("independent tokenization agrees on all 192 real product documents", tokens == upstream.corpus)
    check("independent scores agree for all product rows within 1e-12", max(deltas) <= 1e-12)
    check("full ranking including tied rows agrees", [x[0] for x in calculated] == [x[0] for x in actual])
    result = core.search(query, "product", 3, diagnostics=True)
    projected = [{c: records[i]["row"].get(c, "") for c in config["output_cols"]} for i, _ in calculated[:3]]
    check("public search top three equals independently scored projections", result["results"] == projected)
    check("diagnostic top score equals independent top score", abs(result["diagnostics"]["top_score"] - calculated[0][1]) <= 1e-12)
    rank_rows = [{"rank": rank, "logical_data_row": i + 1, "product": records[i]["row"]["Product Type"],
                  "independent_score": score, "upstream_score": dict(actual)[i]}
                 for rank, (i, score) in enumerate(calculated, 1)]
    return {"query": query, "formula": "IDF=ln(1+(N-df+0.5)/(df+0.5)); k1=1.5; b=0.75",
            "score_is_not_probability": True, "N": N, "avgdl": avgdl, "max_absolute_delta": max(deltas),
            "ranks": rank_rows, "top_three_source_trace": [row_evidence("products.csv", records[i]) for i, _ in calculated[:3]],
            "limitation": "Agreement checks this pinned implementation and stated token contract; it is not an independent relevance benchmark."}


IDENTITIES = {"product": ("products.csv", "Product Type"), "reasoning": ("ui-reasoning.csv", "UI_Category"),
              "style": ("styles.csv", "Style ID"), "color": ("colors.csv", "Product Type"),
              "typography": ("typography.csv", "Font Pairing Name"), "landing": ("landing.csv", "Pattern Name")}
COLOR_MAP = {"primary": "Primary", "on_primary": "On Primary", "secondary": "Secondary", "on_secondary": "On Secondary",
             "accent": "Accent", "on_accent": "On Accent", "background": "Background", "foreground": "Foreground",
             "card": "Card", "card_foreground": "Card Foreground", "muted": "Muted", "muted_foreground": "Muted Foreground",
             "border": "Border", "destructive": "Destructive", "on_destructive": "On Destructive", "ring": "Ring",
             "notes": "Notes", "cta": "Accent", "text": "Foreground", "on_cta": "On Accent"}


def trace_design(label, generated):
    evidence = {}
    for kind, (filename, key) in IDENTITIES.items():
        identity = generated["source_identities"][kind]
        if identity is None:
            evidence[kind] = {"source_identity": None, "meaning": "No matched source identity; default/fallback must be disclosed"}
            continue
        matches = [r for r in read_rows(filename) if r["row"].get(key) == identity]
        check(f"{label} {kind} identity maps to exactly one source row", len(matches) == 1)
        if len(matches) == 1:
            evidence[kind] = row_evidence(filename, matches[0], {key: identity})
    field_checks = []
    for output_key, source_key in COLOR_MAP.items():
        source = evidence["color"]["row"].get(source_key)
        value = generated["colors"][output_key]
        field_checks.append({"output_field": f"colors.{output_key}", "source_field": source_key,
                             "source_value": source, "output_value": value, "literal_match": source == value})
    check(f"{label} all 20 color output fields literally trace to chosen palette",
          all(item["literal_match"] for item in field_checks))
    return {"identities": evidence, "color_field_trace": field_checks,
            "derivations_declared_by_upstream": generated["source_derivations"]}


def step_design():
    clear_caches()
    baseline = design_probe()
    check("repeated generator output equals baseline", design_probe() == baseline)
    clear_caches()
    check("cold generator output equals baseline", design_probe() == baseline)
    fresh = []
    for seed in (0, 1, 8675309):
        value, command = fresh_probe("design", seed)
        check(f"fresh generator process seed {seed} equals baseline", value == baseline)
        fresh.append({**command, "output_sha256": digest(value)})
    traces = {label: trace_design(label, value) for label, value in baseline.items()}
    check("unknown brief explicitly flags default reasoning", baseline["unknown"]["reasoning_default"] is True)
    check("unknown brief has no matched product or reasoning identity", all(
        baseline["unknown"]["source_identities"][k] is None for k in ("product", "reasoning")))
    check("base brief activates UX-focused rule", any(
        r["condition"] == "if_ux_focused" for r in baseline["base"]["activated_rules"]))
    category = baseline["base"]["category"]
    source = next(r for r in read_rows("colors.csv") if r["row"]["Product Type"] == category)
    light = ds._select_palette_for_mode([source["row"]], "light", category)
    dark = ds._select_palette_for_mode([source["row"]], "dark", category)
    differences = {key: {"source": source["row"].get(key), "derived": value}
                   for key, value in dark.items() if value != source["row"].get(key)}
    check("controlled light helper returns the exact fixed source palette", light == source["row"])
    check("controlled dark helper preserves product identity", dark["Product Type"] == category)
    check("controlled dark helper declares derivation", dark.get("_mode_derivation") == "derived-dark")
    check("controlled dark helper yields dark background", ds._palette_is_dark(dark))
    check("controlled dark focus ring contrast meets helper threshold", ds._contrast_ratio(dark["Ring"], dark["Background"]) >= 3)
    return {"queries": DESIGN_QUERIES, "results": baseline, "source_trace": traces, "fresh_processes": fresh,
            "observations": [
                {"name": "Full-query lexical sensitivity", "base_category": baseline["base"]["category"],
                 "dark_words_category": baseline["dark_words"]["category"],
                 "changed": baseline["base"]["category"] != baseline["dark_words"]["category"],
                 "explanation": "Appending dark mode changes the product retrieval query. There is no public explicit color-mode parameter. This is not an isolated color-mode treatment."},
                {"name": "Unknown brief still gets fallback recommendation", "default_flag": baseline["unknown"]["reasoning_default"],
                 "explanation": "This differs from direct search abstention. Generated style/color/font fields are not evidence that the requested product was found."}],
            "controlled_dark_palette": {"category": category, "source_trace": row_evidence("colors.csv", source),
                                        "light": light, "dark": dark, "derived_differences": differences,
                                        "ring_background_contrast": ds._contrast_ratio(dark["Ring"], dark["Background"])},
            "limitation": "No website rendered; no accessibility, task success, visual quality, or conversion outcome established."}


TEST_NAMES = [
    "test_core.TestTokenizer", "test_core.TestBm25CoreBehavior", "test_core.TestSearchDomains",
    "test_core.TestDomainDetection", "test_core.TestReasoningMatch", "test_core.TestDiagnosticsContracts",
    "test_design_system_mode.TestLuminance", "test_design_system_mode.TestModeResolution",
    "test_design_system_mode.TestPaletteSelection", "test_design_system_mode.TestAntiPatternGating",
    "test_design_system_mode.TestEndToEndCoherence",
    "test_data_contracts.TestStyleIdentityContract", "test_data_contracts.TestReasoningContract",
]


def step_tests():
    sys.path.insert(0, str(SCRIPTS / "tests"))
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromNames(TEST_NAMES)
    with tempfile.TemporaryDirectory(prefix="uiux-test-", dir=RESULTS) as temp_dir:
        old_temp = tempfile.tempdir
        tempfile.tempdir = temp_dir
        try:
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
        finally:
            tempfile.tempdir = old_temp
    (RESULTS / "upstream-tests.log").write_text(stream.getvalue(), encoding="utf-8")
    return {"selected_names": TEST_NAMES, "tests_run": result.testsRun,
            "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
            "successful": result.wasSuccessful(), "log": "results/upstream-tests.log",
            "excluded": ["test_core.TestPersistence (all 3 tests)",
                         "test_design_system_mode.TestLightResultOutputCoherence (all 4 formatting tests)",
                         "test_data_contracts.TestLandingAndStackContract", "test_data_contracts.TestGeneratedCatalogContract",
                         "All other test modules; full aggregate CI; installers; gallery; external integrations"],
            "counting": "unittest method count; subTest loops are not added to this count; separate from our evidence checks"}


def step_verify():
    snapshot = json.loads((RESULTS / "snapshot.json").read_text())
    check("source snapshot unchanged after experiment", source_manifest() == snapshot["result"]["files"])
    reports = {name: json.loads((RESULTS / (name + ".json")).read_text())
               for name in ("snapshot", "search", "rank", "design", "tests")}
    check("all five earlier step return codes are zero", all(r["return_code"] == 0 for r in reports.values()))
    evidence_checks = [check for report in reports.values() for check in report["checks"]]
    check("all earlier custom evidence checks pass", all(c["passed"] for c in evidence_checks))
    check("selected upstream regression methods pass", reports["tests"]["result"]["successful"])
    return {"prior_custom_evidence_checks": len(evidence_checks),
            "prior_custom_evidence_passes": sum(c["passed"] for c in evidence_checks),
            "verification_checks": len(CHECKS),
            "upstream_regression_methods": reports["tests"]["result"]["tests_run"],
            "upstream_regression_failures": reports["tests"]["result"]["failures"],
            "upstream_regression_errors": reports["tests"]["result"]["errors"],
            "observed_limitations": reports["design"]["result"]["observations"],
            "scope": "One executable UI UX Pro Max increment; not all projects in the broader catalog."}


def utc_now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "_probe":
        print(stable(search_probe() if sys.argv[2] == "search" else design_probe()))
        raise SystemExit(0)
    steps = {"snapshot": step_snapshot, "search": step_search, "rank": step_rank,
             "design": step_design, "tests": step_tests, "verify": step_verify}
    if len(sys.argv) != 2 or sys.argv[1] not in steps:
        raise SystemExit("Usage: python3 -B run_experiment.py {snapshot|search|rank|design|tests|verify}")
    RESULTS.mkdir(exist_ok=True)
    step = sys.argv[1]
    started = utc_now()
    tic = time.monotonic()
    payload = {"step": step, "argv": [sys.executable, "-B", "run_experiment.py", step],
               "started_at_utc": started}
    try:
        result = steps[step]()
        rc = int(any(not c["passed"] for c in CHECKS) or (step == "tests" and not result["successful"]))
        payload.update(result=result, return_code=rc)
    except Exception as exc:
        payload.update(return_code=1, error=f"{type(exc).__name__}: {exc}")
    payload.update(ended_at_utc=utc_now(), elapsed_seconds=time.monotonic() - tic, checks=CHECKS)
    (RESULTS / f"{step}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: payload[k] for k in ("step", "return_code", "started_at_utc", "ended_at_utc", "elapsed_seconds")}, ensure_ascii=False))
    print(f"Evidence: results/{step}.json; custom checks: {sum(c['passed'] for c in CHECKS)}/{len(CHECKS)}")
    if payload.get("error"):
        print(payload["error"], file=sys.stderr)
    raise SystemExit(payload["return_code"])
