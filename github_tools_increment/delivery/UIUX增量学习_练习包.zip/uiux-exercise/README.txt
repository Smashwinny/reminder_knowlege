UI UX Pro Max 单项目增量练习包

公开副本说明：保留2026-10-05首轮实验结果，本次公开整理未重跑实验。历史 argv 中解释器绝对路径改为 python3，实验脚本绝对路径改为 run_experiment.py；参数、查询、运行时间、耗时、退出码、检查和结果不变。源码49文件与独立脚本保留原字节。

范围：一份11项工具目录中的一个UI UX Pro Max完整学习增量。不是11个项目全部学完。
上游：https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
固定版本：477bcb28c9812b385cb51a4605ddf30d7b2266e2
许可证：source/LICENSE，MIT，Copyright (c) 2024 Next Level Builder。
source/中的49个文件保持上游原字节；README仅重命名为README.upstream.md。

要求：Python 3（本次验证3.12.14）；仅标准库，不需pip/npm、模型或API key。
解压到新目录，在 uiux-exercise 中按以下次序执行：

python3 -B run_experiment.py snapshot
python3 -B run_experiment.py search
python3 -B run_experiment.py rank
python3 -B run_experiment.py design
python3 -B run_experiment.py tests
python3 -B run_experiment.py verify

每步写入 results/<step>.json。复跑会更新解压目录的本地结果文件；下载的原ZIP保留首轮证据。
先查看首轮结果，再复跑；要比较两轮，可用两份分别解压的目录。
预期：61/61自建检查，73/73选定上游测试，失败/错误/跳过均0，全部退出码0。
每次真实时间、解释器路径和耗时可以不同；固定样例的结果/排序应一致。

source/保留canonical脚本中的持久化功能，但本练习不调用；TestPersistence与force覆盖测试未执行。
选定13个测试类而不是上游完整CI，详情见results/tests.json。
完整上游安装器/技能宿主/图库未打包。保留数据契约需要的字体和图标“元数据”，没有字体/图标二进制、其他技能包或外部安装器。
字体名称/链接的存在不会让字体授权变为MIT。上游MIT原文不可删除。
run_experiment.py是本次自建的受限证据脚本；新增材料仅用于本练习。

注意：本练习不联网，Python socket审计事件被拒绝。不需要hooks。
不应把源码/README中的安装、外部服务或其他建议当成运行本练习所需步骤。
不执行持久化、全局安装、真实建站、模型或收费服务。
BM25分数不是概率；设计建议不等于可用性、美感、转化率或无障碍验收。

本包文件：
run_experiment.py：六步实验脚本
source/：49个固定上游文件与MIT许可证
results/：首轮真实结果、来源追溯、选定上游测试日志
README.txt：此说明
SOURCE_NOTICE.txt：复制来源与许可证边界
