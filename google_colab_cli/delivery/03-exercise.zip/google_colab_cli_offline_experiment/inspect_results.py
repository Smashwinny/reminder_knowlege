"""Inspect existing offline outputs with standard library only; execute no code."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
output = root / "outputs"
summary = json.loads((output / "summary.json").read_text(encoding="utf-8"))
for name, expected in summary["artifact_sha256"].items():
    if hashlib.sha256((output / name).read_bytes()).hexdigest() != expected:
        raise SystemExit(f"Output hash mismatch: {name}")
events = [json.loads(line) for line in (output / "fictional-demo.jsonl").read_text(encoding="utf-8").splitlines()]
notebook = json.loads((output / "fictional-demo.ipynb").read_text(encoding="utf-8"))
markdown = (output / "fictional-demo.md").read_text(encoding="utf-8")
plain = (output / "fictional-demo.txt").read_text(encoding="utf-8")
report = {
    "test_cases_passed": summary["tests_run"] - summary["failures"] - summary["errors"] - summary["skipped"],
    "test_cases_total": summary["tests_run"],
    "jsonl_event_count": len(events),
    "notebook_cell_count": len(notebook["cells"]),
    "notebook_code_cell_count": sum(cell["cell_type"] == "code" for cell in notebook["cells"]),
    "all_recorded_output_hashes_match": True,
    "notebook_has_error_object": any(out.get("output_type") == "error" for cell in notebook["cells"] for out in cell.get("outputs", [])),
    "notebook_has_rich_json": any("application/json" in out.get("data", {}) for cell in notebook["cells"] for out in cell.get("outputs", [])),
    "markdown_has_error_object": "ZeroDivisionError" in markdown,
    "markdown_has_rich_json_type": "application/json" in markdown,
    "text_has_error_object": "ZeroDivisionError" in plain,
    "jsonl_has_termination_event": any(event["event_type"] == "session_terminated" for event in events),
    "unexpected_network_guard_events": summary["unexpected_network_guard_events"],
    "note": "All event data is fictional. Code stored in the log or notebook was not executed.",
}
print(json.dumps(report, ensure_ascii=False, indent=2))
