"""Verify the bundled upstream bytes without importing the project."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "source_manifest.json").read_text(encoding="utf-8"))
for entry in manifest["files"]:
    path = root / entry["bundle_path"]
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != entry["sha256"]:
        raise SystemExit(f"SHA-256 mismatch: {entry['bundle_path']}")
    print(f"OK {entry['bundle_path']} {actual}")
print(f"Verified {len(manifest['files'])} unchanged upstream files at {manifest['commit']}")
