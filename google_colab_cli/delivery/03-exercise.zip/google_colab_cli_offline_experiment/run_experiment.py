#!/usr/bin/env python3
"""Offline exercise using unmodified Google Colab CLI history/export modules.

This harness never runs recorded code and never calls Colab. Its guard is a
process-local safety check, not an operating-system security sandbox.
"""
from __future__ import annotations

import ast
import contextlib
import datetime as dt
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "runtime"
OUTPUT = ROOT / "outputs"
for folder in [RUNTIME / "home", RUNTIME / "tmp", RUNTIME / "cache", OUTPUT]:
    folder.mkdir(parents=True, exist_ok=True)
os.environ["HOME"] = str(RUNTIME / "home")
os.environ["USERPROFILE"] = str(RUNTIME / "home")
os.environ["XDG_CONFIG_HOME"] = str(RUNTIME / "home" / ".config")
os.environ["XDG_CACHE_HOME"] = str(RUNTIME / "cache")
os.environ["JUPYTER_CONFIG_DIR"] = str(RUNTIME / "home" / ".jupyter")
os.environ["JUPYTER_DATA_DIR"] = str(RUNTIME / "home" / "jupyter_data")
os.environ["TMPDIR"] = os.environ["TMP"] = os.environ["TEMP"] = str(RUNTIME / "tmp")
tempfile.tempdir = str(RUNTIME / "tmp")
sys.dont_write_bytecode = True
STARTED = dt.datetime.now(dt.timezone.utc).isoformat()
GUARD_EVENTS: list[dict] = []


def beneath(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (ValueError, OSError):
        return False


def guard(event, args):
    # No sockets, DNS, browser/process launch, or writes outside this exercise.
    if event.startswith("socket.") or event in {"subprocess.Popen", "os.system"}:
        GUARD_EVENTS.append({"event": event, "blocked": True})
        raise PermissionError("Offline exercise blocked network/process action")
    if event == "open" and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.fsdecode(args[0]))
        flags = args[2] if len(args) > 2 else 0
        if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
            if not beneath(path, ROOT):
                GUARD_EVENTS.append({"event": "write_outside_exercise", "blocked": True})
                raise PermissionError("Writes must stay within exercise directory")


sys.addaudithook(guard)
sys.path.insert(0, str(ROOT / "vendor"))
import nbformat  # noqa: E402
from colab_cli.history import HistoryLogger  # noqa: E402
from colab_cli.converter import export_history, convert_history_to_ipynb  # noqa: E402


def synthetic_events():
    """Fictional records only. The code field is inert text, never executed."""
    records = [
        {"event_type": "session_created", "endpoint": "fictional-endpoint", "accelerator": "NONE"},
        {"event_type": "execution", "code": "print('离线学习 ☕')", "outputs": [{"text": "离线学习 ☕\n"}]},
        {"event_type": "execution", "code": "1 / 0", "outputs": [{"output_type": "error", "ename": "ZeroDivisionError", "evalue": "division by zero", "traceback": ["Synthetic traceback", "ZeroDivisionError: division by zero"]}]},
        {"event_type": "execution", "code": "display({'answer': 42})", "outputs": [{"output_type": "display_data", "data": {"text/plain": "{'answer': 42}", "application/json": {"answer": 42}}, "metadata": {}}]},
        {"event_type": "execution", "source": "piped", "code": "printf 'shell text only\\n'", "outputs": [{"text": "shell text only\n"}]},
        {"event_type": "file_operation", "op": "upload", "remote": "fictional/report.csv"},
        {"event_type": "automation", "op": "fictional_setup", "code": "print('synthetic setup only')"},
        {"event_type": "automation_result", "outputs": [{"text": "synthetic setup only\n"}]},
        {"event_type": "stdin_request", "prompt": "Fictional label?"},
        {"event_type": "input_reply", "value": "sample-label"},
        {"event_type": "session_terminated", "reason": "synthetic_end"},
    ]
    return [{"timestamp": f"2026-10-05T00:{i:02d}:00.000000+00:00", **record} for i, record in enumerate(records)]


def capture_export(events, session, path):
    stream = io.StringIO()
    with contextlib.redirect_stdout(stream):
        export_history(events, session, str(path))
    return stream.getvalue()


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=RUNTIME / "tmp")
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        self.logger = HistoryLogger(str(self.folder / "history"))

    def test_01_real_logger_roundtrip_order_unicode(self):
        expected = synthetic_events()
        for item in expected:
            self.logger.log_event("fictional", item["event_type"], item)
        self.assertEqual(self.logger.get_history("fictional"), expected)

    def test_02_real_logger_lists_sessions(self):
        for name in ["alpha", "beta"]:
            self.logger.log_event(name, "marker", {"value": name})
        self.assertEqual(set(self.logger.list_sessions()), {"alpha", "beta"})

    def test_03_missing_session_is_empty(self):
        self.assertEqual(self.logger.get_history("does-not-exist"), [])

    def test_04_empty_file_and_blank_lines(self):
        path = Path(self.logger.log_dir) / "blank.jsonl"
        path.write_text("\n \n\t\n", encoding="utf-8")
        self.assertEqual(self.logger.get_history("blank"), [])

    def test_05_corrupt_history_raises_json_decode_error(self):
        path = Path(self.logger.log_dir) / "broken.jsonl"
        path.write_text('{"event_type":"valid"}\n{not-json}\n', encoding="utf-8")
        with self.assertRaises(json.JSONDecodeError):
            self.logger.get_history("broken")

    def test_06_payload_can_override_event_metadata(self):
        self.logger.log_event("metadata", "outer", {"event_type": "inner", "timestamp": "fixed"})
        self.assertEqual(self.logger.get_history("metadata"), [{"event_type": "inner", "timestamp": "fixed"}])

    def test_07_notebook_schema_and_code_count(self):
        nb = convert_history_to_ipynb(synthetic_events(), "fictional")
        nbformat.validate(nb)
        self.assertEqual(len(nb.cells), 12)
        self.assertEqual(sum(c.cell_type == "code" for c in nb.cells), 6)

    def test_08_notebook_text_output_is_preserved(self):
        nb = convert_history_to_ipynb(synthetic_events(), "fictional")
        self.assertEqual(nb.cells[2].outputs[0].text, "离线学习 ☕\n")

    def test_09_notebook_error_output_is_preserved(self):
        nb = convert_history_to_ipynb(synthetic_events(), "fictional")
        out = nb.cells[3].outputs[0]
        self.assertEqual((out.output_type, out.ename, out.evalue), ("error", "ZeroDivisionError", "division by zero"))
        self.assertEqual(len(out.traceback), 2)

    def test_10_notebook_rich_output_is_preserved(self):
        nb = convert_history_to_ipynb(synthetic_events(), "fictional")
        out = nb.cells[4].outputs[0]
        self.assertEqual(out.data["application/json"], {"answer": 42})

    def test_11_stderr_label_becomes_stdout_observed_limitation(self):
        event = {"event_type": "execution", "code": "pass", "outputs": [{"output_type": "stream", "name": "stderr", "text": "warning"}]}
        nb = convert_history_to_ipynb([event], "fictional")
        self.assertEqual(nb.cells[1].outputs[0].name, "stdout")

    def test_12_execute_result_loses_execution_count_observed_limitation(self):
        event = {"event_type": "execution", "code": "42", "outputs": [{"output_type": "execute_result", "execution_count": 7, "data": {"text/plain": "42"}}]}
        out = convert_history_to_ipynb([event], "fictional").cells[1].outputs[0]
        self.assertEqual(out.output_type, "display_data")
        self.assertNotIn("execution_count", out)

    def test_13_piped_shell_and_python_both_get_bash_magic(self):
        nb = convert_history_to_ipynb(synthetic_events(), "fictional")
        self.assertTrue(nb.cells[5].source.startswith("%%bash\n"))
        # execution.py also labels piped Python REPL events as source='piped'.
        # This confirms the converter's misclassification, not correct typing.
        python_event = {"event_type": "execution", "source": "piped", "code": "print(1)", "outputs": []}
        python_nb = convert_history_to_ipynb([python_event], "fictional")
        self.assertEqual(python_nb.cells[1].source, "%%bash\nprint(1)")

    def test_14_exclamation_shell_does_not_get_bash_magic(self):
        event = {"event_type": "execution", "source": "piped", "code": "!echo sample", "outputs": []}
        nb = convert_history_to_ipynb([event], "fictional")
        self.assertEqual(nb.cells[1].source, "!echo sample")

    def test_15_session_termination_absent_from_notebook(self):
        nb = convert_history_to_ipynb(synthetic_events(), "fictional")
        self.assertNotIn("synthetic_end", nbformat.writes(nb))

    def test_16_automation_and_input_are_retained_in_notebook(self):
        rendered = nbformat.writes(convert_history_to_ipynb(synthetic_events(), "fictional"))
        for value in ["fictional_setup", "sample-label", "Fictional label?"]:
            self.assertIn(value, rendered)

    def test_17_markdown_preserves_text_omits_error_rich_and_termination(self):
        path = self.folder / "history.md"
        capture_export(synthetic_events(), "fictional", path)
        text = path.read_text(encoding="utf-8")
        self.assertIn("离线学习 ☕", text)
        self.assertNotIn("ZeroDivisionError", text)
        self.assertNotIn("application/json", text)
        self.assertNotIn("synthetic_end", text)

    def test_18_plain_text_does_not_export_execution_outputs(self):
        path = self.folder / "history.txt"
        capture_export(synthetic_events(), "fictional", path)
        text = path.read_text(encoding="utf-8")
        self.assertIn("1 / 0", text)
        self.assertNotIn("ZeroDivisionError", text)

    def test_19_jsonl_export_exactly_preserves_event_records(self):
        path = self.folder / "history.jsonl"
        expected = synthetic_events()
        capture_export(expected, "fictional", path)
        self.assertEqual([json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()], expected)

    def test_20_uppercase_extension_is_supported(self):
        path = self.folder / "history.IPYNB"
        capture_export([], "fictional", path)
        nbformat.validate(nbformat.read(path, as_version=4))

    def test_21_unsupported_format_prints_warning_without_file(self):
        path = self.folder / "history.csv"
        message = capture_export(synthetic_events(), "fictional", path)
        self.assertIn("Unsupported export format: .csv", message)
        self.assertFalse(path.exists())

    def test_22_empty_notebook_contains_title_only(self):
        nb = convert_history_to_ipynb([], "empty")
        nbformat.validate(nb)
        self.assertEqual(len(nb.cells), 1)
        self.assertEqual(nb.cells[0].cell_type, "markdown")

    def test_23_recorded_code_is_never_executed(self):
        marker = self.folder / "MUST_NOT_EXIST"
        code = f"open({str(marker)!r}, 'w').write('unexpected')"
        self.logger.log_event("inert", "execution", {"code": code, "outputs": []})
        capture_export(self.logger.get_history("inert"), "inert", self.folder / "inert.ipynb")
        self.assertFalse(marker.exists())

    def test_24_default_history_is_under_isolated_home(self):
        logger = HistoryLogger()
        self.assertTrue(beneath(Path(logger.log_dir), RUNTIME / "home"))

    def test_25_multiline_records_stay_one_jsonl_line(self):
        self.logger.log_event("multiline", "execution", {"code": "a\nb", "outputs": [{"text": "x\ny\n"}]})
        self.assertEqual(len((Path(self.logger.log_dir) / "multiline.jsonl").read_text().splitlines()), 1)
        self.assertEqual(self.logger.get_history("multiline")[0]["code"], "a\nb")


class SafetyAndSourceTests(unittest.TestCase):
    def test_26_network_negative_control_is_blocked(self):
        with self.assertRaises(PermissionError):
            socket.socket()

    def test_27_upstream_copies_match_fixed_hash_manifest(self):
        manifest = json.loads((ROOT / "source_manifest.json").read_text(encoding="utf-8"))
        for entry in manifest["files"]:
            with self.subTest(path=entry["bundle_path"]):
                actual = hashlib.sha256((ROOT / entry["bundle_path"]).read_bytes()).hexdigest()
                self.assertEqual(actual, entry["sha256"])

    def test_28_actual_cli_ast_default_is_oauth2(self):
        tree = ast.parse((ROOT / "source_reference/cli.py").read_text(encoding="utf-8"))
        callback = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "callback")
        self.assertEqual(ast.unparse(callback.args.defaults[-1]), "AuthProvider.OAUTH2")

    def test_29_actual_cli_ast_suppresses_update_for_log(self):
        tree = ast.parse((ROOT / "source_reference/cli.py").read_text(encoding="utf-8"))
        assignment = next(node for node in ast.walk(tree) if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "_AUTO_UPDATE_SUPPRESSED" for target in node.targets))
        self.assertIn("log", ast.literal_eval(assignment.value))

    def test_30_actual_log_ast_filters_before_tailing(self):
        tree = ast.parse((ROOT / "source_reference/commands/utility.py").read_text(encoding="utf-8"))
        log = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "log")
        conditions = [ast.unparse(node.test) for node in log.body if isinstance(node, ast.If)]
        self.assertLess(conditions.index("type"), conditions.index("lines"))
        self.assertLess(conditions.index("lines"), conditions.index("output"))

    def test_31_source_config_does_not_redirect_history(self):
        tree = ast.parse((ROOT / "source_reference/common.py").read_text(encoding="utf-8"))
        state = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "State")
        history = next(node for node in state.body if isinstance(node, ast.FunctionDef) and node.name == "history")
        calls = [node for node in ast.walk(history) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "HistoryLogger"]
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0].args, [])
        self.assertEqual(calls[0].keywords, [])


def make_artifacts():
    history_dir = OUTPUT / "history"
    logger = HistoryLogger(str(history_dir))
    # Deterministic fixture reset within this exercise only; no user files.
    (history_dir / "fictional-demo.jsonl").write_text("", encoding="utf-8")
    for event in synthetic_events():
        logger.log_event("fictional-demo", event["event_type"], event)
    records = logger.get_history("fictional-demo")
    messages = []
    for suffix in ["ipynb", "md", "txt", "jsonl"]:
        messages.append(capture_export(records, "fictional-demo", OUTPUT / f"fictional-demo.{suffix}").strip())
    (OUTPUT / "export_stdout.txt").write_text("\n".join(messages) + "\n", encoding="utf-8")
    nbformat.validate(nbformat.read(OUTPUT / "fictional-demo.ipynb", as_version=4))
    return messages


def main():
    messages = make_artifacts()
    loader = unittest.TestLoader()
    upstream = loader.discover(str(ROOT / "upstream_tests"), pattern="test_history.py")
    suite = unittest.TestSuite([upstream, loader.loadTestsFromTestCase(PipelineTests), loader.loadTestsFromTestCase(SafetyAndSourceTests)])
    buffer = io.StringIO()
    result = unittest.TextTestRunner(stream=buffer, verbosity=2).run(suite)
    raw = buffer.getvalue()
    (OUTPUT / "tests_raw.txt").write_text(raw, encoding="utf-8")
    print(raw, end="")
    for message in messages:
        print(message)
    summary = {
        "started_utc": STARTED,
        "finished_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "commit": "a84e094c67544e70d88649ba2d2a1d48511b3af7",
        "python": sys.version,
        "platform": sys.platform,
        "nbformat": importlib.metadata.version("nbformat"),
        "tests_run": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "upstream_history_tests": 2,
        "harness_pipeline_tests": 25,
        "safety_and_static_source_tests": 6,
        "network_guard_events": GUARD_EVENTS,
        "unexpected_network_guard_events": len(GUARD_EVENTS) - 1,
        "google_accounts_accessed": False,
        "remote_runtimes_created": False,
        "recorded_code_executed": False,
        "full_cli_executed": False,
        "windows_execution_tested": False,
        "limitations": [
            "Synthetic event data; this is local history/export coverage only.",
            "The real full CLI and remote Colab integration were not run.",
            "Static AST checks do not demonstrate CLI runtime behavior.",
            "Network guard is process-local, not an OS security sandbox.",
            "Observed format information loss is expected at this fixed commit, not fixed by this exercise.",
            "Python helper is designed for Windows paths; Windows execution is unverified and upstream native Windows CLI is unsupported.",
        ],
    }
    artifact_files = sorted(path for path in OUTPUT.iterdir() if path.is_file() and path.name != "summary.json")
    summary["artifact_sha256"] = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in artifact_files}
    (OUTPUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: summary[key] for key in ["tests_run", "failures", "errors", "upstream_history_tests", "harness_pipeline_tests", "safety_and_static_source_tests", "unexpected_network_guard_events"]}, indent=2))
    return 0 if result.wasSuccessful() and len(GUARD_EVENTS) == 1 else 1


if __name__ == "__main__":
    raise SystemExit(main())
