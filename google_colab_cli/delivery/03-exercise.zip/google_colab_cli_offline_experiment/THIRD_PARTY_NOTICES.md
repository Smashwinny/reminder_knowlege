# Third-party source provenance

The unmodified source files in `vendor/colab_cli`, the upstream unit test in `upstream_tests`, and the files in `source_reference` originate from Google LLC's `googlecolab/google-colab-cli` repository at commit `a84e094c67544e70d88649ba2d2a1d48511b3af7`.

Repository: https://github.com/googlecolab/google-colab-cli

These files retain their upstream notices and are licensed under Apache License 2.0. The full license is included as `LICENSE.upstream`. The verification harness and Chinese exercise instructions are new task artifacts; they do not modify upstream source. Google does not endorse this exercise.

Dependencies are installed from PyPI rather than redistributed in this ZIP. The tested Linux dependency versions are recorded in `requirements-tested-linux.txt`.
