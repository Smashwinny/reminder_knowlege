# Google Colab CLI：真正的本地历史与导出实验

这份练习直接调用 Google 官方仓库中未改动的 `HistoryLogger` 和 `converter`，验证合成日志如何成为 notebook、Markdown、纯文本和 JSONL。它没有创建 Colab 运行时，没有认证 Google 账号，也没有执行日志中保存的代码。

固定上游版本：`a84e094c67544e70d88649ba2d2a1d48511b3af7`

来源：https://github.com/googlecolab/google-colab-cli/tree/a84e094c67544e70d88649ba2d2a1d48511b3af7

## 环境与运行

需要 Python 3.12 或更高版本。首次安装 `nbformat` 及其依赖需要访问官方 PyPI；安装完成后的实验为离线执行。依赖只安装在当前目录的 `.venv` 中，不需要全局安装。

Linux/macOS，在解压后的此目录运行：

```sh
python3 -m venv .venv
.venv/bin/python -m pip --isolated install --no-cache-dir --index-url https://pypi.org/simple -r requirements-tested-linux.txt
.venv/bin/python verify_sources.py
.venv/bin/python run_experiment.py
.venv/bin/python inspect_results.py
```

Windows PowerShell，建议在一个新的解压目录运行：

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip --isolated install --no-cache-dir --index-url https://pypi.org/simple -r requirements.txt
.\.venv\Scripts\python.exe run_experiment.py
```

Windows 命令是便于复跑的路径适配说明，本次没有在 Windows 上执行验证。此练习没有运行完整 `colab` CLI，不能据此声称上游 CLI 原生支持 Windows；上游 README 明确仅支持 Linux/macOS。

`requirements.txt` 固定 nbformat 5.10.4。`requirements-tested-linux.txt` 记录本次 Linux 环境的全部实际依赖版本；在其他平台可能另需平台专用依赖。

## 五步实验

1. `python3 -m venv .venv`：在当前解压目录创建专属虚拟环境
2. 使用上方完整 pip 命令从官方 PyPI 安装本次 Linux 已验证版本；这一步需要联网，后续测试离线运行
3. `verify_sources.py` 核对固定提交及 14 个上游文件的 SHA-256；上游代码和测试原样保存在 `vendor`、`upstream_tests` 和 `source_reference`
4. `run_experiment.py` 运行两个原样上游测试及其余验证，写入/读取 11 条虚构事件，以真实 converter 导出四种格式，验证结构及边界；不执行日志或 notebook 的代码
5. `inspect_results.py` 核对落盘哈希，显示 33/33 结果、11 条事件、12 个 notebook 单元（6 个代码单元）与格式差异；完整证据在 `outputs`

## 实际结果与怎样理解“通过”

本次 Linux 执行：33 项全部通过，包含 2 项原样上游测试、25 项流水线/边界测试，以及 6 项安全或静态源码检查。完整原始输出和 UTC 时间在 `outputs` 内。

部分通过项是在确认上游现有限制，绝不意味着这些限制已经修复：

- `log_event` 的 data 可覆盖 timestamp 和 event_type；日志内容本身不能证明远端执行或其来源真实性
- 损坏 JSONL 会抛出 JSONDecodeError，读取流程没有自动修复
- notebook 可保存错误和富输出，但 stderr 名称会变为 stdout，execute_result 会变为 display_data，原 execution_count 丢失
- converter 会把非 `!` 开头且标记为 piped 的代码统一加上 `%%bash`；而源码也给管道输入的 Python REPL 打上 piped 标记，因此 Python 代码可能被错误地标为 shell，这不是可靠的语言识别
- notebook 未包含 session_terminated；Markdown 不保存错误对象或富输出；纯文本不保存执行输出
- JSONL 对本次合成记录逐条保真，因此适合作为结构化原始记录留存
- notebook 的 kernelspec 标签为 Google Colab 是转换器写入的元数据，也不是远端运行的证据
- CLI 默认 OAuth2、log 的过滤先于截尾、--config 不重定向 history，均是对真实源码的 AST 检查，未作完整 CLI 运行验证

## 安全边界

脚本不读取用户账号、已有 Google 配置、token、Drive 或其他私有数据。它不调用 `colab new/run/sessions/auth/usage`，不启动远端运行时，不修改系统网络策略。进程级审计钩子阻止 socket/DNS、子进程及项目目录外写入，并用一次受控 socket 创建做负对照；该钩子不是抵御恶意代码的操作系统级沙箱。

只使用本包提供的虚构数据。重跑会覆盖本练习自己生成的 `outputs` 文件和 fictional-demo 日志，保留原始结果时请先复制整个解压目录。实验不需要清理远端资源，因为从未创建远端资源。

## 文件说明

- `run_experiment.py`：本地验证脚本，不是对上游模块的仿写
- `vendor/colab_cli/history.py`、`converter.py`：字节未改的上游模块
- `upstream_tests/test_history.py`：字节未改的两个上游单元测试
- `source_reference`：用于静态核对的原始源码和文档，不导入执行
- `source_manifest.json`：上游文件 SHA-256 与固定提交
- `outputs`：本次真实输出、33 项测试结果与摘要
- `LICENSE.upstream`：上游 Apache-2.0 完整许可证

没有复现或验证：第三方定制技能或远程工作负载、GPU/TPU 可用性、CCU 扣费、性能、Google One 实际权益、真实 Colab 生命周期、完整 CLI 或远端集成测试。

## 公开副本说明

这是既有实验的公开副本。本次发布准备没有重新运行实验。outputs/export_stdout.txt 的绝对路径已规范为 [EXERCISE_ROOT]，summary.json 中对应指纹随之更新；上游文件、脚本、合成输入、测试输出及四种导出文件均保留原字节。
