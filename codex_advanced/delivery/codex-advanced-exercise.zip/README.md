# Codex 进阶离线契约练习

公开副本说明：本包保留 2026-10-05 的历史离线实验，本次公开整理未重跑。25 个样例、运行器、两份官方 schema、LICENSE 与 NOTICE 均保持原字节。历史 JSON 的解释器路径改为可复用的 python3；结果、错误、时间、版本与参数不变。SHA256SUMS 对当前公开包重新计算。HTML 浏览器视觉及 HTML 转 PDF 原路线受环境限制，本次未重试。

这个包只调用本地 Python JSON Schema 校验器。它不启动 Codex CLI/App Server，不连接账户，不调用模型，不读取凭证或真实配置。全部输入为合成资料。原视频未观看、未核验；本包不是视频复现。

## 环境

需要 Bash、Python 3.11+（包含 tomllib）、jsonschema 4.18+ 及其 referencing 依赖。本次已有 Python 3.12.14 / jsonschema 4.26.0 / referencing 0.37.0；没有安装任何软件。本包不含依赖轮子；若缺依赖，先停在环境检查，不要把 ModuleNotFoundError 当成测试通过。

## 六步

把 codex-advanced-exercise.zip 放到空的工作目录，按以下顺序执行。第 1 步完成后保持在 replay/ 目录。

1. 解包并检查依赖：

```bash
python3 -m zipfile -e codex-advanced-exercise.zip replay
cd replay
python3 -I -c "import sys;print(sys.version)"
python3 -I -c "import importlib.metadata as m;print(m.version('jsonschema'))"
```

2. 检查四份上游文件哈希与两份 schema：

```bash
python3 -I validate_offline.py --verify-only
```

3. 配置样例 9 项：

```bash
python3 -I validate_offline.py --suite config --output evidence/recheck_config.json
```

4. 协议样例 13 项：

```bash
python3 -I validate_offline.py --suite protocol --output evidence/recheck_protocol.json
```

5. 语法错误 3 项：

```bash
python3 -I validate_offline.py --suite malformed --output evidence/recheck_malformed.json
```

6. 全量回归 25 项：

```bash
python3 -I validate_offline.py --suite all --output evidence/recheck_all.json
```

预期全部步骤退出码为 0；最终 passed=25、failed=0，accept=8、reject=14、parse_error=3。PASS 的含义是观察符合样例的预期，反例被拒绝也应显示 PASS。预存 original_results.json 是历史实测基线；请看自己的 recheck_*.json。

## 中间成果怎么看

- 配置中的数字 model=42 会出现类型错误；带引号的 false 是字符串，不是布尔值
- 配置 schema 拒绝本包测试的未知顶层键和 Provider 键
- 协议 schema 接受本包测试的额外请求/ClientInfo 字段；不能从一个对象推广到所有字段
- 合成模型名和不存在的 threadId 可以结构合规，这不说明服务端会接受它们
- malformed 套件由 JSON/TOML 解析器先报错，没有进入 schema 校验

具体错误消息和路径保存在 JSON 中。运行器拒绝外部 schema 引用，只允许本地片段引用；没有做操作系统网络抓包审计。

## 固定来源与许可

官方源码固定于 openai/codex@823ea830c0fd418b09ff02d36cad9a1fff66465b。

- ConfigToml: https://github.com/openai/codex/blob/823ea830c0fd418b09ff02d36cad9a1fff66465b/codex-rs/core/config.schema.json
- ClientRequest: https://github.com/openai/codex/blob/823ea830c0fd418b09ff02d36cad9a1fff66465b/codex-rs/app-server-protocol/schema/json/ClientRequest.json
- LICENSE: https://github.com/openai/codex/blob/823ea830c0fd418b09ff02d36cad9a1fff66465b/LICENSE
- NOTICE: https://github.com/openai/codex/blob/823ea830c0fd418b09ff02d36cad9a1fff66465b/NOTICE

四份原文均保留，采用上游 Apache 2.0 许可；schema 未改写。source_manifest.json 保留 Git blob SHA-1 和 SHA-256。运行器和合成样例为本练习原创，不来自真实请求、配置或凭证。安装清单版本 0.159.2 只读过，不能和这个源码提交视为相同运行时。

## 官方文档

核对日期 2026-10-05 UTC；动态文档不是固定构建版本。

- 认证 https://learn.chatgpt.com/docs/auth
- Cloud https://learn.chatgpt.com/docs/cloud
- 配置基础 https://learn.chatgpt.com/docs/config-file/config-basic
- 高级配置 https://learn.chatgpt.com/docs/config-file/config-advanced
- App Server https://learn.chatgpt.com/docs/app-server
- 明确授权的 ChatGPT 登录集成 https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server

结构校验不证明配置来源生效、协议状态、资源存在、操作权限、模型资格或计费结果。没有进行这些在线验收。
