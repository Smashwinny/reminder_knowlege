#!/usr/bin/env python3
"""Validate synthetic fixtures against pinned, unmodified public Codex schemas.

No Codex process, account, model, network request, or live config is involved.
Requires Python >=3.11 and jsonschema >=4.18 (already installed for this run).
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
from pathlib import Path
import sys
import tomllib

from jsonschema import Draft7Validator
from referencing import Registry
from referencing.exceptions import NoSuchResource

ROOT = Path(__file__).resolve().parent
SCHEMA_PATHS = {
    "ConfigToml": "schemas/upstream/ConfigToml.json",
    "ClientRequest": "schemas/upstream/ClientRequest.json",
}


def local_path(relative: str) -> Path:
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError("Path must stay inside the experiment directory")
    return path


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def block_external_reference(uri: str):
    raise NoSuchResource(ref=uri)


def verify_sources() -> list[dict]:
    manifest = json.loads(local_path("schemas/source_manifest.json").read_text())
    verified = []
    for item in manifest["files"]:
        data = local_path(item["path"]).read_bytes()
        blob_sha = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        content_sha = sha256(data)
        if blob_sha != item["github_blob_sha1"] or content_sha != item["sha256"]:
            raise ValueError(f"Source hash mismatch: {item['path']}")
        verified.append({"path": item["path"], "bytes": len(data), "sha256": content_sha,
                         "github_blob_sha1": blob_sha, "matches": True})
    return verified


def assert_local_refs(node, location="$") -> None:
    if isinstance(node, dict):
        for key, value in node.items():
            if key == "$ref" and not value.startswith("#/"):
                raise ValueError(f"External reference prohibited at {location}: {value}")
            assert_local_refs(value, f"{location}.{key}")
    elif isinstance(node, list):
        for index, value in enumerate(node):
            assert_local_refs(value, f"{location}[{index}]")


def describe_error(error) -> dict:
    return {"message": error.message, "validator": error.validator,
            "instance_path": list(error.absolute_path),
            "schema_path": list(error.absolute_schema_path)}


def selected_branch_errors(errors, schema, instance) -> list[dict]:
    """Keep actual errors for the matching method variant, without unrelated variants."""
    if not isinstance(instance, dict):
        return []
    method = instance.get("method")
    selected = next((i for i, branch in enumerate(schema.get("oneOf", []))
                     if method in branch.get("properties", {}).get("method", {}).get("enum", [])), None)
    result = []
    if selected is not None:
        for error in errors:
            for child in error.context:
                if child.schema_path and child.schema_path[0] == selected:
                    result.append(describe_error(child))
    return result


def run_case(case, schemas, validators) -> dict:
    path = local_path(case["path"])
    data = path.read_bytes()
    record = {**case, "fixture_sha256": sha256(data)}
    try:
        value = json.loads(data) if case["format"] == "json" else tomllib.loads(data.decode("utf-8"))
    except (json.JSONDecodeError, tomllib.TOMLDecodeError) as error:
        record.update(actual="parse_error", errors=[{"type": type(error).__name__, "message": str(error)}])
    else:
        errors = sorted(validators[case["schema"]].iter_errors(value), key=lambda e: str(list(e.path)))
        record.update(actual="reject" if errors else "accept",
                      errors=[describe_error(e) for e in errors],
                      selected_method_errors=selected_branch_errors(errors, schemas[case["schema"]], value))
    record["passed"] = record["actual"] == record["expected"]
    return record


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true", help="Verify pinned source hashes and schemas only")
    parser.add_argument("--suite", choices=["all", "config", "protocol", "malformed"], default="all")
    parser.add_argument("--output", help="Optional result JSON path under evidence/; defaults to stdout summary only")
    args = parser.parse_args()
    sources = verify_sources()
    schemas = {name: json.loads(local_path(path).read_text()) for name, path in SCHEMA_PATHS.items()}
    registry = Registry(retrieve=block_external_reference)
    for schema in schemas.values():
        assert_local_refs(schema)
        Draft7Validator.check_schema(schema)
    validators = {name: Draft7Validator(schema, registry=registry) for name, schema in schemas.items()}
    cases_path = local_path("fixtures/cases.json")
    cases = json.loads(cases_path.read_text())["cases"]
    chosen = [] if args.verify_only else [c for c in cases if args.suite == "all" or c["suite"] == args.suite]
    results = [run_case(case, schemas, validators) for case in chosen]
    summary = {"suite": "verify-only" if args.verify_only else args.suite,
               "source_files_verified": len(sources), "schemas_checked": len(schemas),
               "cases_run": len(results), "passed": sum(r["passed"] for r in results),
               "failed": sum(not r["passed"] for r in results),
               "actual_outcomes": dict(Counter(r["actual"] for r in results))}
    report = {
        "schema_version": 1,
        "host_reported_utc": datetime.now(timezone.utc).isoformat(),
        "timestamp_note": "Host clock only. Authoritative orchestration timestamps, if supplied, are recorded separately.",
        "command": [sys.executable, "-I", "validate_offline.py", *sys.argv[1:]],
        "versions": {"python": sys.version.split()[0], "jsonschema": metadata.version("jsonschema"),
                     "referencing": metadata.version("referencing")},
        "source_commit": "823ea830c0fd418b09ff02d36cad9a1fff66465b",
        "harness_sha256": sha256(Path(__file__).read_bytes()),
        "case_manifest_sha256": sha256(cases_path.read_bytes()),
        "offline_controls": {"only_fragment_refs_allowed": True, "external_ref_retrieval": "blocked",
                             "codex_executed": False, "protocol_transmitted": False,
                             "credentials_read": False, "live_config_written": False},
        "not_tested": ["Codex runtime behavior", "authentication", "account or model entitlements",
                       "configuration precedence or application", "protocol sequencing or authorization",
                       "inference", "billing", "token savings", "video reproduction"],
        "summary": summary, "sources": sources, "results": results,
    }
    if args.output:
        output = local_path(args.output)
        if not output.is_relative_to(local_path("evidence")):
            raise ValueError("Output must be under evidence/")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    for result in results:
        print(f"{'PASS' if result['passed'] else 'FAIL'} {result['id']}: {result['actual']}")
    print(json.dumps(summary, sort_keys=True))
    if args.output:
        print(f"Saved: {args.output}")
    return 0 if summary["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
