#!/usr/bin/env python3
"""Six-step, cloud-only reproduction of unchanged WeChatBridge Windows.Core.
Requires Linux x86_64, Python 3.12+, tar support and official Microsoft download
access for a first SDK setup. Never performs native application delivery.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,platform,shutil,subprocess,sys,tarfile,time,urllib.request
ROOT=Path(__file__).resolve().parent
VERSION='10.0.401'
SDK_URL='https://builds.dotnet.microsoft.com/dotnet/Sdk/10.0.401/dotnet-sdk-10.0.401-linux-x64.tar.gz'
SDK_SHA512='51c8b999af9e8dd9998c9edc5944e19a90788862068acd38694e098889054ce8c23d4f0c5cccfa16bf187d044562359e5ee69a9f8ad0bbe913ba90311fbce25b'
LOG=ROOT/'logs'; LOG.mkdir(exist_ok=True)

def digest(path,alg='sha256'):
 h=hashlib.new(alg)
 with path.open('rb') as f:
  for part in iter(lambda:f.read(1024*1024),b''): h.update(part)
 return h.hexdigest()
def emit(obj): print(json.dumps(obj,ensure_ascii=False,indent=2),flush=True)
def environment(sdk):
 env=os.environ.copy()
 for p in ['cli-home','tmp','nuget-packages','nuget-http-cache']:(ROOT/p).mkdir(exist_ok=True)
 env.update({'DOTNET_ROOT':str(sdk),'HOME':str(ROOT/'cli-home'),'DOTNET_CLI_HOME':str(ROOT/'cli-home'),'TMPDIR':str(ROOT/'tmp'),'TMP':str(ROOT/'tmp'),'TEMP':str(ROOT/'tmp'),'NUGET_PACKAGES':str(ROOT/'nuget-packages'),'NUGET_HTTP_CACHE_PATH':str(ROOT/'nuget-http-cache'),'DOTNET_CLI_TELEMETRY_OPTOUT':'1','DOTNET_SKIP_FIRST_TIME_EXPERIENCE':'1','DOTNET_GENERATE_ASPNET_CERTIFICATE':'false','DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE':'true','DOTNET_ADD_GLOBAL_TOOLS_TO_PATH':'false','TZ':'UTC'})
 return env
def command(argv,log,env=None):
 p=subprocess.run(argv,cwd=ROOT,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (LOG/log).write_text(p.stdout); print(p.stdout,end='',flush=True)
 if p.returncode: raise RuntimeError(f'Command failed with exit {p.returncode}: {argv}; see logs/{log}')
 return p.stdout
def sdk_path():
 path=ROOT/'.local-sdk.json'
 if not path.exists():raise RuntimeError('Run python3 run.py setup first')
 sdk=Path(json.loads(path.read_text())['path'])
 if not (sdk/'dotnet').is_file():raise RuntimeError('Recorded SDK is unavailable; rerun setup')
 return sdk

def setup():
 if platform.system()!='Linux' or platform.machine() not in ('x86_64','AMD64'):raise RuntimeError('This reproduction requires Linux x86_64; native application behavior is not tested')
 if sys.version_info<(3,12):raise RuntimeError('Python 3.12+ is required for safe tar extraction')
 override=os.environ.get('WECHATBRIDGE_DOTNET_SDK')
 sdk=Path(override).resolve() if override else ROOT/'dotnet-sdk'
 archive=ROOT/f'dotnet-sdk-{VERSION}-linux-x64.tar.gz'
 receipt={'version':VERSION,'officialUrl':SDK_URL,'publishedSha512':SDK_SHA512,'mode':'explicit-existing-sdk' if override else 'exercise-local-sdk'}
 if override:
  # An explicit existing SDK is an optimization, not an unverified binary download.
  supplied=os.environ.get('WECHATBRIDGE_DOTNET_ARCHIVE')
  if not supplied:raise RuntimeError('Existing SDK reuse requires WECHATBRIDGE_DOTNET_ARCHIVE to verify the matching official archive')
  archive=Path(supplied).resolve()
  if digest(archive,'sha512')!=SDK_SHA512:raise RuntimeError('Existing SDK archive checksum mismatch')
  # Match every extracted SDK file to the verified archive before execution.
  n=0
  with tarfile.open(archive,'r:gz') as t:
   for member in t:
    if member.isfile():
     local=sdk/member.name
     if not local.is_file():raise RuntimeError(f'Existing SDK file missing: {member.name}')
     stream=t.extractfile(member); h=hashlib.sha256()
     for part in iter(lambda:stream.read(1024*1024),b''):h.update(part)
     if digest(local)!=h.hexdigest():raise RuntimeError(f'Existing SDK differs from archive: {member.name}')
     n+=1
  receipt['verifiedSdkFiles']=n
 else:
  if not archive.exists():
   print(f'Downloading official SDK into {archive.name} (240059572 bytes)',flush=True)
   request=urllib.request.Request(SDK_URL,headers={'User-Agent':'WeChatBridge-Core-Exercise/1.0'})
   with urllib.request.urlopen(request,timeout=180) as r, archive.open('wb') as f:shutil.copyfileobj(r,f)
  if digest(archive,'sha512')!=SDK_SHA512:raise RuntimeError('SDK archive checksum mismatch; no extraction or execution performed')
  if not (sdk/'dotnet').exists():
   sdk.mkdir(exist_ok=True)
   with tarfile.open(archive,'r:gz') as t:t.extractall(sdk,filter='data')
  receipt['archiveBytes']=archive.stat().st_size
 receipt['archiveChecksumMatched']=True
 versionfile=sdk/'sdk'/VERSION/'.version'
 if not versionfile.exists() or VERSION not in versionfile.read_text().splitlines():raise RuntimeError('Expected SDK version metadata is missing')
 actual=command([str(sdk/'dotnet'),'--version'],'runner-sdk-version.log',environment(sdk)).strip()
 if actual!=VERSION:raise RuntimeError(f'Unexpected runtime SDK version {actual}')
 (ROOT/'.local-sdk.json').write_text(json.dumps({'path':str(sdk),'version':VERSION},indent=2)+'\n')
 (ROOT/'setup-result.json').write_text(json.dumps(receipt,indent=2)+'\n');emit(receipt)

def verify():
 checks=json.loads((ROOT/'copy_verification.json').read_text()); base=ROOT/'upstream/windows/src/WeChatBridge.Windows.Core'
 for row in checks:
  if digest(base/row['file'])!=row['sha256']:raise RuntimeError('Upstream source mismatch: '+row['file'])
 manifest=json.loads((ROOT/'bundle_manifest.json').read_text())
 for name,value in manifest.items():
  if digest(ROOT/name)!=value:raise RuntimeError('Bundled static file mismatch: '+name)
 result={'sourceCommit':'07b88822debc3bd544ae7a83bc207633b29c3a04','unchangedCoreFiles':len(checks),'bundleFilesVerified':len(manifest),'license':'MIT; Copyright (c) 2026 qzz0518'}
 (ROOT/'verify-result.json').write_text(json.dumps(result,indent=2)+'\n');emit(result)

def fixtures():command([sys.executable,'make_fixtures.py'],'runner-fixtures.log')
def build():
 sdk=sdk_path(); env=environment(sdk)
 command([str(sdk/'dotnet'),'restore','harness/CoreExercise.csproj','--configfile','NuGet.Config','--ignore-failed-sources','--disable-parallel','--nologo'],'runner-restore.log',env)
 command([str(sdk/'dotnet'),'build','harness/CoreExercise.csproj','-c','Release','--no-restore','--nologo'],'runner-build.log',env)
def test():
 sdk=sdk_path()
 command([str(sdk/'dotnet'),'run','--project','harness/CoreExercise.csproj','-c','Release','--no-build','--',str(ROOT)],'runner-test.log',environment(sdk))
def report():
 p=ROOT/'results/latest.json'
 if not p.exists():raise RuntimeError('No current test run; run python3 run.py test')
 data=json.loads(p.read_text())
 if data['failed'] or data['passed']!=42:raise RuntimeError(f"Expected 42 passed / 0 failed, got {data['passed']} / {data['failed']}")
 verify()
 run=Path(data['runDirectory']); outputs=[]
 for f in sorted(run.rglob('*')):
  if f.is_file() and not f.is_symlink():outputs.append({'path':str(f.relative_to(run)),'bytes':f.stat().st_size,'sha256':digest(f)})
 summary={'passed':data['passed'],'failed':data['failed'],'testDurationMs':data['durationMs'],'runDirectory':str(run),'sourceCommit':data['sourceCommit'],'portableCoreOnly':True,'nativeIntegrationVerified':False,'outputs':outputs,'limitations':['No macOS Share Extension, AX, OCR, WeChat DB or real WeChat files','No Windows WPF/Share Target, clipboard or real target-app delivery','No exactly-once/concurrent-consumer guarantee','InboxWriter stages .zip-named bytes; archive integrity is a separate check','Future-dated intents are fresh under the current one-sided age check','GUID IDs are not content hashes']}
 (ROOT/'experiment-report.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 emit({k:v for k,v in summary.items() if k!='outputs'}); print(f'Hashed {len(outputs)} output files; see experiment-report.json')

parser=argparse.ArgumentParser();parser.add_argument('step',choices=['setup','verify','fixtures','build','test','report']);args=parser.parse_args()
start=time.monotonic(); at=datetime.datetime.now(datetime.timezone.utc).isoformat(); status='passed'; error=None
try:globals()[args.step]()
except Exception as ex:status='failed'; error=str(ex); print('ERROR:',error,file=sys.stderr)
finally:
 record={'step':args.step,'startedAt':at,'seconds':round(time.monotonic()-start,6),'status':status,'error':error}
 with (LOG/'steps.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 emit(record)
sys.exit(0 if status=='passed' else 1)
