using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using WeChatBridge.Windows.Core;

var root = Path.GetFullPath(args.Single());
var input = Path.Combine(root, "inputs");
var runId = DateTimeOffset.UtcNow.ToString("yyyyMMddTHHmmssfffZ");
var output = Path.Combine(root, "results", runId);
Directory.CreateDirectory(output);
var results = new List<object>();
var failures = 0;
var total = Stopwatch.StartNew();
var started = DateTimeOffset.UtcNow;
byte[] Read(string file) => File.ReadAllBytes(Path.Combine(input, file));
string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
string Dir(string name) { var d=Path.Combine(output,name); Directory.CreateDirectory(d); return d; }
void Assert(bool condition, string message) { if (!condition) throw new Exception(message); }
void Throws<T>(Action action) where T:Exception { try { action(); } catch(T) { return; } throw new Exception($"Expected {typeof(T).Name}"); }
async Task ThrowsAsync<T>(Func<Task> action) where T:Exception { try { await action(); } catch(T) { return; } throw new Exception($"Expected {typeof(T).Name}"); }
async Task Test(string id, string claim, Func<Task> test) {
 var sw=Stopwatch.StartNew(); var at=DateTimeOffset.UtcNow;
 try { await test(); results.Add(new {id,claim,status="passed",startedAt=at,durationMs=sw.Elapsed.TotalMilliseconds}); Console.WriteLine($"PASS {id}: {claim}"); }
 catch(Exception ex) { failures++; results.Add(new {id,claim,status="failed",startedAt=at,durationMs=sw.Elapsed.TotalMilliseconds,error=ex.ToString()}); Console.WriteLine($"FAIL {id}: {ex}"); }
}
Task Sync(Action a) { a(); return Task.CompletedTask; }
InboxSourceFile Source(string file="stored.zip", string? display=null, int index=0) => new(Path.Combine(input,file),display??file,"application/zip",index,0);
InboxPaths Paths(string name) { var p=new InboxPaths(Dir(name)); p.EnsureCreated(); return p; }

await Test("A01", "stored archive yields two synthetic messages and unchanged multiline transcript", ()=>Sync(()=>{
 var bytes=Read("stored.zip"); Assert(WeChatNativeArchive.MessageCount(bytes)==2,"message count"); var t=WeChatNativeArchive.GetTranscript(bytes)!;
 Assert(t.Path=="聊天记录.txt" && t.Records?.Count==2,"transcript metadata"); Assert(t.Body==File.ReadAllText(Path.Combine(input,"expected-transcript.txt")),"body changed");
 Assert(t.Records![0].Text=="第一行\n第二行","multiline body");
}));
await Test("A02", "deflated ZIP parses and extracts exact transcript and attachment bytes", ()=>Sync(()=>{
 var bytes=Read("deflated.zip"); Assert(WeChatNativeArchive.MessageCount(bytes)==2,"deflate count"); var d=Dir("extract-deflated"); var entries=WeChatNativeArchive.Extract(bytes,d);
 Assert(entries.Count==2,"entry count"); Assert(Hash(File.ReadAllBytes(Path.Combine(d,"images/sample.bin")))==Hash(Read("expected-attachment.bin")),"attachment hash");
 Assert(Hash(File.ReadAllBytes(Path.Combine(d,"聊天记录.txt")))==Hash(Read("expected-transcript.txt")),"text hash");
}));
await Test("A03", "stored ZIP extracts exact attachment bytes", ()=>Sync(()=>{
 var d=Dir("extract-stored"); WeChatNativeArchive.Extract(Read("stored.zip"),d);
 Assert(Hash(File.ReadAllBytes(Path.Combine(d,"images/sample.bin")))==Hash(Read("expected-attachment.bin")),"hash");
}));
await Test("A04", "unknown TXT is retained without inventing parsed messages", ()=>Sync(()=>{
 var bytes=Read("unknown-text.zip"); Assert(WeChatNativeArchive.MessageCount(bytes)==null,"unknown count"); var t=WeChatNativeArchive.GetTranscript(bytes)!;
 Assert(t.Body=="synthetic future text format" && t.Records==null,"raw preservation");
}));
await Test("A05", "attachment-only ZIP is valid with unknown message count", ()=>Sync(()=>{
 Assert(WeChatNativeArchive.MessageCount(Read("attachment-only.zip"))==null,"attachment count"); Assert(WeChatNativeArchive.GetTranscript(Read("attachment-only.zip"))==null,"transcript invented");
}));
await Test("A06", "BOM and CRLF preserve the two-message interpretation", ()=>Sync(()=>Assert(WeChatNativeArchive.MessageCount(Read("crlf-bom.zip"))==2,"BOM/CRLF")));
foreach (var file in new[]{"empty.zip","empty-file.zip","not-a-zip.zip","bad-crc.zip","unsupported-method.zip","encrypted-flag.zip","oversized-declaration.zip","duplicate.zip"}) {
 await Test("A-reject-"+file,"archive integrity rejects "+file,()=>Sync(()=>Throws<WeChatReadException>(()=>WeChatNativeArchive.MessageCount(Read(file)))));
}
foreach (var file in new[]{"traversal.zip","absolute.zip","symlink.zip","case-alias.zip"}) {
 await Test("A-extract-reject-"+file,"unsafe extraction rejects "+file+" without creating files",()=>Sync(()=>{
  var d=Dir("reject-"+file); Throws<WeChatReadException>(()=>WeChatNativeArchive.Extract(Read(file),d)); Assert(!Directory.EnumerateFileSystemEntries(d).Any(),"unsafe file written");
 }));
}
await Test("A19", "nonempty extraction destination is refused and sentinel retained",()=>Sync(()=>{
 var d=Dir("nonempty"); File.WriteAllText(Path.Combine(d,"sentinel"),"untouched"); Throws<WeChatReadException>(()=>WeChatNativeArchive.Extract(Read("stored.zip"),d)); Assert(File.ReadAllText(Path.Combine(d,"sentinel"))=="untouched","overwritten");
}));
await Test("A20", "pre-cancelled archive operation is stopped",()=>Sync(()=>{
 using var c=new CancellationTokenSource(); c.Cancel(); Throws<OperationCanceledException>(()=>WeChatNativeArchive.MessageCount(Read("stored.zip"),c.Token));
}));
await Test("A21", "raw transcript rejects malformed headers and impossible dates",()=>Sync(()=>{
 Throws<WeChatReadException>(()=>WeChatTranscriptRecord.Parse("unrecognized")); Throws<WeChatReadException>(()=>WeChatTranscriptRecord.Parse("·合成甲\n2026年99月5日 09:00\ntext\n"));
}));

await Test("S01", "Staging hidden before atomic Ready commit; original ZIP hash preserved",async()=>{
 var p=Paths("staging"); var reader=new InboxReader(p,InboxReader.Removal.Delete); var staged=await InboxWriter.StageAsync(p,[Source()],action:ShareAction.Codex);
 Assert(reader.LoadBatches().Count==0 && !Directory.Exists(staged.ReadyDirectory),"visible early"); Assert(File.Exists(Path.Combine(staged.StagingDirectory,"manifest.json")),"manifest missing");
 var intent=new BatchIntent{Action=ShareAction.Codex,RequestedAt=DateTimeOffset.UtcNow}; var committed=await InboxWriter.CommitAsync(p,staged,intent);
 Assert(!Directory.Exists(staged.StagingDirectory) && Directory.Exists(committed.BatchDirectory),"rename not complete"); var batch=reader.LoadBatches().Single();
 Assert(Hash(File.ReadAllBytes(batch.Items.Single().FullPath))==Hash(Read("stored.zip")),"ZIP changed"); Assert(File.Exists(Path.Combine(batch.Directory,"intent.json")),"intent missing");
 var json=File.ReadAllText(Path.Combine(batch.Directory,"manifest.json")); Assert(!json.Contains(input),"absolute source path persisted");
 using var parsed=JsonDocument.Parse(json); Assert(parsed.RootElement.GetProperty("createdAt").GetString()!.EndsWith('Z'),"not UTC Z");
 Assert(parsed.RootElement.GetProperty("schemaVersion").GetInt32()==1,"schema");
});
await Test("S02", "duplicate display names are disambiguated without overwriting originals",async()=>{
 var p=Paths("duplicates"); var c=await InboxWriter.CommitAsync(p,[Source("stored.zip","聊天记录.zip"),Source("deflated.zip","聊天记录.zip",1)]);
 Assert(c.Manifest.Items.Select(i=>i.DisplayName).SequenceEqual(new[]{"聊天记录.zip","聊天记录 (2).zip"}),"duplicate naming");
 Assert(Hash(File.ReadAllBytes(Path.Combine(c.BatchDirectory,c.Manifest.Items[0].RelativePath)))==Hash(Read("stored.zip")),"first overwritten");
 Assert(Hash(File.ReadAllBytes(Path.Combine(c.BatchDirectory,c.Manifest.Items[1].RelativePath)))==Hash(Read("deflated.zip")),"second overwritten");
});
await Test("S03", "invalid second item rolls back entire staging batch and records failure",async()=>{
 var p=Paths("rollback"); await ThrowsAsync<InboxValidationException>(()=>InboxWriter.CommitAsync(p,[Source(),Source("notes.txt",index:1)]));
 Assert(!Directory.EnumerateDirectories(p.Ready).Any() && !Directory.EnumerateDirectories(p.Staging).Any(),"partial batch leaked"); Assert(Directory.EnumerateFiles(p.Failed,"*.json").Count()==1,"failure not recorded");
});
await Test("S04", "injected per-file limit rejects before Ready publication",async()=>{
 var p=Paths("file-limit"); await ThrowsAsync<InboxValidationException>(()=>InboxWriter.CommitAsync(p,[Source()],limits:new InboxLimits(10,10000)));
 Assert(!Directory.EnumerateDirectories(p.Ready).Any(),"oversized published");
});
await Test("S05", "injected total-size limit rejects whole batch",async()=>{
 var p=Paths("batch-limit"); var len=Read("stored.zip").LongLength; await ThrowsAsync<InboxValidationException>(()=>InboxWriter.CommitAsync(p,[Source(),Source(index:1)],limits:new InboxLimits(len+1,len+1)));
 Assert(!Directory.EnumerateDirectories(p.Ready).Any() && !Directory.EnumerateDirectories(p.Staging).Any(),"over-limit batch leaked");
});
await Test("S06", "InboxWriter accepts .zip filename without validating archive integrity",async()=>{
 var p=Paths("zip-boundary"); var c=await InboxWriter.CommitAsync(p,[Source("not-a-zip.zip")]); var bytes=File.ReadAllBytes(Path.Combine(c.BatchDirectory,c.Manifest.Items.Single().RelativePath));
 Assert(Hash(bytes)==Hash(Read("not-a-zip.zip")),"staging changed bytes"); Throws<WeChatReadException>(()=>WeChatNativeArchive.MessageCount(bytes));
});
await Test("S07", "pre-cancelled staging leaves no Ready or partial batch",async()=>{
 var p=Paths("cancel-stage"); using var c=new CancellationTokenSource(); c.Cancel(); await ThrowsAsync<OperationCanceledException>(()=>InboxWriter.CommitAsync(p,[Source()],cancellationToken:c.Token));
 Assert(!Directory.EnumerateDirectories(p.Ready).Any() && !Directory.EnumerateDirectories(p.Staging).Any(),"cancel leaked");
});
await Test("S08", "source symlink is rejected",async()=>{
 var p=Paths("source-link"); var link=Path.Combine(p.Root,"link.zip"); File.CreateSymbolicLink(link,Path.Combine(input,"stored.zip"));
 await ThrowsAsync<InboxValidationException>(()=>InboxWriter.CommitAsync(p,[new InboxSourceFile(link,"link.zip","application/zip",0,0)]));
 Assert(!Directory.EnumerateDirectories(p.Ready).Any(),"symlink published");
});

await Test("I01", "fresh intent is consumed once, including after reader restart",async()=>{
 var p=Paths("fresh-intent"); var now=new DateTimeOffset(2026,10,5,12,0,0,TimeSpan.Zero); var intent=new BatchIntent{Action=ShareAction.Codex,RequestedAt=now};
 var c=await InboxWriter.CommitAsync(p,[Source()],action:ShareAction.Codex,intent:intent); var reader=new InboxReader(p,InboxReader.Removal.Delete);
 Assert(reader.ConsumeIntent(c.BatchId,now.AddSeconds(89)).Kind==ConsumedIntentKind.Ready,"fresh not ready"); Assert(!File.Exists(Path.Combine(c.BatchDirectory,"intent.json")),"not deleted");
 Assert(reader.ConsumeIntent(c.BatchId,now).Kind==ConsumedIntentKind.None,"same-reader replay"); Assert(new InboxReader(p).ConsumeIntent(c.BatchId,now).Kind==ConsumedIntentKind.None,"restart replay");
});
await Test("I02", "exactly 90-second-old intent is expired and consumed",async()=>{
 var p=Paths("expired-intent"); var now=new DateTimeOffset(2026,10,5,12,0,0,TimeSpan.Zero); var c=await InboxWriter.CommitAsync(p,[Source()],action:ShareAction.Codex,intent:new BatchIntent{Action=ShareAction.Codex,RequestedAt=now});
 var r=new InboxReader(p); Assert(r.ConsumeIntent(c.BatchId,now.AddSeconds(90)).Kind==ConsumedIntentKind.Expired,"boundary not expired"); Assert(r.ConsumeIntent(c.BatchId,now).Kind==ConsumedIntentKind.None,"expired replay");
});
await Test("I03", "malformed intent is deleted without executing",async()=>{
 var p=Paths("malformed-intent"); var c=await InboxWriter.CommitAsync(p,[Source()],action:ShareAction.Codex); File.WriteAllText(Path.Combine(c.BatchDirectory,"intent.json"),"broken JSON");
 Assert(new InboxReader(p).ConsumeIntent(c.BatchId).Kind==ConsumedIntentKind.None,"malformed ready"); Assert(!File.Exists(Path.Combine(c.BatchDirectory,"intent.json")),"malformed remains");
});
await Test("I04", "state initializes once and preserves target/chat/scene after outcome",async()=>{
 var p=Paths("state"); var c=await InboxWriter.CommitAsync(p,[Source()],action:ShareAction.Custom,intent:new BatchIntent{Action=ShareAction.Custom,RequestedAt=DateTimeOffset.UtcNow,TargetDisplayName="Synthetic target"});
 var r=new InboxReader(p); Assert(r.LoadBatches().Single().IsFirstSeen,"firstSeen missing"); Assert(!new InboxReader(p).LoadBatches().Single().IsFirstSeen,"restart firstSeen repeated");
 r.RecordContext(c.BatchId,"Synthetic group","scene-1","Synthetic scene"); r.RecordOutcome(new BatchOutcome(BatchOutcomeKind.Failed,"Synthetic failure",DateTimeOffset.UtcNow),c.BatchId);
 var state=new InboxReader(p).StateFor(c.BatchId)!; Assert(state.TargetName=="Synthetic target" && state.ChatName=="Synthetic group" && state.SceneID=="scene-1" && state.Outcome!.Kind==BatchOutcomeKind.Failed,"context lost");
});
await Test("I05", "clipboard initial state records copied metadata only; no clipboard API is called",async()=>{
 var p=Paths("clipboard-model"); var c=await InboxWriter.CommitAsync(p,[Source()]); var b=new InboxReader(p).LoadBatches().Single(); Assert(b.Outcome?.Kind==BatchOutcomeKind.Copied && b.Outcome.At==b.CreatedAt,"initial copied");
});
await Test("I06", "future timestamps are considered fresh by current one-sided age check",()=>Sync(()=>{
 var now=new DateTimeOffset(2026,10,5,12,0,0,TimeSpan.Zero); Assert(new BatchIntent{Action=ShareAction.Codex,RequestedAt=now.AddHours(1)}.IsFresh(now),"behavior changed");
}));

async Task<ReadyBatch> Add(InboxPaths p,InboxReader r,string file="stored.zip") { var c=await InboxWriter.CommitAsync(p,[Source(file)],action:ShareAction.Collect); return r.LoadBatches().Single(b=>b.Id==c.BatchId); }
await Test("C01", "freeze preserves batch order/hashes, blocks edits and splits late share",async()=>{
 var p=Paths("collection-freeze"); var r=new InboxReader(p,InboxReader.Removal.Delete); var s=new CollectionService(p,r); var a=await Add(p,r); var b=await Add(p,r,"deflated.zip");
 var id=s.Append(a,"Synthetic group"); Assert(s.Append(b,"Synthetic group")==id,"unexpected collection"); Assert(s.Append(a,"Synthetic group")==id,"duplicate append id");
 var f=s.Freeze(id); Assert(f.Select(x=>x.Id).SequenceEqual(new[]{a.Id,b.Id}),"freeze order"); Assert(Hash(File.ReadAllBytes(a.Items.Single().FullPath))==Hash(Read("stored.zip")),"original changed");
 Throws<InvalidOperationException>(()=>s.Ledger.Remove(id,a.Id)); var late=await Add(p,r); Assert(s.Append(late,"Synthetic late group")!=id,"late share joined frozen");
});
await Test("C02", "restart changes interrupted delivery to Retry and does not recollect",async()=>{
 var p=Paths("collection-restart"); var r=new InboxReader(p,InboxReader.Removal.Delete); var s=new CollectionService(p,r); var a=await Add(p,r); var id=s.Append(a,"Synthetic group"); s.Freeze(id);
 var restarted=new CollectionService(p,new InboxReader(p,InboxReader.Removal.Delete)); Assert(restarted.Ledger.Editable(id).Status==CollectionStatus.Retry,"not retry"); Assert(restarted.Ledger.ProtectedBatchIDs.Contains(a.Id),"not protected");
 restarted.Append(a,null); Assert(restarted.Ledger.Collections.Count==1 && restarted.Ledger.Collections.Single().BatchIDs.Count==1,"recollected");
});
await Test("C03", "remove/undo across restart restores original bytes and member order",async()=>{
 var p=Paths("collection-undo"); var r=new InboxReader(p,InboxReader.Removal.Delete); var s=new CollectionService(p,r); var a=await Add(p,r); var b=await Add(p,r,"deflated.zip"); var id=s.Append(a,"Synthetic group"); s.Append(b,"Synthetic group");
 s.Remove(id,a.Id); Assert(!File.Exists(a.Items.Single().FullPath),"not removed from Ready"); s.Append(a,null); Assert(s.Ledger.Editable(id).BatchIDs.SequenceEqual(new[]{b.Id}),"removed batch readded");
 var restarted=new CollectionService(p,r); Assert(restarted.CanUndo,"undo missing"); restarted.Undo(); Assert(restarted.Ledger.Editable(id).BatchIDs.SequenceEqual(new[]{a.Id,b.Id}),"order wrong");
 Assert(Hash(File.ReadAllBytes(a.Items.Single().FullPath))==Hash(Read("stored.zip")),"undo bytes changed"); Assert(!restarted.CanUndo,"undo not consumed");
});
await Test("C04", "interrupted removal is recovered from on-disk undo record",async()=>{
 var p=Paths("collection-interrupted-remove"); var r=new InboxReader(p,InboxReader.Removal.Delete); var s=new CollectionService(p,r); var a=await Add(p,r); var id=s.Append(a,"Synthetic group");
 var stored=Path.Combine(p.Root,"RemovedCollectionBatches",a.Id.ToString("D")); Directory.CreateDirectory(Path.GetDirectoryName(stored)!);
 ConfigStore.Save(p.Root,"collection-undo.json",new CollectionService.RemovedBatch(id,a.Id,0,stored)); Directory.Move(a.Directory,stored);
 var restarted=new CollectionService(p,r); Assert(Directory.Exists(a.Directory) && !restarted.CanUndo,"interrupted removal not restored"); Assert(restarted.Ledger.Editable(id).BatchIDs.SequenceEqual(new[]{a.Id}),"ledger wrong");
});
await Test("C05", "newer or corrupt collection ledger is rejected without overwrite",()=>Sync(()=>{
 var p=Paths("collection-corrupt"); var path=Path.Combine(p.Root,"collections.json"); var raw="{\"schemaVersion\":8,\"collections\":[],\"seenBatchIDs\":[]}"; File.WriteAllText(path,raw);
 Throws<InvalidDataException>(()=>new CollectionService(p,new InboxReader(p))); Assert(File.ReadAllText(path)==raw,"ledger overwritten");
}));
await Test("C06", "unnamed collection cannot freeze without explicit synthetic name",async()=>{
 var p=Paths("collection-name"); var r=new InboxReader(p,InboxReader.Removal.Delete); var s=new CollectionService(p,r); var a=await Add(p,r); var id=s.Append(a,null);
 Throws<InvalidOperationException>(()=>s.Freeze(id)); s.SetChatName(id,a.Id,"Synthetic group",false); Assert(s.Freeze(id).Count==1,"named freeze failed");
});
await Test("C07", "protected pending collection survives retention including unreadable manifest",async()=>{
 var p=Paths("collection-retention"); var r=new InboxReader(p,InboxReader.Removal.Delete); var s=new CollectionService(p,r); var a=await Add(p,r); s.Append(a,"Synthetic group"); s.Ledger.ParkCurrent(); s.Save();
 Assert(r.PruneHistory(TimeSpan.FromDays(1),DateTimeOffset.UtcNow.AddDays(30),s.Ledger.ProtectedBatchIDs)==0,"pending removed"); File.WriteAllText(Path.Combine(a.Directory,"manifest.json"),"broken");
 Assert(r.PruneHistory(TimeSpan.FromDays(1),DateTimeOffset.UtcNow.AddDays(30),s.Ledger.ProtectedBatchIDs)==0 && Directory.Exists(a.Directory),"unreadable protected removed");
});
var report=new {sourceCommit="07b88822debc3bd544ae7a83bc207633b29c3a04",scope="Unchanged Windows.Core portable filesystem/archive/intent/collection behavior only",syntheticOnly=true,nativeApisCalled=false,startedAt=started,finishedAt=DateTimeOffset.UtcNow,durationMs=total.Elapsed.TotalMilliseconds,passed=results.Count-failures,failed=failures,tests=results,runDirectory=output};
var jsonReport=JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}); File.WriteAllText(Path.Combine(output,"test-results.json"),jsonReport); File.WriteAllText(Path.Combine(root,"results","latest.json"),jsonReport);
Console.WriteLine($"SUMMARY passed={results.Count-failures} failed={failures} durationMs={total.Elapsed.TotalMilliseconds:F2} results={output}");
return failures==0?0:1;
