#!/usr/bin/env bash
# Scope runtime/cache/temp/first-run writes only to this exercise.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DOTNET_ROOT="$ROOT/dotnet-sdk"
export HOME="$ROOT/cli-home" DOTNET_CLI_HOME="$ROOT/cli-home" TMPDIR="$ROOT/tmp" TMP="$ROOT/tmp" TEMP="$ROOT/tmp"
export NUGET_PACKAGES="$ROOT/nuget-packages" NUGET_HTTP_CACHE_PATH="$ROOT/nuget-http-cache"
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_GENERATE_ASPNET_CERTIFICATE=false
export DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE=true DOTNET_ADD_GLOBAL_TOOLS_TO_PATH=false
export TZ=UTC
