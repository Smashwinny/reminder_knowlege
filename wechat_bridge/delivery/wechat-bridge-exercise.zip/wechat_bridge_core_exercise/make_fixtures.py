from pathlib import Path
import zipfile,io,json,hashlib,struct
root=Path(__file__).resolve().parent; out=root/'inputs'; out.mkdir(exist_ok=True)
body='·合成甲\n2026年10月5日 09:00\n第一行\n第二行\n\n·合成乙\n2026年10月5日 09:01\nimages/sample.bin\n'
media=bytes(range(64))
def archive(name,entries,compression=zipfile.ZIP_STORED):
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w',compression=compression) as z:
  for n,data,mode in entries:
   i=zipfile.ZipInfo(n,(2026,10,5,9,0,0)); i.compress_type=compression; i.create_system=3; i.external_attr=mode<<16
   z.writestr(i,data)
 (out/name).write_bytes(b.getvalue()); return b.getvalue()
regular=0o100644
normal=[('聊天记录.txt',body.encode(),regular),('images/sample.bin',media,regular)]
stored=archive('stored.zip',normal)
archive('deflated.zip',normal,zipfile.ZIP_DEFLATED)
archive('unknown-text.zip',[('聊天记录.txt','synthetic future text format'.encode(),regular)])
archive('attachment-only.zip',[('images/sample.bin',media,regular)])
archive('empty.zip',[])
archive('empty-file.zip',[('empty.txt',b'',regular)])
archive('traversal.zip',[('../escaped.txt',b'SYNTHETIC',regular)])
archive('absolute.zip',[('/escaped.txt',b'SYNTHETIC',regular)])
archive('symlink.zip',[('link',b'../outside',0o120777)])
archive('case-alias.zip',[('Photos/a.bin',b'A',regular),('photos/b.bin',b'B',regular)])
archive('unsupported-method.zip',normal,zipfile.ZIP_BZIP2)
archive('crlf-bom.zip',[('聊天记录.txt',('\ufeff'+body.replace('\n','\r\n')).encode(),regular)])
archive('duplicate.zip',[('same.bin',b'A',regular),('same.bin',b'B',regular)])
b=bytearray(stored); name_len,extra_len=struct.unpack_from('<HH',b,26); b[30+name_len+extra_len]^=1; (out/'bad-crc.zip').write_bytes(b)
b=bytearray(stored); off=b.index(b'PK\x01\x02'); struct.pack_into('<I',b,off+24,1073741825); (out/'oversized-declaration.zip').write_bytes(b)
b=bytearray(stored); off=b.index(b'PK\x01\x02'); struct.pack_into('<H',b,off+8,struct.unpack_from('<H',b,off+8)[0]|1); (out/'encrypted-flag.zip').write_bytes(b)
(out/'not-a-zip.zip').write_bytes(b'SYNTHETIC NON-ZIP BYTES')
(out/'notes.txt').write_text('SYNTHETIC disallowed standalone file\n')
(out/'expected-transcript.txt').write_text(body)
(out/'expected-attachment.bin').write_bytes(media)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.is_file()}
(root/'inputs_manifest.json').write_text(json.dumps({'syntheticOnly':True,'fixedZipTimestamp':'2026-10-05T09:00:00','files':manifest},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'syntheticOnly':True,'fixtures':len(manifest),'inputDirectory':'inputs','manifest':'inputs_manifest.json'}))
