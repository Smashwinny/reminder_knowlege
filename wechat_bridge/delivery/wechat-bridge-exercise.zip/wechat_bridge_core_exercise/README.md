# WeChatBridge portable core experiment

Sanitized local copy: this preserves the recorded 2026-10-05 component study. No SDK setup, fixture generation, compilation, tests, upstream execution or native application operation was performed during this copy preparation. Changes are limited to publication/provenance notes, private absolute path roles (<EXERCISE_DIR> and <PYTHON_RUNTIME>), and dependent bundle checksums. Commands, test outcomes, error details, timing, synthetic GUIDs and historical output fingerprints remain intact apart from path labels. Current static members are verified by bundle_manifest.json; the 68 generated-output hashes remain historical evidence rather than new outputs. Upstream Core, licenses, third-party notice, harness, scripts and all 20 fixtures are byte-identical. HTML browser and HTML-to-PDF routes remained blocked and were not retried.

Run only in a disposable Linux x86_64 cloud directory. All inputs are synthetic. Requires Python 3.12+; setup downloads the official Microsoft .NET SDK 10.0.401 (240,059,572 bytes, about 229 MiB compressed; allow approximately 1 GiB disk). Microsoft download access is needed only for SDK setup. The build clears NuGet package sources and uses no package dependencies. No global installation, certificate, account, native application, permission or clipboard configuration is performed.

Source: https://github.com/freestylefly/WeChatBridge/tree/07b88822debc3bd544ae7a83bc207633b29c3a04

After extracting this ZIP, open a shell in its `wechat_bridge_core_exercise/` directory. Execute these six commands in order:

1. `python3 run.py setup`
2. `python3 run.py verify`
3. `python3 run.py fixtures`
4. `python3 run.py build`
5. `python3 run.py test`
6. `python3 run.py report`

Outputs: setup-result.json verifies the official SDK SHA-512; verify-result.json verifies 46 unchanged Core files and the static bundle; inputs_manifest.json holds 20 synthetic input hashes; logs/ holds raw output and step timings; results/latest.json holds every case; experiment-report.json holds output hashes and limits. Expected build: 0 warnings / 0 errors. Expected tests: 42 passed / 0 failed. Each command exits nonzero on failure. Do not continue after a failed setup, verification, build or test.

Optional download-free reuse: before the same six commands, set WECHATBRIDGE_DOTNET_SDK to an existing extracted SDK directory and WECHATBRIDGE_DOTNET_ARCHIVE to the matching official archive. Setup verifies its published SHA-512 and compares every extracted regular SDK file with the archive before execution. It does not copy old build products. Record this reuse in your report. Without these variables setup downloads/extracts inside this directory. Both modes isolate runtime HOME/CLI home/temp/cache here.

## What 42 passes establish

Genuine unchanged upstream Windows.Core .NET code was invoked, rather than a rewritten model: ZIP parsing/CRC/bounds/path checks, staged original-file storage, rollback/size limits, 90-second intent and sequential replay suppression, state preservation, collection freeze/restart retry/remove-undo/recovery/retention. The harness and synthetic fixture generator are new test support code.

The result does not validate macOS Share Extension, AX/OCR, Windows native Share Target, real clipboard/paste, WeChat integration, real chat privacy or target-agent ingestion. Copied/Delivered model state is not evidence of a native action. Sequential intent consumption is not concurrent exactly-once delivery. GUID item IDs are identifiers, not integrity hashes. InboxWriter accepts a .zip suffix with non-ZIP bytes; archive validation is separate. Current intent freshness accepts future-dated requests because it only tests age <90 seconds.

## Preserved first failures

reference/logs/build-first.log records a setup error: /usr/bin/time is absent. It was replaced with Bash timing, then with the Python runner's monotonic timer. reference/logs/test-first.log and reference/test-results-first.json record 41/42 on the first harness run: I05 incorrectly compared a JSON whole-second timestamp to an in-memory fractional-second timestamp. Only the harness comparison was corrected to compare persisted batch/outcome times. No upstream source was altered. Final raw logs and case results are preserved beside them.

## License

Upstream Core files and notices retain MIT, Copyright (c) 2026 qzz0518. See upstream/LICENSE and upstream/THIRD-PARTY-NOTICES.md. Sparkle 2.9.6 belongs to the macOS app and is not downloaded, built or linked here. The Microsoft SDK is not bundled; its license and notices accompany its official archive. The exercise support code is provided under the same MIT terms in EXERCISE-LICENSE.txt.
