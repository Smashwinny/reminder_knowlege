# WeChatBridge source feasibility review

Inspected on 2026-10-05 UTC. Repository: https://github.com/freestylefly/WeChatBridge. Fixed commit: `07b88822debc3bd544ae7a83bc207633b29c3a04` (commit date 2026-10-03). Source is MIT, copyright (c) 2026 qzz0518; preserve LICENSE and THIRD-PARTY-NOTICES. This static review predates the experiment. It used no real chat data, WeChat database or native account and made no permission changes.

## What the product actually receives

The macOS product receives user-exported ZIP/TXT/media through a Share Extension, copies transient provider files into its own staging area, and exposes a complete batch by rename into Ready. It does not need database extraction/decryption or process injection. It may then activate another application and paste files/prompt text, or archive locally. Share Extension entitlements include sandbox/App Group access and a local fallback folder exception, without network entitlement. This does not establish the privacy behavior of a downstream AI application after handoff.

## Evidence and implementation

- `macos/Package.swift`: Swift tools 6.0; platform macOS 14; App + Share + Core. Sparkle 2.9.6 exact, revision ac2def288cbff5cfc7df3ffef6abdf45b72bcb0a, app-only dependency. Full macOS build is native; archive reader imports Darwin and zlib; other core files import AppKit/UniformTypeIdentifiers.
- `macos/Sources/WeChatBridgeCore/BatchStaging.swift`: manifest, intent and diagnostic files are written inside Staging, then whole batch is moved to Ready. Separate per-item directories preserve duplicate original names.
- `macos/Sources/WeChatBridgeCore/InboxReader.swift`: loads Ready, initializes state, consumes intent by read then delete, preserves target/context independently. Sequential replay suppression is not a distributed exactly-once guarantee; macOS ignores a deletion error.
- `windows/src/WeChatBridge.Windows.Core/WeChatBridge.Windows.Core.csproj`: plain net10.0, no PackageReference. Native Win32 calls exist in the broader assembly but can be kept out of the experiment call graph.
- `Archive/WeChatNativeArchive.cs`: stored/deflate ZIP, central-directory bounds, UTF-8 names, CRC32 and expanded size checks, transcript extraction and strict destination/path protections. Text collection limit 16 MiB; total declared expansion 1 GiB; at most 1000 entries.
- `Archive/WeChatTranscriptRecord.cs`: line-based sender and Chinese date-header parser; multiline body, CRLF/BOM handling. An unfamiliar TXT can still be preserved while parsed metadata remains unavailable.
- `InboxModels.cs`: explicit InboxPaths root; StageAsync copies originals and records schema/version/name/relative path/byte count/index; CommitAsync writes optional intent/state then Directory.Move. Rollback removes only its generated staging directory and records failure. ValidateSource verifies existence, reparse flag and .zip filename, NOT ZIP integrity.
- `InboxReader.cs` and `ShareAction.cs`: BatchIntent age <90 seconds; read/delete once for sequential readers; fresh/expired/none result. State tracks delivered/copied/failed/expired and target/chat/scene metadata.
- `Collections/CollectionService.cs` and `BatchCollection.cs`: collection order and SeenBatchIDs, freeze before delivery, subsequent share begins another collection, restart turns interrupted Delivering into Retry, recoverable removal/undo and retention protection.
- `Delivery/DeliveryEngine.cs`: delivered state means activation/paste steps accepted; there is no target-agent receipt proving ingestion or upload. This code will not be called in the Linux experiment.

## Platform and documentation reconciliation

The top-level README includes a substantial Windows tree. The product capabilities document dated 2026-09-20 still says macOS only; the Windows README still introduces an early PoC and says no automation/Obsidian/skills. The newer Windows parity document dated 2026-10-03 and source contain those additions. Therefore older statements cannot be used as a current feature matrix. Conversely, the presence of Windows code and mocked tests does not prove native sharing, app focus/real attachment receiving, installer signatures, or update parity. The current parity document itself lists these as installation-environment checks.

## Historical runtime and local setup

Cloud: Linux x86_64; git 2.52.0, Python 3.12.14, Node v24.19.0, zip/unzip. No preinstalled swift, dotnet, cargo/rustc, cmake in PATH or conventional runtime locations.

A scoped official Microsoft .NET SDK 10.0.401 linux-x64 tarball was downloaded into `exercise/`, verified against Microsoft release metadata SHA-512, and extracted there. Size 240,059,572 bytes. Checksum and URL are in `exercise/sdk_receipt.json`; source hashes in `exercise/source_receipt.json`. No global install, CLI execution, package restoration or upstream execution has occurred as of this preliminary review.

## Genuine-code experiment plan recorded before execution

Copy unchanged Core source/build properties beneath exercise/upstream and prove per-file hashes. Build a dependency-free console harness with a local NuGet.Config that clears package sources. All CLI home, temp, caches, generated synthetic inputs, staging/Ready outputs and reports stay under exercise. No xUnit/NuGet expansion; no OS/native entry point.

1. Parse synthetic stored and deflated UTF-8 chat + image/data attachment ZIPs; verify record count, multiline content, extracted bytes and hashes.
2. Reject malformed/empty/CRC-corrupt archives and unsafe extraction entries (traversal, symlink, case alias), and preserve nonrecognized TXT as raw text.
3. Verify Staging is hidden until commit, Ready transition, duplicate basename handling, original-byte retention, partial failure rollback and injected per-file/batch limits.
4. Verify fresh/90-second-expired intent and sequential single-use across reader restarts; preserve state/target/chat context.
5. Verify collection freeze order, late-share split, restart retry state, idempotent append, original ZIP preservation and remove/undo recovery.
6. Demonstrate and label the separate trust boundaries: naming a file .zip can pass InboxWriter while archive integrity parsing rejects its bytes.

A successful run can establish only these portable core behaviors. It cannot claim macOS Share Extension, accessibility/OCR, real WeChat export integration, Windows Explorer Share Target/UI, real clipboard/paste or target-agent ingestion passed.
