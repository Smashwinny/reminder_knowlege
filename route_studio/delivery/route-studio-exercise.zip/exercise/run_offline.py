#!/usr/bin/env python3
"""TEST_ONLY: exercise genuine Route Studio GPX/motion units without device I/O.

Run with Python 3.11+ and a separately obtained, pinned upstream checkout.
No dependencies need installation. This file is original test code, not an
upstream implementation. It emits a test-summary JSON, never an activity track.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.abc
import io
import json
import math
import os
from pathlib import Path
import sys

PINNED_COMMIT = "137297d7ca980f92a6a832708c9c61964bde7591"
SOURCE_HASHES = {
    "src/ios_location_controller/__init__.py": "17b0bb01dc54f5c4d0ec16a7191aa50aeaf3c0123b76495d708f243c8e776630",
    "src/ios_location_controller/gpx.py": "5eeb6740526cceb54fc51b27e61efff5921044d57e8795558190d8004259f98a",
    "src/ios_location_controller/motion.py": "69a5f59b42616bb65b6ef4f57937bcedaa70ad09256f8a757fa8fc7223828297",
}
ALLOWED_PROJECT_MODULES = {
    "ios_location_controller",
    "ios_location_controller.gpx",
    "ios_location_controller.motion",
}


def run(repo: Path, fixture: Path, output: Path) -> dict:
    result = {
        "label": "TEST_ONLY_OFFLINE_SOFTWARE_TEST_NOT_ACTIVITY_EVIDENCE",
        "upstream": "https://github.com/yinsuecci/mockrunning",
        "pinned_commit": PINNED_COMMIT,
        "python_version": sys.version.split()[0],
        "scope": "Only genuine gpx.py and motion.py, synthetic input near 0,0",
        "activity_timestamps": False,
        "activity_export": False,
        "device_observation": False,
        "steps": [],
        "assertions": 0,
        "forbidden_io_attempts": [],
        "source_hashes": {},
        "status": "running",
    }

    def check(condition: bool, description: str) -> None:
        if not condition:
            raise AssertionError(description)
        result["assertions"] += 1

    def rejects(function, description: str, error=ValueError) -> None:
        try:
            function()
        except error:
            check(True, description)
        else:
            raise AssertionError(description + ": expected rejection")

    def step(number: int, name: str, details: dict) -> None:
        result["steps"].append({"step": number, "name": name, "status": "passed", **details})

    def forbidden(name: str) -> None:
        result["forbidden_io_attempts"].append(name)
        raise RuntimeError("Offline boundary blocked: " + name)

    class OnlyPureProjectModules(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if (fullname.startswith("ios_location_controller.")
                    and fullname not in ALLOWED_PROJECT_MODULES):
                forbidden("import:" + fullname)
            if fullname.split(".")[0] in {
                "pymobiledevice3", "playwright", "socket", "subprocess",
                "asyncio", "threading", "ctypes",
            }:
                forbidden("import:" + fullname)
            return None

    # Fail closed on accidental networking, process launch, or writes outside
    # the designated summary. This is an in-process guard, not an OS sandbox.
    def audit(event, args):
        if (event.startswith("socket.") or event.startswith("subprocess.")
                or event.startswith("os.exec") or event.startswith("os.spawn")
                or event in {"os.system", "os.fork", "os.forkpty", "pty.spawn"}):
            forbidden(event)
        if event == "open":
            path, mode, flags = args
            writable = (isinstance(mode, str) and any(c in mode for c in "wax+"))
            writable = writable or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT
                                                  | os.O_TRUNC | os.O_APPEND))
            if writable and not (isinstance(path, (str, bytes, os.PathLike))
                                 and Path(path).resolve() == output):
                forbidden("write-outside-summary")

    try:
        check(sys.version_info >= (3, 11), "Python 3.11 or newer")
        check("TEST_ONLY" in fixture.name, "Fixture must be clearly synthetic")
        for relative, expected in SOURCE_HASHES.items():
            actual = hashlib.sha256((repo / relative).read_bytes()).hexdigest()
            check(actual == expected, "Pinned source digest: " + relative)
            result["source_hashes"][relative] = actual
        fixture_text = fixture.read_text(encoding="utf-8")
        check("<time" not in fixture_text, "No activity timestamps in fixture")
        check("TEST_ONLY" in fixture_text, "TEST_ONLY fixture content label")
        result["fixture_sha256"] = hashlib.sha256(fixture_text.encode()).hexdigest()

        sys.dont_write_bytecode = True
        sys.meta_path.insert(0, OnlyPureProjectModules())
        sys.addaudithook(audit)
        sys.path.insert(0, str(repo / "src"))
        from ios_location_controller.gpx import Point, distance_meters, interpolate, load_points
        from ios_location_controller.motion import Motion, Settings, route_points

        points = load_points(fixture)
        check(len(points) == 3, "Namespaced track parses three points")
        check(all(p.timestamp is None for p in points), "Parsed timestamps absent")
        check(all(abs(p.latitude) <= 0.002 and abs(p.longitude) <= 0.002 for p in points),
              "All accepted test coordinates near synthetic origin")
        check([(p.latitude, p.longitude) for p in points] == [(0, 0), (0, .001), (0, .002)],
              "Parser preserves coordinate order")
        step(1, "Pin source and parse synthetic GPX", {"parsed_points": len(points)})

        def xml_load(text):
            return load_points(io.StringIO(text))

        singleton = xml_load('<gpx><trkpt lat="0" lon="0"/></gpx>')
        check(len(singleton) == 1, "File parser accepts a singleton track")
        rejects(lambda: xml_load("<gpx/>"), "Empty GPX")
        rejects(lambda: xml_load('<gpx><rte><rtept lat="0" lon="0"/>'
                                 '<rtept lat="0" lon=".001"/></rte></gpx>'),
                "File parser does not support route points")
        invalid_coordinates = [("nan", "0"), ("0", "inf"), ("91", "0"), ("0", "181")]
        for lat, lon in invalid_coordinates:
            rejects(lambda lat=lat, lon=lon: xml_load(
                f'<gpx><trkpt lat="{lat}" lon="{lon}"/></gpx>'),
                "Invalid coordinate sentinel")
        # Far-out numeric values above are rejection sentinels, never routes.
        items = [{"lat": p.latitude, "lng": p.longitude} for p in points]
        checked = route_points(items)
        check(checked == points, "route_points matches parser output")
        route_failures = [None, [], items[:1], [items[0], items[0]],
                          [{"lat": 0, "lng": 0}, {"lat": 0, "lng": 1e-8}],
                          [{"lat": float("nan"), "lng": 0}, items[1]],
                          [{"lat": 0, "lng": float("inf")}, items[1]],
                          [items[0]] * 10001]
        for bad in route_failures:
            rejects(lambda bad=bad: route_points(bad), "Invalid route shape or coordinate")
        step(2, "Compare parser and route-validation contracts", {
            "gpx_rejection_cases": 6,
            "route_rejection_cases": len(route_failures),
            "singleton_parser_accepts_route_validator_rejects": True,
            "standalone_parser_rejects_rtept": True,
        })

        segment = distance_meters(points[0], points[1])
        total = sum(distance_meters(a, b) for a, b in zip(points, points[1:]))
        check(math.isclose(segment, 111.19492664455875, abs_tol=1e-8),
              "One millidegree at equator using upstream spherical radius")
        check(math.isclose(total, 2 * segment, abs_tol=1e-8), "Two equal segments")
        check(distance_meters(points[0], points[0]) == 0, "Identity distance")
        check(math.isclose(distance_meters(points[1], points[0]), segment, abs_tol=1e-8),
              "Symmetric distance")
        for fraction, expected in [(-1, points[0]), (0, points[0]),
                                   (.5, Point(0, .0005)), (1, points[1]), (2, points[1])]:
            check(interpolate(points[0], points[1], fraction) == expected,
                  "Interpolation midpoint or clamp")
        step(3, "Verify distance and interpolation", {
            "synthetic_segment_m": segment,
            "synthetic_total_m": total,
            "interpolation_cases": 5,
        })

        # Exact seven input vectors in upstream tests/test_motion.py lines 9-11.
        # They are invoked here without importing that module, because it imports
        # web/playback. This is adapted coverage, not an upstream pytest run.
        upstream_invalid_settings = [
            {"speed_kmh": 0}, {"interval": float("nan")},
            {"lateral_variation_m": -1}, {"speed_variation_pct": 81},
            {"loop": "false"}, {"random_seed": 1.2}, {"extra": 1},
        ]
        for bad in upstream_invalid_settings:
            rejects(lambda bad=bad: Settings.parse(bad), "Upstream invalid-settings vector")
        settings = Settings.parse({"speed_kmh": 3.6, "interval": 1,
                                   "speed_variation_pct": 0, "lateral_variation_m": 0})
        check(settings.speed_variation_pct == settings.lateral_variation_m == 0,
              "No variation or realism tuning")
        step(4, "Replay seven upstream-derived validation cases", {
            "upstream_cases_adapted": 7,
            "upstream_test_modules_executed": 0,
            "variations_zero": True,
        })

        motion = Motion(checked, settings)
        check((motion.distance, motion.elapsed, motion.laps) == (0, 0, 0),
              "Motion starts with zero explicit state")
        at_start, speed, done = motion.advance(0, settings)
        check(at_start == points[0] and not done, "Zero advance stays at start")
        midpoint, speed, done = motion.advance(total / 2, settings)
        check(distance_meters(midpoint, points[1]) < 1e-8 and not done,
              "Deterministic advance reaches midpoint")
        check(speed == 3.6 and math.isclose(motion.distance, total / 2, abs_tol=1e-8),
              "One-metre-per-simulated-second advance")
        snapshot = (motion.distance, motion.elapsed, motion.laps)
        check(snapshot == (motion.distance, motion.elapsed, motion.laps),
              "Reading state does not advance it")
        endpoint, _, done = motion.advance(total, settings)
        check(done and distance_meters(endpoint, points[-1]) < 1e-8,
              "Nonloop completion clamps coordinate to endpoint")
        check(math.isclose(motion.distance, total, abs_tol=1e-8), "Distance clamps to total")
        duplicate = Motion([points[0], points[0], points[1]], settings)
        dup_point, _, _ = duplicate.advance(segment / 2, settings)
        check(distance_meters(dup_point, Point(0, .0005)) < 1e-8,
              "Intermediate zero-length segment is skipped")
        loop_settings = Settings.parse({"speed_kmh": 3.6, "speed_variation_pct": 0,
                                       "lateral_variation_m": 0, "loop": True})
        looping = Motion(checked, loop_settings)
        _, _, loop_done = looping.advance(total * 2.25, loop_settings)
        check(looping.laps == 2 and not loop_done, "Loop counts two complete synthetic laps")
        check(math.isclose(looping.distance, total * .25, abs_tol=1e-8),
              "Loop wraps remaining distance")
        speed_comparison = []
        for test_speed, expected_distance in [(3.6, 10.0), (7.2, 20.0)]:
            comparison_settings = Settings.parse({
                "speed_kmh": test_speed, "speed_variation_pct": 0,
                "lateral_variation_m": 0,
            })
            comparison_motion = Motion(checked, comparison_settings)
            comparison_point, _, comparison_done = comparison_motion.advance(10, comparison_settings)
            check(math.isclose(comparison_motion.distance, expected_distance, abs_tol=1e-8),
                  "Controlled speed change gives expected synthetic distance")
            check(math.isclose(distance_meters(points[0], comparison_point),
                               expected_distance, abs_tol=1e-8),
                  "Controlled speed change gives expected interpolated coordinate")
            check(not comparison_done, "Short controlled comparison does not complete route")
            speed_comparison.append({
                "test_speed_kmh": test_speed,
                "logical_dt_s": 10,
                "synthetic_distance_m": comparison_motion.distance,
                "synthetic_point": {"lat": comparison_point.latitude,
                                    "lng": comparison_point.longitude},
            })
        step(5, "Verify explicit motion state transitions", {
            "nonloop_endpoint_clamped": True,
            "loop_counter": looping.laps,
            "controller_pause_resume_tested": False,
            "state_trace": {
                "midpoint_distance_m": total / 2,
                "midpoint_synthetic_point": {"lat": midpoint.latitude, "lng": midpoint.longitude},
                "endpoint_distance_m": motion.distance,
                "endpoint_synthetic_point": {"lat": endpoint.latitude, "lng": endpoint.longitude},
                "loop_residual_m": looping.distance,
            },
            "controlled_speed_comparison": speed_comparison,
        })

        first, second = Motion(checked, settings), Motion(checked, settings)
        for delta in [0, .25, .75, 1, 2, 4]:
            check(first.advance(delta, settings) == second.advance(delta, settings),
                  "Deterministic explicit-advance replay")
        loaded = sorted(name for name in sys.modules if name.startswith("ios_location_controller"))
        check(set(loaded) == ALLOWED_PROJECT_MODULES, "Only the three pure project modules loaded")
        check(not result["forbidden_io_attempts"], "No forbidden I/O attempted")
        for relative, expected in SOURCE_HASHES.items():
            check(hashlib.sha256((repo / relative).read_bytes()).hexdigest() == expected,
                  "Source remains unchanged: " + relative)
        step(6, "Replay deterministically and verify offline boundary", {
            "deterministic_replay_steps": 6,
            "loaded_project_modules": loaded,
            "source_unchanged": True,
            "guard_scope": "Process-local audit/import guards, not an OS-level network sandbox",
            "forbidden_io_attempts": 0,
        })
        result["status"] = "passed"
    except BaseException as exc:
        result["status"] = "failed"
        result["failure"] = {"type": type(exc).__name__, "message": str(exc)}
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
                      encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    fixture = Path(__file__).resolve().with_name("TEST_ONLY_fixture.gpx")
    result = run(args.repo.resolve(), fixture, args.output.resolve())
    print(json.dumps({"status": result["status"], "steps": len(result["steps"]),
                      "assertions": result["assertions"],
                      "failure": result.get("failure")}, ensure_ascii=False))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
