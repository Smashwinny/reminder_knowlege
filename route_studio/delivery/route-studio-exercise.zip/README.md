# Route Studio TEST_ONLY 纯模块实验

公开副本说明：本包保留 2026-10-05 的历史合成组件学习，本次公开整理没有重跑实验、重新生成样例或执行源码获取。原点附近且无时间戳的 TEST_ONLY 样例、运行器、检查器和来源清单均保留原字节；仅新增本段说明。不含上游源码，不生成真实活动证明，不说明设备或现实运动效果。HTML 浏览器视觉及 HTML 转 PDF 原路线受环境限制，本次未重试。

运行范围：仅固定版 gpx.py、motion.py 与无设备副作用的包入口；没有设备、浏览器或服务启动。合成 GPX 不带活动时间戳，不表示真实运动。

前置条件：Bash 终端、Python 3.11+、Git；第2步需要联网正常读取 GitHub。下载 ZIP 后在其所在目录操作，目标 route-studio-lab 须不存在。仅验证这一 Bash 路径，没有声称 Windows PowerShell 已复验。

上游固定提交：137297d7ca980f92a6a832708c9c61964bde7591。未发现 LICENSE/COPYING，因此本 ZIP 不包含上游代码。七组设置无效值是对上游测试输入的独立改写，未分发或执行上游测试模块。

## 1 解包并核对工具

目的：建立全新目录；只需 Bash、Python 3.11+、Git 与一次源码获取网络

```bash
python3 -I -B -m zipfile -e route-studio-exercise.zip route-studio-lab
cd route-studio-lab
python3 --version
git --version
```

验证与失败条件：Python 至少 3.11；出现 exercise/run_offline.py 和 TEST_ONLY_fixture.gpx

## 2 获取固定版源码

目的：单独获取并固定上游版本，避免默认分支日后变化

```bash
git init --quiet source
git -C source remote add origin https://github.com/yinsuecci/mockrunning.git
git -C source fetch --depth 1 origin \
  137297d7ca980f92a6a832708c9c61964bde7591
git -C source checkout --quiet --detach FETCH_HEAD
git -C source rev-parse HEAD
```

验证与失败条件：HEAD 必须完整等于固定哈希；获取失败就停止，不改为其他版本

## 3 运行纯模块实验

目的：只运行 gpx 和 motion；所有错误必须触发非零退出码

```bash
python3 -I -B exercise/run_offline.py \
  --repo source --output first.json
```

验证与失败条件：status=passed，steps=6，断言数匹配本包记录；否则读 failure 后停止

## 4 查看几何与状态结果

目的：把通过状态展开成米数、插值、反例和推进状态

```bash
python3 -I -B inspect_result.py metrics first.json
```

验证与失败条件：段长约111.194927m，总长约222.389853m；零波动速度翻倍后距离翻倍

## 5 用同一输入重新计算

目的：验证确定性；同版本同输入应产生逐字段一致的 JSON

```bash
python3 -I -B exercise/run_offline.py \
  --repo source --output second.json
python3 -I -B inspect_result.py compare first.json second.json
```

验证与失败条件：显示 REPLAY_IDENTICAL: true；任何不同都需要查版本与输入

## 6 检查边界与源码清洁度

目的：确认模块范围、无设备观察、无活动导出、无源码改动

```bash
python3 -I -B inspect_result.py boundary first.json
git -C source status --porcelain --untracked-files=all
```

验证与失败条件：仅三项允许的项目模块、禁用 I/O 尝试数为0；Git 状态应为空

输出仅为测试摘要 JSON，不生成活动轨迹。防护是进程内 audit/import guard，不是操作系统网络沙箱。数据校验通过、纯函数通过、真实设备行为是不同结论。
