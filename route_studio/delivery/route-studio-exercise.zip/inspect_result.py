#!/usr/bin/env python3
"""Read only TEST_ONLY summaries. Does not import upstream or emit a track."""
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('mode',choices=['metrics','compare','boundary'])
p.add_argument('first',type=Path)
p.add_argument('second',nargs='?',type=Path)
a=p.parse_args(); r=json.loads(a.first.read_text(encoding='utf-8'))
assert r['status']=='passed' and r['label'].startswith('TEST_ONLY_')
if a.mode=='compare':
    assert a.second is not None
    other=json.loads(a.second.read_text(encoding='utf-8'))
    assert r==other, 'Replay summaries differ'
    print('REPLAY_IDENTICAL: true')
elif a.mode=='boundary':
    expected=['ios_location_controller','ios_location_controller.gpx','ios_location_controller.motion']
    final=r['steps'][-1]
    assert final['loaded_project_modules']==expected
    assert r['activity_timestamps'] is False and r['activity_export'] is False
    assert r['device_observation'] is False and r['forbidden_io_attempts']==[]
    assert final['source_unchanged'] is True
    print('PROJECT_MODULES: '+', '.join(expected))
    print('FORBIDDEN_IO_ATTEMPTS: 0')
    print('SOURCE_UNCHANGED: true')
    print('DEVICE_OBSERVATION: false')
    print('GUARD: process-local audit/import guard, not OS sandbox')
else:
    print('STATUS: '+r['status'])
    print('ASSERTIONS: '+str(r['assertions']))
    for s in r['steps']:
        if s['step'] in [2,3,4,5]:
            print(json.dumps(s,ensure_ascii=False,sort_keys=True))
