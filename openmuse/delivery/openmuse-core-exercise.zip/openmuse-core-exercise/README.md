# OpenMuse core reliability exercise

Publication copy: this preserves the recorded 2026-10-05 experiment; no dependency installation, test execution or experiment rerun occurred during publication preparation. Changes are limited to publication/provenance notes, private absolute paths in historical logs, and dependent archive checksums. Path markers <EXERCISE_DIR>, <REVIEW_EXERCISE_DIR> and <NODE_RUNTIME> identify roles without disclosing original locations. Commands, flags, versions, observations, errors, durations and test counts remain unchanged. The original-source acquisition note is generalized to remove private mapping context. Saved group sha256 values in experiment-result.json refer to historical logs before path normalization; bundle-file-sha256.json verifies the current public members. Upstream code, MIT LICENSE, authored tests and dependency locks are byte-identical. Browser and HTML-to-PDF routes were blocked previously and were not retried; HTML has structural checks only.

Source: https://github.com/CopilotKit/openmuse/tree/b06caad7005ac5b6d2b451752a3794a6ae1759c1

This exercise runs byte-identical upstream approval, SQL-store, and worker code. It does not start the OpenMuse app, log into a service, send mail, open a browser, or call a model. All owner names, addresses, action contents, provider callbacks, and worker handlers are synthetic fixtures. PGlite is the actual embedded PostgreSQL implementation, not a mocked database.

## Recorded result

On 2026-10-05, Node v24.19.0 / npm 11.9.0, 11:46:11–11:46:23 UTC:

- 12 original approval tests passed
- 8 original engine tests passed
- 1 original persistence test passed, selected using `--test-name-pattern='fresh nested data directory'`
- The other persistence test was intentionally excluded. This Node version reports only the selected test and `skipped 0`; it is not a 22-test result
- 4 separately authored changed-input/lease characterization tests passed
- All four processes exited 0 and reported `NETWORK_GUARD attempts=0`

The process-local guard blocks common HTTP/TCP/UDP dispatch and listeners during testing. It is an extra check, not an OS-level network-isolation claim. Dependencies must be downloaded first from the official npm registry; the test phase itself needs no network or secrets.

## Six reproducible command groups

Run from this extracted directory in Bash with Node 24 and Python 3 available. The upstream README recommends pnpm 11.19.0 for the whole application; this deliberately smaller exercise uses npm and Node's experimental TypeScript transformation instead of installing the full application or tsx.

1. Verify fixed upstream source copies and dependency lock integrity:

   `node --version; npm --version; python3 verify-exercise.py`

2. Install only the 16 pinned dependencies, with install scripts disabled:

   `bash install-deps.sh; python3 verify-exercise.py`

   This writes only `node_modules`, `home`, `cache`, `tmp`, and logs in this exercise. Existing platform proxy and certificate variables are preserved for the download. Certificate verification is never disabled. It does not copy user npm credentials or load user/global npm config. The initial investigation used `npm install` to create the supplied package lock; clean reproduction uses `npm ci`.

3. Run the original action-review tests and inspect `rawlogs/03-original-actions.log`:

   `bash run-core.sh actions`

   The script prints exact commands, UTC timestamps, TAP output, network-guard counts, and exit codes. This group runs `upstream/tests/actions.test.ts` (12 tests). Inputs include a wrong owner, stale hash, expired review, disconnected account, changed connection, and uncertain provider result. The recorded original execution used `bash run-core.sh` without a selector, which runs groups 3–6 in order.

4. Inspect original engine execution, `rawlogs/04-original-engine.log`:

   `bash run-core.sh engine; cat rawlogs/04-original-engine.log`

   Eight tests include two same-process workers sharing a real store, cancellation before the next guarded effect, saved checkpoint after actual database close/reopen, pending approval fairness, and a failed run-record write.

5. Inspect persisted uncertain-state recovery, `rawlogs/05-original-persistence.log`:

   `bash run-core.sh persistence; cat rawlogs/05-original-persistence.log`

   The original full test file is unmodified. Name selection runs only the real nested-directory database restart test; the unrelated PostgreSQL pool-error test is excluded. An `executing` record becomes `outcome_unknown` after close/reopen and recovery.

6. Inspect changed inputs and verify the final source fingerprint:

   `bash run-core.sh characterization; cat rawlogs/06-changed-input-characterization.log; python3 verify-exercise.py`

   Four new tests are in `characterization.test.ts`, distinct from original tests. They vary the proposal subject and operation key, use wrong owner and stale hash, preserve an uncertain provider result through real PGlite reopen, and advance a virtual clock by 60,001 ms to let another worker take a lease. The old worker's checkpoint and next guarded effect are rejected.

## Important interpretation boundaries

- Changing the payload under a new operation key changes the review hash. Reusing the same operation key returns the original stored proposal even if the new payload differs. This is operation identity reuse; it is not payload-equivalence validation
- The original approval version test proves stored version binding, changed hashes, and forwarding revision 1 to an injected adapter. It does not exercise Google, HTTP `If-Match`, or a live provider version conflict
- SQL compare-and-swap fences the task-state checkpoint by lease identity/status. A lease does not prove exactly-once external side effects. `event()` checks a guard before a separate write, and arbitrary handler effects require their own boundary checks
- Concurrency here uses separate worker objects in one process and one PGlite store. This is not a multi-process PostgreSQL or distributed-system acceptance test
- Uncertain provider outcomes are deliberately not replayed. The fixture throws an uncertainty-marked error; it does not actually send anything or prove what a remote provider did
- Close/reopen and seeded interrupted records are controlled recovery simulations. No production server was killed and no real account was used
- The upstream `docs/VERIFICATION.md` describes a historical September 16 run. Its 154-test number must not be attributed to this October 5 exercise
- This is a focused test subset, not a full app build, typecheck, browser test, security audit, E2B validation, or production-readiness verdict

## Evidence and provenance

`source-manifest.json` records upstream commit and SHA-256 fingerprints. `dependency-receipt.json` records all 16 exact dependency versions and SHA-512 registry integrity values checked against upstream `pnpm-lock.yaml`. `rawlogs/` contains the actual recorded outputs, including unsuccessful dependency setup attempts. The initial `/dev/null` config collision, missing-proxy DNS failure, and omitted-platform-CA TLS failure were resolved without disabling verification or changing global settings.

The upstream source is MIT licensed; its complete license is included at `upstream/LICENSE`. Minimal original files are copied without edits. This teaching harness is separate, and dependencies are not bundled. The original introductory webpage was not read; its promotional claims are not treated as verified facts.
