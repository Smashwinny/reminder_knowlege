#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p rawlogs tmp home
run() {
  local label="$1"; shift
  local log="rawlogs/${label}.log"
  date -u +'%Y-%m-%dT%H:%M:%SZ' | tee "$log"
  printf 'COMMAND: env -i PATH=<existing> HOME=%q TMPDIR=%q node --experimental-transform-types --import ./offline-guard.mjs --test --test-isolation=none --test-concurrency=1 --test-reporter=tap ' "$PWD/home" "$PWD/tmp" | tee -a "$log"
  printf '%q ' "$@" | tee -a "$log"
  printf '\n' | tee -a "$log"
  set +e
  env -i PATH="$PATH" HOME="$PWD/home" TMPDIR="$PWD/tmp" node --experimental-transform-types --import ./offline-guard.mjs --test --test-isolation=none --test-concurrency=1 --test-reporter=tap "$@" 2>&1 | tee -a "$log"
  local code=${PIPESTATUS[0]}
  set -e
  printf '\nEXIT_CODE=%s\n' "$code" | tee -a "$log"
  date -u +'%Y-%m-%dT%H:%M:%SZ' | tee -a "$log"
  return "$code"
}
selection="${1:-all}"
case "$selection" in all|actions|engine|persistence|characterization) ;; *) echo 'Usage: bash run-core.sh [all|actions|engine|persistence|characterization]' >&2; exit 2;; esac
if [[ "$selection" == all || "$selection" == actions ]]; then
  run 03-original-actions upstream/tests/actions.test.ts
fi
if [[ "$selection" == all || "$selection" == engine ]]; then
  run 04-original-engine upstream/tests/engine.test.ts
fi
if [[ "$selection" == all || "$selection" == persistence ]]; then
  run 05-original-persistence --test-name-pattern='fresh nested data directory' upstream/tests/persistence.test.ts
fi
if [[ "$selection" == all || "$selection" == characterization ]]; then
  run 06-changed-input-characterization characterization.test.ts
fi
