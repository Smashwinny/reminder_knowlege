#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p rawlogs tmp home cache
: > home/empty-user.npmrc
: > home/empty-global.npmrc
date -u +'%Y-%m-%dT%H:%M:%SZ' | tee rawlogs/reproduce-install.log
env -i PATH="$PATH" HTTP_PROXY="${HTTP_PROXY:-}" HTTPS_PROXY="${HTTPS_PROXY:-}" ALL_PROXY="${ALL_PROXY:-}" NO_PROXY="${NO_PROXY:-}" NODE_EXTRA_CA_CERTS="${NODE_EXTRA_CA_CERTS:-}" SSL_CERT_FILE="${SSL_CERT_FILE:-}" HOME="$PWD/home" TMPDIR="$PWD/tmp" npm_config_cache="$PWD/cache" npm_config_userconfig="$PWD/home/empty-user.npmrc" npm_config_globalconfig="$PWD/home/empty-global.npmrc" npm ci --ignore-scripts --no-audit --no-fund --registry=https://registry.npmjs.org --fetch-retries=0 --fetch-timeout=20000 --update-notifier=false --loglevel=notice 2>&1 | tee -a rawlogs/reproduce-install.log
date -u +'%Y-%m-%dT%H:%M:%SZ' | tee -a rawlogs/reproduce-install.log
