// New learning tests. They import pristine upstream implementations.
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ActionService } from './upstream/apps/server/src/actions.ts';
import { createStore } from './upstream/apps/server/src/db.ts';
import { TaskWorker, LostLeaseError } from './upstream/apps/server/src/engine/worker.ts';

const input = (subject: string) => ({ kind: 'email.send', data: {
  to: ['fixture@example.com'], subject, body: 'Synthetic offline fixture.',
  cc: [], bcc: [], attachmentIds: [],
} });

test('changed payload with a new operation key changes the review hash and rejects the old hash', async () => {
  const db = await createStore();
  let calls = 0;
  try {
    const service = new ActionService(db, { connected: async () => true, execute: async () => { calls++; return 'fixture'; } });
    const first = await service.propose('owner', input('Baseline'), 'operation-1');
    const changed = await service.propose('owner', input('Changed subject'), 'operation-2');
    assert.notEqual(first.hash, changed.hash);
    await assert.rejects(service.decide('owner', changed.id, first.hash, 'approve'), /changed/i);
    await assert.rejects(service.decide('different-owner', changed.id, changed.hash, 'approve'), /not found/i);
    assert.equal(calls, 0);
    assert.equal((await db.get('owner', 'actions', changed.id))?.status, 'awaiting_review');
    console.log('OBSERVATION changed_subject=true changed_hash=true stale_hash_rejected=true wrong_owner_rejected=true provider_calls=0');
  } finally { await db.close(); }
});

test('same operation key with changed payload returns the original persisted proposal', async () => {
  const db = await createStore();
  try {
    const service = new ActionService(db, { connected: async () => true, execute: async () => 'fixture' });
    const first = await service.propose('owner', input('Baseline'), 'same-operation');
    const replay = await service.propose('owner', input('Changed subject'), 'same-operation');
    assert.equal(replay.id, first.id);
    assert.equal(replay.hash, first.hash);
    assert.equal(replay.data.subject, 'Baseline');
    assert.equal((await db.list('owner', 'actions')).length, 1);
    console.log('OBSERVATION changed_subject=true reused_key=true original_payload_returned=true action_count=1');
  } finally { await db.close(); }
});

test('uncertain provider outcome survives real PGlite reopen and repeated approval does not replay', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'openmuse-characterization-'));
  let calls = 0;
  const options = { connected: async () => true, execute: async () => {
    calls++;
    throw Object.assign(new Error('Synthetic response lost after dispatch'), { outcomeUnknown: true });
  } };
  let db = await createStore({ dataDir: join(dir, 'db') });
  try {
    const first = new ActionService(db, options);
    const proposal = await first.propose('owner', input('Uncertain'), 'uncertain-operation');
    assert.equal((await first.decide('owner', proposal.id, proposal.hash, 'approve')).status, 'outcome_unknown');
    await db.close();
    db = await createStore({ dataDir: join(dir, 'db') });
    await db.recoverInterruptedActions();
    const reopened = new ActionService(db, options);
    assert.equal((await reopened.decide('owner', proposal.id, proposal.hash, 'approve')).status, 'outcome_unknown');
    assert.equal(calls, 1);
    console.log('OBSERVATION provider_calls=1 reopened_database=true final_status=outcome_unknown replay_calls=0');
  } finally { await db.close(); await rm(dir, { recursive: true, force: true }); }
});

test('expired-lease takeover rejects an old worker checkpoint and its next guarded effect', async () => {
  const db = await createStore();
  let now = Date.parse('2026-01-01T00:00:00Z');
  let start!: () => void, release!: () => void;
  const started = new Promise<void>(resolve => { start = resolve; });
  const held = new Promise<void>(resolve => { release = resolve; });
  let staleCheckpoints = 0, oldEffects = 0, newEffects = 0;
  let firstTick: Promise<void> | undefined;
  try {
    await db.put('owner', 'tasks', { id: 'lease-task', title: 'Fixture', prompt: 'Fixture', kind: 'agent', status: 'queued', plan: [], evidence: [], input: {}, state: {}, createdAt: new Date(now).toISOString(), updatedAt: new Date(now).toISOString(), attempts: 0, leaseId: null, leaseUntil: null, artifactIds: [] });
    const oldWorker = new TaskWorker(db, async (_owner, _task, ctx) => {
      start();
      await held;
      await assert.rejects(ctx.checkpoint({ result: 'stale overwrite' }), LostLeaseError);
      staleCheckpoints++;
      await ctx.guard();
      oldEffects++;
      return { status: 'succeeded', result: 'old worker' };
    }, { now: () => now, leaseMs: 60000 });
    const newWorker = new TaskWorker(db, async () => {
      newEffects++;
      return { status: 'succeeded', result: 'new worker' };
    }, { now: () => now, leaseMs: 60000 });
    firstTick = oldWorker.tick();
    await started;
    now += 60001;
    await newWorker.tick();
    release();
    await firstTick;
    const saved = await db.get('owner', 'tasks', 'lease-task');
    assert.equal(saved?.result, 'new worker');
    assert.equal(saved?.attempts, 2);
    assert.equal(staleCheckpoints, 1);
    assert.equal(oldEffects, 0);
    assert.equal(newEffects, 1);
    console.log('OBSERVATION same_process=true virtual_clock_advanced_ms=60001 claims=2 stale_checkpoint_rejected=true old_guarded_effects=0 new_handler_calls=1 final_result=new_worker');
  } finally { release(); await firstTick?.catch(() => {}); await db.close(); }
});
