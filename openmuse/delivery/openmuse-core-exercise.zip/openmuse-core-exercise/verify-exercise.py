"""Verify unchanged source and pinned npm integrity without running upstream code."""
import hashlib
import json
import pathlib
import re

root = pathlib.Path(__file__).resolve().parent
manifest = json.loads((root / "source-manifest.json").read_text())
for name, expected in manifest["files"].items():
    actual = hashlib.sha256((root / "upstream" / name).read_bytes()).hexdigest()
    assert actual == expected, f"Source changed: {name}"
print(f"SOURCE_SHA256_OK files={len(manifest['files'])} commit={manifest['commit']}")

lock = json.loads((root / "package-lock.json").read_text())
upstream_lock = (root / "upstream/pnpm-lock.yaml").read_text()
count = 0
for path, entry in lock["packages"].items():
    if not path:
        continue
    name = path.split("node_modules/")[-1]
    version = entry["version"]
    key = f"{name}@{version}"
    match = re.search(r"^  ['\"]?" + re.escape(key) + r"['\"]?:\n    resolution: \{integrity: ([^}]+)\}", upstream_lock, re.M)
    assert match and match.group(1) == entry.get("integrity"), f"Integrity mismatch: {key}"
    assert entry["resolved"].startswith("https://registry.npmjs.org/"), f"Unexpected registry: {key}"
    installed = root / path / "package.json"
    if installed.exists():
        assert json.loads(installed.read_text())["version"] == version, f"Installed version mismatch: {key}"
    count += 1
assert count == 16, f"Unexpected dependency count: {count}"
print("NPM_LOCK_INTEGRITY_OK packages=16 lifecycle_scripts_not_needed=true")
