// Process-local test guard only. It does not change OS/network settings.
import net from 'node:net';
import tls from 'node:tls';
import http from 'node:http';
import https from 'node:https';
import dgram from 'node:dgram';
let attempts = 0;
const blocked = () => {
  attempts += 1;
  throw new Error('Offline exercise: network use is forbidden');
};
globalThis.fetch = blocked;
net.Socket.prototype.connect = blocked;
net.Server.prototype.listen = blocked;
tls.connect = blocked;
http.request = blocked;
http.get = blocked;
https.request = blocked;
https.get = blocked;
dgram.Socket.prototype.send = blocked;
dgram.Socket.prototype.bind = blocked;
process.on('exit', () => {
  console.log(`NETWORK_GUARD attempts=${attempts}`);
  if (attempts) process.exitCode = 1;
});
