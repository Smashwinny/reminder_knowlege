#!/usr/bin/env node
// Original study harness. It does not ship or execute Patchright or a browser.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { stripTypeScriptTypes } from 'node:module';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(fs.readFileSync(path.join(here, 'source-manifest.json'), 'utf8'));
const args = process.argv.slice(2);
const option = (name) => {
  const i = args.indexOf(name);
  if (i < 0 || !args[i + 1]) throw new Error(`Required: ${name} VALUE`);
  return args[i + 1];
};
const repo = path.resolve(option('--repo'));
const output = path.resolve(option('--out'));
if (typeof vm.SourceTextModule !== 'function') {
  throw new Error('Run with node --experimental-vm-modules');
}
const startedAt = new Date().toISOString();
const began = performance.now();
const gitEnv = { ...process.env, GIT_NO_LAZY_FETCH: '1', GIT_TERMINAL_PROMPT: '0' };
function git(...argv) {
  return execFileSync('git', ['-C', repo, ...argv], {
    encoding: 'utf8', timeout: 10000, maxBuffer: 1024 * 1024, env: gitEnv,
  });
}
assert.equal(git('rev-parse', `${manifest.commit}^{commit}`).trim(), manifest.commit);
const executablePaths = [
  'src/config/browser.config.ts', 'src/config/index.ts',
  'src/browser/browser-manager.ts',
];
const source = new Map();
const sourceChecks = [];
for (const filename of executablePaths) {
  const text = git('show', `${manifest.commit}:${filename}`);
  const digest = crypto.createHash('sha256').update(text).digest('hex');
  assert.equal(digest, manifest.files[filename], `Unexpected source bytes: ${filename}`);
  source.set(filename, text);
  sourceChecks.push({ filename, sha256: digest, matched: true });
}

// This is a test dependency boundary, not a hardened adversarial sandbox.
// Only three manually reviewed source modules are executed. All imports are
// allowlisted below; filesystem/proxy/cleanup dependencies are inert doubles.
async function loadModule(entry, { env = {}, directoryExists = true, events = [] } = {}) {
  const trace = { events, mkdir: [], exists: [], proxyCalls: 0, imports: [] };
  const proxyMarker = Object.freeze({ unitDouble: true });
  const context = vm.createContext({
    process: Object.freeze({ env: Object.freeze({ ...env }) }),
    __dirname: '/unit-fixture/src/config',
  }, { codeGeneration: { strings: false, wasm: false } });
  const cache = new Map();
  function synthetic(id, exports) {
    if (cache.has(id)) return cache.get(id);
    const module = new vm.SyntheticModule(Object.keys(exports), function () {
      for (const [key, value] of Object.entries(exports)) this.setExport(key, value);
    }, { context, identifier: id });
    cache.set(id, module);
    return module;
  }
  function actual(filename) {
    if (cache.has(filename)) return cache.get(filename);
    if (!source.has(filename)) throw new Error(`Source not allowlisted: ${filename}`);
    const code = stripTypeScriptTypes(source.get(filename), { mode: 'strip' });
    const module = new vm.SourceTextModule(code, {
      context, identifier: filename,
      importModuleDynamically() { throw new Error('Dynamic import is outside this test'); },
    });
    cache.set(filename, module);
    return module;
  }
  const root = actual(entry);
  await root.link((specifier, referencingModule) => {
    const parent = referencingModule.identifier;
    trace.imports.push({ parent, specifier });
    if (parent === 'src/config/index.ts') {
      if (specifier === './browser.config') return actual('src/config/browser.config.ts');
      if (specifier === './proxy.config') return synthetic('unit:proxy-marker', {
        getProxyConfig() { trace.proxyCalls++; return proxyMarker; },
      });
      if (specifier === 'path') return synthetic('unit:path', { resolve: path.posix.resolve });
      if (specifier === 'fs') return synthetic('unit:fs', {
        existsSync(value) { trace.exists.push(value); return directoryExists; },
        mkdirSync(value, options) { trace.mkdir.push({ path: value, options: { ...options } }); },
      });
    }
    if (parent === 'src/browser/browser-manager.ts' && specifier === '../utils/file-utils') {
      return synthetic('unit:cleanup', {
        cleanupTempDir(value) { events.push(`cleanup:${value}`); },
      });
    }
    throw new Error(`Import outside this test: ${parent} -> ${specifier}`);
  });
  await root.evaluate({ timeout: 1000 });
  return { namespace: root.namespace, trace, proxyMarker };
}

const results = [];
async function test(id, category, description, action) {
  const start = performance.now();
  try {
    const observed = await action();
    results.push({ id, category, description, passed: true, observed, durationMs: +(performance.now() - start).toFixed(3) });
    console.log(`PASS ${id}: ${description} | ${JSON.stringify(observed)}`);
  } catch (error) {
    results.push({ id, category, description, passed: false, error: String(error.stack || error), durationMs: +(performance.now() - start).toFixed(3) });
    console.log(`FAIL ${id}: ${description} | ${error.message}`);
  }
}
const plain = (value) => JSON.parse(JSON.stringify(value));
async function browser(env = {}) {
  return plain((await loadModule('src/config/browser.config.ts', { env })).namespace.getBrowserConfig());
}
async function app(env = {}, directoryExists = true) {
  const fixture = await loadModule('src/config/index.ts', { env, directoryExists });
  return { ...fixture, config: fixture.namespace.getAppConfig() };
}
async function manager(events = []) {
  const fixture = await loadModule('src/browser/browser-manager.ts', { events });
  return new fixture.namespace.BrowserManager();
}

await test('B01', 'config', 'Unset browser env uses headed Chrome path and Berlin timezone', async () => {
  const value = await browser();
  assert.deepEqual(value, { headless: false, executablePath: '/usr/bin/google-chrome-stable', timezoneId: 'Europe/Berlin' });
  return value;
});
await test('B02', 'config', 'Explicit browser path and timezone override defaults', async () => {
  const value = await browser({ BROWSER_EXECUTABLE_PATH: '/unit-fixture/chrome', BROWSER_TIMEZONE: 'Etc/UTC' });
  assert.equal(value.executablePath, '/unit-fixture/chrome'); assert.equal(value.timezoneId, 'Etc/UTC');
  return value;
});
await test('B03', 'config', 'Empty browser values fall back to defaults', async () => {
  const value = await browser({ BROWSER_EXECUTABLE_PATH: '', BROWSER_TIMEZONE: '' });
  assert.equal(value.executablePath, '/usr/bin/google-chrome-stable'); assert.equal(value.timezoneId, 'Europe/Berlin');
  return value;
});
await test('B04', 'config', 'Unimplemented HEADLESS environment variable has no effect', async () => {
  const value = await browser({ HEADLESS: 'true' }); assert.equal(value.headless, false);
  return { suppliedHEADLESS: 'true', actualHeadless: value.headless };
});
await test('A01', 'config', 'Unset app env produces MAX_PARALLEL 2 with inert proxy marker', async () => {
  const { config, trace, proxyMarker } = await app();
  assert.equal(config.maxParallel, 2); assert.equal(config.sessionsDir, '/unit-fixture/src/sessions');
  assert.equal(config.proxy, proxyMarker); assert.equal(trace.proxyCalls, 1); assert.equal(trace.mkdir.length, 0);
  return { maxParallel: config.maxParallel, sessionsDir: config.sessionsDir, realProxyUsed: false };
});
await test('A02', 'config', 'Missing custom sessions directory requests recursive mkdir only on inert fs', async () => {
  const { config, trace } = await app({ SESSIONS_DIR: '/unit-fixture/custom', MAX_PARALLEL: '3' }, false);
  assert.equal(config.maxParallel, 3); assert.equal(config.sessionsDir, '/unit-fixture/custom');
  assert.deepEqual(trace.mkdir, [{ path: '/unit-fixture/custom', options: { recursive: true } }]);
  return { maxParallel: config.maxParallel, mkdirRequests: trace.mkdir, realFilesystemChanged: false };
});
await test('A03', 'config', 'Existing sessions directory does not request mkdir', async () => {
  const { trace } = await app({ SESSIONS_DIR: '/unit-fixture/existing' }, true);
  assert.equal(trace.mkdir.length, 0); assert.deepEqual(trace.exists, ['/unit-fixture/existing']);
  return { mkdirRequests: 0, existsChecks: trace.exists };
});
for (const [id, input, expected] of [
  ['A04', '0', 0], ['A05', '-1', -1], ['A06', 'oops', NaN],
  ['A07', '2junk', 2], ['A08', '2.9', 2],
]) {
  await test(id, 'negative-config', `MAX_PARALLEL=${JSON.stringify(input)} is not rejected`, async () => {
    const { config } = await app({ MAX_PARALLEL: input });
    assert.ok(Object.is(config.maxParallel, expected));
    return { input, observed: Number.isNaN(config.maxParallel) ? 'NaN' : config.maxParallel, rejected: false };
  });
}
await test('A09', 'config', 'Empty MAX_PARALLEL falls back to 2', async () => {
  const { config } = await app({ MAX_PARALLEL: '' }); assert.equal(config.maxParallel, 2);
  return { input: '', observed: config.maxParallel };
});
await test('L01', 'lifecycle', 'Empty BrowserManager closes and cleans without work', async () => {
  const events = []; const m = await manager(events); assert.equal(m.getContext(), null);
  await m.closeAndCleanup(); assert.deepEqual(events, []);
  return { context: m.getContext(), events };
});
await test('L02', 'lifecycle', 'setContext preserves the inert context without closing it', async () => {
  const events = []; const m = await manager(events); const context = { async close() { events.push('close'); } };
  m.setContext(context, '/unit-fixture/temp'); assert.equal(m.getContext(), context); assert.deepEqual(events, []);
  return { contextIdentityPreserved: true, events };
});
await test('L03', 'lifecycle', 'close clears context but leaves cleanup until explicitly requested', async () => {
  const events = []; const m = await manager(events); m.setContext({ async close() { events.push('close'); } }, '/unit-fixture/temp');
  await m.close(); assert.equal(m.getContext(), null); assert.deepEqual(events, ['close']);
  m.cleanup(); assert.deepEqual(events, ['close', 'cleanup:/unit-fixture/temp']);
  return { events };
});
await test('L04', 'lifecycle', 'closeAndCleanup orders close before cleanup', async () => {
  const events = []; const m = await manager(events); m.setContext({ async close() { events.push('close'); } }, '/unit-fixture/temp');
  await m.closeAndCleanup(); assert.equal(m.getContext(), null); assert.deepEqual(events, ['close', 'cleanup:/unit-fixture/temp']);
  return { events };
});
await test('L05', 'lifecycle', 'Repeated successful closeAndCleanup is idempotent', async () => {
  const events = []; const m = await manager(events); m.setContext({ async close() { events.push('close'); } }, '/unit-fixture/temp');
  await m.closeAndCleanup(); await m.closeAndCleanup(); m.cleanup();
  assert.deepEqual(events, ['close', 'cleanup:/unit-fixture/temp']); return { events };
});
await test('L06', 'negative-lifecycle', 'Close rejection propagates, preserves context, and skips cleanup', async () => {
  const events = []; const m = await manager(events); const failure = new Error('UNIT_CLOSE_FAILURE');
  const context = { async close() { events.push('close:rejected'); throw failure; } };
  m.setContext(context, '/unit-fixture/temp'); await assert.rejects(() => m.closeAndCleanup(), (error) => error === failure);
  assert.equal(m.getContext(), context); assert.deepEqual(events, ['close:rejected']);
  return { error: failure.message, contextRetained: true, cleanupCalls: 0, events };
});
await test('L07', 'negative-lifecycle', 'A later successful close retry then permits cleanup', async () => {
  const events = []; const m = await manager(events); let attempts = 0;
  m.setContext({ async close() { attempts++; events.push(`close:${attempts}`); if (attempts === 1) throw new Error('UNIT_CLOSE_FAILURE'); } }, '/unit-fixture/temp');
  await assert.rejects(() => m.closeAndCleanup(), /UNIT_CLOSE_FAILURE/); await m.closeAndCleanup();
  assert.equal(m.getContext(), null); assert.deepEqual(events, ['close:1', 'close:2', 'cleanup:/unit-fixture/temp']);
  return { attempts, events };
});

const failed = results.filter((result) => !result.passed).length;
const report = {
  study: 'patchright-enhanced configuration/lifecycle unit study',
  repository: manifest.repository, commit: manifest.commit,
  startedAt, finishedAt: new Date().toISOString(), elapsedMs: +(performance.now() - began).toFixed(3),
  runtime: process.version,
  scope: {
    actualUpstreamModulesExecuted: executablePaths,
    unitDoubles: ['fs.existsSync/mkdirSync', 'proxy marker only', 'cleanupTempDir', 'context.close'],
    externalBrowserDependenciesImported: false, browserLaunched: false,
    navigationPerformed: false, stealthTested: false, proxyConfigured: false,
    networkRequestsFromTestedModules: false, semanticTypecheckPerformed: false,
    fullProjectBuildPerformed: false, upstreamTestsRun: false,
    note: 'Passing assertions establish current unit behavior, including defects; they do not establish browser, integration, or security success.',
  },
  sourceChecks, summary: { tests: results.length, passed: results.length - failed, failed }, results,
};
fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, `${JSON.stringify(report, null, 2)}\n`);
console.log(`SUMMARY ${report.summary.passed}/${report.summary.tests} assertions matched; ${failed} failed; ${report.elapsedMs} ms`);
console.log(`RESULT ${output}`);
if (failed) process.exitCode = 1;
