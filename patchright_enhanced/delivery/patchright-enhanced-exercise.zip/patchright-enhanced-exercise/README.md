# Patchright Enhanced 配置与生命周期单元练习

只执行固定提交的 3 个真实 TypeScript 模块，外部副作用使用惰性替身。
这不是浏览器启动、站点访问、完整类型检查或完整项目构建实验。
20 个断言用来记录当前行为；部分 PASS 明确确认了缺陷，不能理解为质量合格。

## 前提

在有 Bash、Git 和 Node 24.19.0 的环境中解压此包并进入本目录。
Node 的 VM modules 和类型去除会打印 ExperimentalWarning，这是本轮保留的真实提示。
本包没有 node_modules，也不要求 npm install。没有可用的 Node 24 时先停止。

## 六步主实验

1. 检查工具

    node --version
    git --version

2. 只读获取固定来源并运行真实单元代码

    bash reproduce.sh work

该脚本拒绝已存在的 work 目录，以免覆盖旧结果。正常公共 Git 读取下载仓库对象，但不检出工作树、不安装依赖。若网络或权限阻止下载，停止并记录原因，不换身份或走绕过路径。

3. 观察实际配置与环境变量

    node inspect.mjs work/results.json defaults

4. 对照数值输入矩阵

    node inspect.mjs work/results.json counts

5. 对照成功、重复调用、关闭拒绝与再次关闭

    node inspect.mjs work/results.json lifecycle

6. 核对结果与未测边界

    node inspect.mjs work/results.json scope

实际应看到 20/20、3 个源码散列一致、浏览器/导航/完整构建均为 false。耗时与时间戳可能变化，不是性能基准。

## 可审计的来源获取命令

reproduce.sh 中实际执行以下来源读取步骤；不需要再次执行它们：

    git clone --no-checkout https://github.com/whaleyxbt/patchright-enhanced.git work/repo
    git -C work/repo rev-parse 'e38ab7ab9448db6f093f72ee097c18ca9905e84c^{commit}'

之后 harness 对固定提交使用 git show，核对 source-manifest.json 内的 SHA-256，再执行白名单模块。
完整单元运行命令为：

    node --experimental-vm-modules harness.mjs --repo work/repo --out work/results.json

## 包内文件

- harness.mjs：自建测试夹具
- inspect.mjs：自建只读结果查看器
- viewer-tests.mjs：自建查看器的证据完整性正反例测试
- reproduce.sh：自建获取与复现脚本
- source-manifest.json：来源、版本、文件指纹
- README.md：本说明

没有上游源码、副本依赖、浏览器、凭据或私人知识正文。当前固定提交的跟踪文件中未找到许可证文件，因此本包不复制上游模块；这不是许可或商用授权判断。

## 执行边界

真实执行：getBrowserConfig、getAppConfig、BrowserManager。
替身：fs 存在/建目录操作、代理标记、context.close、cleanupTempDir；path.resolve 使用纯路径运算。
VM 不是用于任意不可信代码的强安全沙箱；这里仅载入已审阅且逐字节核对的 3 个模块，并限定导入。
不执行：main、SessionRunner、context-factory、proxy.config、start/default、文件清理实现、Patchright 或浏览器。
合成失败仅证明指定分支。它不证明浏览器故障恢复、目录真的被删除或真实任务成功。


## 查看器本身的补充验证

这组测试与20个上游行为断言分开统计，不是另加上游测试：

    node viewer-tests.mjs work/results.json

预期：VIEWER SUMMARY 10/10；1个完整证据正例被接受，9个合成错误证据被拒绝。负例包括空数组、缺失项、重复路径、格式错误或不匹配的散列、错误提交、错误路径、matched=false、错误执行模块。
scope查看器必须确认恰好3个唯一的预期文件、各SHA-256格式及与清单逐项一致、源码匹配标记为true、仓库/提交与清单一致，才打印“3 source hashes”。这些检查验证记录一致性，不能替代独立重新执行上游函数。
