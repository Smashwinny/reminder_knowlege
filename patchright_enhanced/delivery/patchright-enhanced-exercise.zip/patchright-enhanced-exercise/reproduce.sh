#!/usr/bin/env bash
# Normal public Git read followed by a bounded offline unit experiment.
# No package installation, browser dependency, browser launch, or site visit.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEST="${1:?Usage: bash reproduce.sh NEW_WORK_DIRECTORY}"
if [[ -e "$DEST" ]]; then
  echo "Refusing an existing work directory: $DEST" >&2
  exit 2
fi
mkdir -p "$DEST"
DEST="$(cd -- "$DEST" && pwd)"
exec > >(tee "$DEST/reproduce.log") 2>&1
printf 'START %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
printf 'Runtime: '; node --version
git clone --no-checkout https://github.com/whaleyxbt/patchright-enhanced.git "$DEST/repo"
EXPECTED=e38ab7ab9448db6f093f72ee097c18ca9905e84c
ACTUAL="$(GIT_NO_LAZY_FETCH=1 git -C "$DEST/repo" rev-parse "$EXPECTED^{commit}")"
test "$ACTUAL" = "$EXPECTED"
printf 'PINNED_COMMIT %s\n' "$ACTUAL"
node --experimental-vm-modules "$ROOT/harness.mjs" --repo "$DEST/repo" --out "$DEST/results.json"
printf 'END %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
