#!/usr/bin/env node
// Original negative tests for the read-only result viewer; not upstream tests.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const source=process.argv[2];
if(!source) throw new Error('Usage: node viewer-tests.mjs RESULTS.json');
const baseline=JSON.parse(fs.readFileSync(source,'utf8'));
const viewer=fileURLToPath(new URL('./inspect.mjs',import.meta.url));
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'patchright-viewer-'));
const cases=[
 ['valid-evidence',r=>r,true],
 ['empty-source-checks',r=>{r.sourceChecks=[];},false],
 ['missing-source-check',r=>{r.sourceChecks.pop();},false],
 ['duplicate-source-path',r=>{r.sourceChecks[2]={...r.sourceChecks[0]};},false],
 ['malformed-source-hash',r=>{r.sourceChecks[0].sha256='bad';},false],
 ['mismatched-source-hash',r=>{r.sourceChecks[0].sha256='0'.repeat(64);},false],
 ['wrong-commit',r=>{r.commit='0'.repeat(40);},false],
 ['unexpected-source-path',r=>{r.sourceChecks[0].filename='src/unexpected.ts';},false],
 ['match-flag-false',r=>{r.sourceChecks[0].matched=false;},false],
 ['wrong-executed-module',r=>{r.scope.actualUpstreamModulesExecuted[0]='src/unexpected.ts';},false],
];
try{
 for(const [name,mutate,shouldPass] of cases){
  const data=structuredClone(baseline);mutate(data);
  const input=path.join(dir,name+'.json');fs.writeFileSync(input,JSON.stringify(data));
  const result=spawnSync(process.execPath,[viewer,input,'scope'],{encoding:'utf8'});
  assert.equal(result.error,undefined,'Could not invoke viewer');
  assert.equal(result.status===0,shouldPass,`${name}: unexpected acceptance/rejection`);
  if(!shouldPass) assert.ok(!result.stdout.includes('VERIFIED'),'Invalid evidence printed a success claim');
  console.log(`PASS VIEWER ${name}: ${shouldPass?'accepted':'rejected'}; exit=${result.status}`);
 }
 console.log(`VIEWER SUMMARY ${cases.length}/${cases.length}; 1 valid + ${cases.length-1} negative cases; separate from 20 upstream behavior assertions`);
}finally{
 fs.rmSync(dir,{recursive:true,force:true});
}
