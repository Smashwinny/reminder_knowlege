#!/usr/bin/env node
// Original read-only result viewer. It does not execute upstream code.
import fs from 'node:fs';
import assert from 'node:assert/strict';
const [filename, mode] = process.argv.slice(2);
if (!filename || !mode) throw new Error('Usage: node inspect.mjs RESULTS.json defaults|counts|lifecycle|scope');
const r=JSON.parse(fs.readFileSync(filename,'utf8'));
const manifest=JSON.parse(fs.readFileSync(new URL('./source-manifest.json',import.meta.url),'utf8'));
const expectedPaths=['src/config/browser.config.ts','src/config/index.ts','src/browser/browser-manager.ts'];
const filters={defaults:x=>['B01','B02','B03','B04','A01','A02','A03','A09'].includes(x.id),counts:x=>x.id.startsWith('A'),lifecycle:x=>x.id.startsWith('L')};
if(mode==='scope'){
  assert.deepEqual(r.summary,{tests:20,passed:20,failed:0});
  for(const key of ['browserLaunched','navigationPerformed','networkRequestsFromTestedModules','fullProjectBuildPerformed']) assert.equal(r.scope[key],false);
  assert.equal(r.repository,manifest.repository,'Unexpected repository');
  assert.equal(r.commit,manifest.commit,'Unexpected commit');
  assert.ok(Array.isArray(r.sourceChecks),'sourceChecks must be an array');
  assert.equal(r.sourceChecks.length,expectedPaths.length,'Exactly 3 source checks required');
  const names=r.sourceChecks.map(x=>x.filename);
  assert.equal(new Set(names).size,expectedPaths.length,'Unique source paths required');
  assert.deepEqual([...names].sort(),[...expectedPaths].sort(),'Unexpected source paths');
  assert.deepEqual([...r.scope.actualUpstreamModulesExecuted].sort(),[...expectedPaths].sort(),'Unexpected executed modules');
  for(const check of r.sourceChecks){
    assert.equal(check.matched,true,'Source match must be true');
    assert.match(check.sha256,/^[a-f0-9]{64}$/,'SHA-256 must be well formed');
    assert.equal(check.sha256,manifest.files[check.filename],'Source hash differs from manifest');
  }
  console.log('VERIFIED 20/20; 3 source hashes; no browser/navigation/build');
  console.log(JSON.stringify({runtime:r.runtime,commit:r.commit,scope:r.scope},null,2));
}else{
  if(!filters[mode]) throw new Error('Unknown view: '+mode);
  for(const x of r.results.filter(filters[mode])) console.log(x.id+' '+JSON.stringify(x.observed));
}
